book lines provided by Graham Banks (many thanks)
