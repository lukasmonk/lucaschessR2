#include "UndoData.h"

UndoData::UndoData(void)
{
}

UndoData::~UndoData(void)
{
}
