const int White = 1;
const int Black = 2;
