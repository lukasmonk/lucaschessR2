#ifndef PSQT_H
#define PSQT_H

extern const int Pawn[144];
extern const int Knight[144];
extern const int eKnight[144];
extern const int Bishop[144];
extern const int Rook[144];
extern const int KingMid[144];
extern const int KingEnd[144];
extern const int opp[144];
extern const int *endtab[16];
extern const int *midtab[16];
extern const int SupN[144];
extern const int sqcol[144];
extern const int eQueen[144];
extern const int eBishop[144];

#endif

