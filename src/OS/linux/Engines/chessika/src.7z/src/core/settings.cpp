#include "settings.h"

int Settings::MAX_DEPTH = 20;
bool Settings::SHOW_MOVE_ORDERING = false;
bool Settings::SHOW_MOVE_CALCULATION = true;
bool Settings::WEB_MODE = false;
