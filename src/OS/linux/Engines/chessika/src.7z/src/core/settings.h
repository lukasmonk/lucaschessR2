#ifndef _SETTINGS_H
#define _SETTINGS_H

class Settings {
    public:
        static int MAX_DEPTH;
        static bool SHOW_MOVE_ORDERING;
        static bool SHOW_MOVE_CALCULATION;
        static bool WEB_MODE;
};

#endif
