
#ifndef VERSION_H
#define VERSION_H

#ifndef GIT_VERSION
#define GIT_VERSION
#endif
#define ENGINE_NAME             "Daydreamer"
#define ENGINE_VERSION_NUMBER   "1.75 JA"
#define ENGINE_VERSION_NAME     ""  //GIT_VERSION
#define ENGINE_VERSION          ENGINE_VERSION_NUMBER ENGINE_VERSION_NAME
#define ENGINE_AUTHOR           "Aaron Becker"

#endif

