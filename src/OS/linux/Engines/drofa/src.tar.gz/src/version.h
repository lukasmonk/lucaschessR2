#ifndef VERSION_H
#define VERSION_H

#define VER_MAJ 3
#define VER_MIN 3
#define VER_PATCH 0

#endif
