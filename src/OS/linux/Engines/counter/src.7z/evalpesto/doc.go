package eval

/*
Rofchade is a UCI chess engine written in C++ by Ronald Friederich.
http://rofchade.nl/?p=307
*/
