/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adolph Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project realised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info: 
     jeff@proxone.net
*/

#include "AlphaBetaSearcher.h"
#include <iostream>
#include <cstring>

int AlphaBetaSearcher::alphabeta(Position *p, int depth, int alpha, int beta)
{
    int m;
    bool fin;
    analysedPositions++;
    
    pv_length[ply]=ply;
    Move bestMove=0;

    //on retourne de suite s'il manque un roi
    if(!(p->w_occupied^p->w_pawn^p->w_knight^p->w_bishop^p->w_rook^p->w_queen)) return -20000;
    if(!(p->b_occupied^p->b_pawn^p->b_knight^p->b_bishop^p->b_rook^p->b_queen)) return 20000;

    if(depth<=0) return evaluator->evaluate(p);

    //std::cout<<"alphabeta "<<depth<<std::endl;

    //int value;
    std::vector<Move> *nextMoves=moveGenerator->generateMoves(p);
    //bool existLegalMove=false;
    
    
    if(p->flags&playerMask) /* niveau maximisant */
    {
        //value=-100000;
        m=alpha;
        fin=false;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); (!fin)&&iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            //on teste la legalite du coup, si le roi est en echec apres le domove le coup n est pas legal
            //si le coup n est pas legal aller directement au undomove
            //if(moveGenerator->isLegal(p))
            //{
            //    existLegalMove=true;
            
                int t=alphabeta(p,depth-1,m,beta);
                ply--;
                if(t>m)
                {
                    m=t;
                    bestMove=*iter;
              
                    //update pv
                    pv[ply][ply]=(*iter);
                    for(int j=ply+1;j<pv_length[ply+1];j++)
                        pv[ply][j]=pv[ply+1][j];
                    pv_length[ply]=pv_length[ply+1];
                
                    if(t>beta) fin=true;
                }
            //} else ply--;
            p->undoMove(*iter);
        }
    }
    else /* niveau minimisant */
    {
        //value=100000;
        m=beta;
        fin=false;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); (!fin)&&iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            //on teste la legalite du coup, si le roi est en echec apres le domove le coup n est pas legal
            //si le coup n est pas legal aller directement au undomove
            //if(moveGenerator->isLegal(p))
            //{
            //    existLegalMove=true;
            
                int t=alphabeta(p,depth-1,alpha,m);
                ply--;
                if(t<m)
                {
                    m=t;
                    bestMove=*iter;
              
                    //update pv
                    pv[ply][ply]=(*iter);
                    for(int j=ply+1;j<pv_length[ply+1];j++)
                        pv[ply][j]=pv[ply+1][j];
                    pv_length[ply]=pv_length[ply+1];
                
                    if(t<alpha) fin=true;
                }
            //} else ply--;
            p->undoMove(*iter);
        }
    }
    delete nextMoves;
    
	return m; /*
	if(bestMove.move!=0)
	p->doMove(bestMove);
    if(moveGenerator->isLegal(p)&&bestMove.move!=0){p->undoMove(bestMove); return m;}
    else //pas de mouvements legaux : on verifie si pat ou mat
    {
		if(bestMove.move!=0)
        p->undoMove(bestMove);
        
        bitboard attacks;
        if(p->flags&playerMask) // white plays 
        {
            attacks=moveGenerator->getAttacks(p,false);
            if((p->b_occupied^p->b_pawn^p->b_knight^p->b_bishop^p->b_rook^p->b_queen)&attacks) return -1000000;
            else return 0;
        }
        else //black plays
        {
            attacks=moveGenerator->getAttacks(p,true);
            if((p->w_occupied^p->w_pawn^p->w_knight^p->w_bishop^p->w_rook^p->w_queen)&attacks) return 1000000;
            else return 0;
        }
    }*/
}

Move AlphaBetaSearcher::rootSearch(Position *current, int depth)
{
    startTime=clock();
    double totalTime;

    std::vector<Move> *possibleMoves=moveGenerator->generateMoves(current);
    std::vector<Move>::iterator iter;
    int value;
    Move bestMove;
    analysedPositions=0;
    
    ply=1;
    pv_length[ply]=ply;
    
    if(current->flags&playerMask) /* computer plays white */
    {
        value=-100000;
        for(iter=possibleMoves->begin(); iter<possibleMoves->end(); iter++)
        {
            ply++;
            current->doMove(*iter);
            if(moveGenerator->isLegal(current))
            {
                int mmv=alphabeta(current,depth-1,-1000000,1000000);
                ply--;
                if(mmv>value)
                {
                    value=mmv;
                    bestMove=(*iter);
              
                    //update pv
                    pv[ply][ply]=bestMove;
                    for(int j=ply+1;j<pv_length[ply+1];j++)
                        pv[ply][j]=pv[ply+1][j];
                    pv_length[ply]=pv_length[ply+1];
                
                    if(post) displayPV(current,value,depth);
                }
                //displayPV(current,value,depth);
            } else ply--;
            current->undoMove(*iter);
        }
    }
    else  /* computer plays black */
    {
        value=100000;
        for(iter=possibleMoves->begin(); iter<possibleMoves->end(); iter++)
        {
            ply++;
            current->doMove(*iter);
            if(moveGenerator->isLegal(current))
            {
                int mmv=alphabeta(current,depth-1,-1000000,1000000);
                ply--;
                if(mmv<value)
                {
                    value=mmv;
                    bestMove=(*iter);
           
                    //update pv
                    pv[ply][ply]=bestMove;
                    for(int j=ply+1;j<pv_length[ply+1];j++)
                        pv[ply][j]=pv[ply+1][j];
                    pv_length[ply]=pv_length[ply+1];
                
                    if(post) displayPV(current,-value,depth);
                }
                //displayPV(current,value,depth);
            } else ply--;
            current->undoMove(*iter);
        }
    }
    
    totalTime=(clock()-startTime)/(double)CLOCKS_PER_SEC;
    //std::cout<<"Search time:"<<totalTime<<" Speed:"<<(analysedPositions/totalTime)<<" nodes/s."<<std::endl;
    iface->displayTimeNPS(totalTime,(int)(analysedPositions/totalTime));

    delete possibleMoves;
    
    //return bestMove;
    if(bestMove.move!=0)
	current->doMove(bestMove);
    if(moveGenerator->isLegal(current)&&bestMove.move!=0){current->undoMove(bestMove); return bestMove;}
    else
    {
        current->undoMove(bestMove);
        std::cout<<"resign"<<std::endl;
    }
    return 0;
}

void AlphaBetaSearcher::displayPV(Position *current, int value, int depth)
{
    Position p=(*current);
    char *moveString;

    strcpy(pvString,"");
    //std::cout<<std::dec<<depth<<'\t'<<(value)<<'\t'<<(int)(((clock()-startTime)/(double)CLOCKS_PER_SEC)*100)<<'\t'<<analysedPositions<<'\t';

    for (int i = 1; i < pv_length[1]; i++)
    {
        moveString=moveParser.getStringFromMove(pv[1][i], &p);
        //std::cout<<moveString<<' ';
        strcat(pvString,moveString);
        strcat(pvString," ");
        delete moveString;
        p.doMove(pv[1][i]);
    }
    
    //if(current->flags&playerMask)
        
    
    iface->displayThinking(depth, value, (int)(((clock()-startTime)/(double)CLOCKS_PER_SEC)*100), analysedPositions, pvString);
    
    
    //std::cout<<std::endl;
}

int AlphaBetaSearcher::quiesce(Position *p, int alpha, int beta)
{
    int m;
    bool fin;
    //analysedPositions++;
    //int score=evaluator->evaluate(p);
    
    pv_length[ply]=ply;

    //on retourne de suite s'il manque un roi
    if(!(p->w_occupied^p->w_pawn^p->w_knight^p->w_bishop^p->w_rook^p->w_queen)) return -20000;
    if(!(p->b_occupied^p->b_pawn^p->b_knight^p->b_bishop^p->b_rook^p->b_queen)) return 20000;

    if(ply>=29) 
    {
        std::cout<<ply<<std::endl;//return evaluator->evaluate(p);//quiesce(p,alpha,beta);//evaluator->evaluate(p);
        p->displayChessboard();
    }
    //int value;
    std::vector<Move> *nextMoves=moveGenerator->generateCaptureMoves(p);
    if(nextMoves->empty()) { /*std::cout<<"empty"<<std::endl;*/ return evaluator->evaluate(p); }
    
    
    if(p->flags&playerMask) /* niveau maximisant */
    {
        //value=-100000;
        //if(score>=beta) return score;
        m=alpha;
        fin=false;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); (!fin)&&iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int t=quiesce(p,m,beta);
            analysedPositions++;
            ply--;
            if(t>m)
            {
                m=t;
              
                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
                
                if(t>beta) fin=true;
            }
            p->undoMove(*iter);
        }
    }
    else /* niveau minimisant */
    {
        //value=100000;
        //if(score<=alpha) return score;
        m=beta;
        fin=false;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); (!fin)&&iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int t=quiesce(p,alpha,m);
            analysedPositions++;
            ply--;
            if(t<m)
            {
                m=t;
              
                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
                
                if(t<alpha) fin=true;
            }
            p->undoMove(*iter);
        }
    }
    delete nextMoves;
    return m;
}
