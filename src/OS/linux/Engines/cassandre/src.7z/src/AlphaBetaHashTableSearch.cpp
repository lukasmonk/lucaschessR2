/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adoplh Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project relised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info:
     jeff@proxone.net
*/

#include "AlphaBetaHashTableSearcher.h"
#include <iostream>
#include <cstring>

int  AlphaBetaHashTableSearcher::alphabeta(Position *p, int depth, int alpha, int beta)
{
    analysedPositions++;

    pv_length[ply]=ply;
    Move bestMove=0;
    bool side = p->flags&playerMask;
    int hashf=hashfALPHA;//,probre_val;

    /*	
    if ((val = ht->ProbeHash(depth, alpha, beta,p,&bestMove)) != -1) 
    {
  	//std::cout << "On quitte de suite AlphaBeta\n";
	return val;
    }*/

    //on retourne de suite s'il manque un roi
    if(!(p->w_occupied^p->w_pawn^p->w_knight^p->w_bishop^p->w_rook^p->w_queen)) return -20000;
    if(!(p->b_occupied^p->b_pawn^p->b_knight^p->b_bishop^p->b_rook^p->b_queen)) return 20000;
   

  /*  if ((probre_val = ht->ProbeHash(depth, alpha, beta,p,&bestMove,side)) != -1)
        return probre_val;*/


switch (ht->ProbeHash(depth, alpha, beta,p,&bestMove,side)) {

    case hashfEXACT:
      return(ht->getHashValue(p,side));

    case hashfBETA:
    if (ht->getHashValue(p,side)>=hashfBETA)
                    return (ht->getHashValue(p,side));
                else break;

    case hashfALPHA:
     if (ht->getHashValue(p,side)<=hashfALPHA)
                    return (ht->getHashValue(p,side));
                else break;

}

    //ALPHA-BETA BASED ON NEGMAX EVALUATION
    if(depth<=0) {
    		    int val = evaluator->evaluate(p);
		    /*if (depth == 0 )
		        ht->RecordHash(depth, val,hashfEXACT,p,&bestMove,side);*/
		    return -val;
		 }

    std::vector<Move> *nextMoves=moveGenerator->generateMoves(p);

    std::vector<Move>::iterator iter;

    /* yeah loop through the moves */
    for(iter=nextMoves->begin(); iter<nextMoves->end(); iter++)
    {
                ply++;

		p->doMove(*iter);

		int score=-alphabeta(p,depth-1,-beta,-alpha);
		ply--;
                p->undoMove(*iter); //take care of the place of this

		if (score >= beta) {
                     //ht->RecordHash(depth, beta, hashfBETA,p,&bestMove,side);
                     //return beta;
                     ht->RecordHash(depth, score, hashfBETA,p,&bestMove,side);
		     return score;
                }
                if (score > alpha) {
                      hashf = hashfEXACT;
                      alpha = score;
		      bestMove=*iter;

		      //update pv
		      pv[ply][ply]=(*iter);
		      for(int j=ply+1;j<pv_length[ply+1];j++)
				pv[ply][j]=pv[ply+1][j];
			pv_length[ply]=pv_length[ply+1];
                 }
    }

  delete nextMoves;
  ht->RecordHash(depth, alpha, hashf,p,&bestMove,side);
  return alpha;
}

Move AlphaBetaHashTableSearcher::rootSearch(Position *current, int depth)
{
    startTime=clock();
    double totalTime;

    std::vector<Move> *possibleMoves=moveGenerator->generateMoves(current);
    std::vector<Move>::iterator iter;
    int value;
    Move bestMove;
    analysedPositions=0;

    ply=1;
    pv_length[ply]=ply;
    
    if(current->flags&playerMask) // computer plays white 
    {
        value=-100000;
        for(iter=possibleMoves->begin(); iter<possibleMoves->end(); iter++)
        {
            ply++;
            current->doMove(*iter);
            if(moveGenerator->isLegal(current))
            {
                int score=alphabeta(current,depth-1,-1000000,1000000);
                ply--;
                if(score>value)
                {
                    value=score;
                    bestMove=(*iter);

                    //update pv
                    pv[ply][ply]=bestMove;
                    for(int j=ply+1;j<pv_length[ply+1];j++)
                        pv[ply][j]=pv[ply+1][j];
                    pv_length[ply]=pv_length[ply+1];

                    if(post) displayPV(current,value,depth);
                }
                //displayPV(current,value,depth);
            } else ply--;
            current->undoMove(*iter);
        }
    }
    else  // computer plays black 
    {
        value=100000;
        for(iter=possibleMoves->begin(); iter<possibleMoves->end(); iter++)
        {
            ply++;
            current->doMove(*iter);
            if(moveGenerator->isLegal(current))
            {
                int score=alphabeta(current,depth-1,-1000000,1000000);
                ply--;
                if(score<value)
                {
                    value=score;
                    bestMove=(*iter);

                    //update pv
                    pv[ply][ply]=bestMove;
                    for(int j=ply+1;j<pv_length[ply+1];j++)
                        pv[ply][j]=pv[ply+1][j];
                    pv_length[ply]=pv_length[ply+1];

                    if(post) displayPV(current,value,depth) ;
                }
                //displayPV(current,value,depth);
            } else ply--;
            current->undoMove(*iter);
        }
    }
    
    totalTime=(clock()-startTime)/(double)CLOCKS_PER_SEC;
    std::cout<<"Search time:"<<totalTime<<" Speed:"<<(analysedPositions/totalTime)<<" nodes/s."<<std::endl;

    delete possibleMoves;

    //return bestMove;
    if(bestMove.move!=0)
	current->doMove(bestMove);
    if(moveGenerator->isLegal(current)&&bestMove.move!=0){current->undoMove(bestMove); return bestMove;}
    else
    {
        current->undoMove(bestMove);
        std::cout<<"resign"<<std::endl;
    }
    return 0;
}
void AlphaBetaHashTableSearcher::displayPV(Position *current, int value, int depth)
{
    Position p=(*current);
    char *moveString;

    std::cout<<std::dec<<depth<<'\t'<<(value)<<'\t'<<(int)(((clock()-startTime)/(double)CLOCKS_PER_SEC)*100)<<'\t'<<analysedPositions<<'\t';

    for (int i = 1; i < pv_length[1]; i++)
    {
        moveString=moveParser.getStringFromMove(pv[1][i], &p);
        std::cout<<moveString<<' ';
        delete moveString;
        p.doMove(pv[1][i]);
    }

    std::cout<<std::endl;
}

int AlphaBetaHashTableSearcher::quiesce(Position *p, int alpha, int beta)
{

    //analysedPositions++;
    int score=evaluator->evaluate(p);

    pv_length[ply]=ply;

    //on retourne de suite s'il manque un roi
    if(!(p->w_occupied^p->w_pawn^p->w_knight^p->w_bishop^p->w_rook^p->w_queen)) return -20000;
    if(!(p->b_occupied^p->b_pawn^p->b_knight^p->b_bishop^p->b_rook^p->b_queen)) return 20000;

    if(ply>=29)
    {
        std::cout<<ply<<std::endl;return -evaluator->evaluate(p);//quiesce(p,alpha,beta);//evaluator->evaluate(p);
        p->displayChessboard();
    }
    //int value;
    std::vector<Move> *nextMoves=moveGenerator->generateCaptureMoves(p);
    if(nextMoves->empty()) { //std::cout<<"empty"<<std::endl;
                              return -evaluator->evaluate(p); 
                           }

     if (score >= beta)
		return beta;
	if (score > alpha)
		alpha = score;

/*
    if(p->flags&playerMask) // niveau maximisant 
    {
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int score=quiesce(p,alpha,beta);
            analysedPositions++;
            ply--;
            if(score>alpha)
            {
                alpha=score;
                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];

                if(alpha>=beta) break;
            }
            p->undoMove(*iter);
        }
        return alpha;
    }
    else // niveau minimisant 
    {*/
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int score=-quiesce(p,-beta,-alpha);

            analysedPositions++;
            ply--;
	    p->undoMove(*iter);
	    
            if(score>alpha)
            {
                if(alpha>=beta)
		       return beta;

		alpha=score;

                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
            }
	    

        }
	delete nextMoves;
        return alpha;
    //}

}


