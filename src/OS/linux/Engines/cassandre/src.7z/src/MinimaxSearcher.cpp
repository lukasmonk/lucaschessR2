/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adolph Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project realised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info: 
     jeff@proxone.net
*/

#include "MinimaxSearcher.h"
#include <iostream>
#include <cstring>


int MinimaxSearcher::minimax(Position *p, int depth)
{    
    analysedPositions++;
    
    pv_length[ply]=ply;

    //on retourne de suite s'il manque un roi
    if(!(p->w_occupied^p->w_pawn^p->w_knight^p->w_bishop^p->w_rook^p->w_queen)) return -20000;
    if(!(p->b_occupied^p->b_pawn^p->b_knight^p->b_bishop^p->b_rook^p->b_queen)) return 20000;

    if(depth<=0) return evaluator->evaluate(p);//quiesce(p);//evaluator->evaluate(p);

    int value;
    std::vector<Move> *nextMoves=moveGenerator->generateMoves(p);
    if(p->flags&playerMask) /* niveau maximisant */
    {
        value=-100000;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int mmv=minimax(p,depth-1);
            ply--;
            if(mmv>value)
            {
                value=mmv;
              
                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
            }
            p->undoMove(*iter);
        }
    }
    else /* niveau minimisant */
    {
        value=100000;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int mmv=minimax(p,depth-1);
            ply--;
            if(mmv<value)
            {
                value=mmv;
              
                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
            }
            p->undoMove(*iter);
        }
    }
    delete nextMoves;
    return value;
}

Move MinimaxSearcher::rootSearch(Position *current, int depth)
{
    startTime=clock();
    double totalTime;

    std::vector<Move> *possibleMoves=moveGenerator->generateMoves(current);
    std::vector<Move>::iterator iter;
    int value;
    Move bestMove;
    analysedPositions=0;
    
    ply=1;
    pv_length[ply]=ply;
    
    if(current->flags&playerMask) /* computer plays white */
    {
        value=-100000;
        for(iter=possibleMoves->begin(); iter<possibleMoves->end(); iter++)
        {
            ply++;
            current->doMove(*iter);
            int mmv=minimax(current,depth-1);
            ply--;
            if(mmv>value)
            {
                value=mmv;
                bestMove=(*iter);
              
                //update pv
                pv[ply][ply]=bestMove;
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
                
                if(post) displayPV(current,value,depth);
            }
            current->undoMove(*iter);
        }
    }
    else  /* computer plays black */
    {
        value=100000;
        for(iter=possibleMoves->begin(); iter<possibleMoves->end(); iter++)
        {
            ply++;
            current->doMove(*iter);
            int mmv=minimax(current,depth-1);
            ply--;
            if(mmv<value)
            {
                value=mmv;
                bestMove=(*iter);
           
                //update pv
                pv[ply][ply]=bestMove;
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
                
                if(post) displayPV(current,value,depth);
            }
            current->undoMove(*iter);
        }
    }
    
    totalTime=(clock()-startTime)/(double)CLOCKS_PER_SEC;
    std::cout<<"Search time:"<<totalTime<<" Speed:"<<(analysedPositions/totalTime)<<" nodes/s."<<std::endl;

    delete possibleMoves;
    return bestMove;
}

void MinimaxSearcher::displayPV(Position *current, int value, int depth)
{
    Position p=(*current);
    char *moveString;

    std::cout<<std::dec<<depth<<'\t'<<(value)<<'\t'<<(int)(((clock()-startTime)/(double)CLOCKS_PER_SEC)*100)<<'\t'<<analysedPositions<<'\t';

    for (int i = 1; i < pv_length[1]; i++)
    {
        moveString=moveParser.getStringFromMove(pv[1][i], &p);
        std::cout<<moveString<<' ';
        delete moveString;
        p.doMove(pv[1][i]);
    }
    
    std::cout<<std::endl;
}

int MinimaxSearcher::quiesce(Position *p)
{
    //analysedPositions++;
    pv_length[ply]=ply;
    int value;
    
    if(ply>8) return evaluator->evaluate(p);
    
    std::vector<Move> *nextMoves=moveGenerator->generateCaptureMoves(p);
    
    if(nextMoves->empty()) { /*std::cout<<"empty"<<std::endl;*/ return evaluator->evaluate(p); }
    
    if(p->flags&playerMask) /* niveau maximisant */
    {
        value=-100000;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int mmv=quiesce(p);
            analysedPositions++;
            ply--;
            if(mmv>value)
            {
                value=mmv;
              
                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
            }
            p->undoMove(*iter);
        }
    }
    else /* niveau minimisant */
    {
        value=100000;
        std::vector<Move>::iterator iter;
        for(iter=nextMoves->begin(); iter<nextMoves->end(); iter++)
        {
            ply++;
            p->doMove(*iter);
            int mmv=quiesce(p);
            analysedPositions++;
            ply--;
            if(mmv<value)
            {
                value=mmv;
              
                //update pv
                pv[ply][ply]=(*iter);
                for(int j=ply+1;j<pv_length[ply+1];j++)
                    pv[ply][j]=pv[ply+1][j];
                pv_length[ply]=pv_length[ply+1];
            }
            p->undoMove(*iter);
        }
    }
    delete nextMoves;
    return value;
}
