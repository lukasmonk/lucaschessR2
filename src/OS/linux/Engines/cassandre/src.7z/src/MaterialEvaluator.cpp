/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adolph Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project realised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info: 
     jeff@proxone.net
*/

#include "MaterialEvaluator.h"

int MaterialEvaluator::evaluate(Position *p)
{
    int value=0;
  
    //evaluation du materiel
    value+=bbtk->popCnt(p->w_pawn)<<7;//*100;
    value+=bbtk->popCnt(p->w_knight)*448;
    value+=bbtk->popCnt(p->w_bishop)*448;
    value+=bbtk->popCnt(p->w_rook)*640;
    value+=bbtk->popCnt(p->w_queen)*1152;
    //value+=bbtk->popCnt(p->w_occupied^p->w_pawn^p->w_knight^p->w_bishop^p->w_rook^p->w_queen)<<14;//_*16000 *20000;
    
    value-=bbtk->popCnt(p->b_pawn)<<7;//*100;
    value-=bbtk->popCnt(p->b_knight)*448;
    value-=bbtk->popCnt(p->b_bishop)*448;
    value-=bbtk->popCnt(p->b_rook)*640;
    value-=bbtk->popCnt(p->b_queen)*1152;
    //value-=bbtk->popCnt(p->b_occupied^p->b_pawn^p->b_knight^p->b_bishop^p->b_rook^p->b_queen)<<14;//_*16000 *20000;
    
    return value;
}
