/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adoplh Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project relised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info:
     jeff@proxone.net
*/

#ifndef CASSANDRE_HASHTABLEELEMENT_H
#define CASSANDRE_HASHTABLEELEMENT_H 1

#define    HASHSIZE 1024*1024
#define    hashfEXACT   0
#define    hashfALPHA   1
#define    hashfBETA    2

class HashTableElement {

  public:
      bitboard key;
      int depth;
      
      /*
      a flag that indicates what the value means
      for example if we store 16 n the value field
      0 means that the value of the node was exactly 16
      1 means that the value of the node was at most 16
      2 means that the value of the node was at least 16
      */
      int flags;
       
      int value;
      Move best;

};
#endif
