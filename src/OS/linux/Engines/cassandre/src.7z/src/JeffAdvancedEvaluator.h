/*
 *  JeffAdvancedEvaluator.h
 *  Cassandre
 *
 *  Created by Jeff on Tue Nov 19 2002.
 *  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
 *
 */


#ifndef CASSANDRE_JEFF_ADV_EVALUATOR_H
#define CASSANDRE_JEFF_ADV_EVALUATOR_H 1

#include "Position.h"
/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adolph Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project realised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info: 
     jeff@proxone.net
*/

#include "BitboardToolkit.h"
#include "Evaluator.h"
#include "MoveGenerator.h"

class JeffAdvancedEvaluator : public Evaluator
{
    public:
        JeffAdvancedEvaluator()
        {
            moveGenerator=new MoveGenerator();
            bitMask=BitboardToolkit::instance()->bitMask;
        }
        int evaluate(Position *p);
        
    private:
        bitboard *bitMask;
        MoveGenerator *moveGenerator;
        int evaluateOpening(Position *p);
        int evaluateMiddle(Position *p);
        int evaluateEnd(Position *p);
        
        const static int bonus_bishop[64];
        const static int bonus_knight[64];
        const static int bonus_black_pawn[64];
        const static int bonus_white_pawn[64];
        const static int bonus_black_king[64];
        const static int bonus_white_king[64];
        const static int bonus_end_king[64];
        
        //const static bitboard bitMask[64]; //masques 1 bit
};

#endif
