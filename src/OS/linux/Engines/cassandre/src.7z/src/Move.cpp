/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adolph Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project realised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info: 
     jeff@proxone.net
*/

#include "Move.h"

const unsigned int Move::moveMask=0x3F;
const unsigned int Move::captureMask=0x100000;
const unsigned int Move::promotionMask=0x200000;
const unsigned int Move::pieceMask=0x0F;
const unsigned int Move::wQCastleMask=0x400000;
const unsigned int Move::wKCastleMask=0x800000;
const unsigned int Move::bQCastleMask=0x1000000;
const unsigned int Move::bKCastleMask=0x2000000;
const unsigned int Move::isEnPassantCaptureMask=0x4000000;
//const unsigned int Move::breaksPawnAdvanceMask=0x8000000;
