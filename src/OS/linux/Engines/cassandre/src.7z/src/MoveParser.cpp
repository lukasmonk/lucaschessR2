/* This file is part of Cassandre.
   Copyright (c) 2003 Romang Jean-Fran�ois, Adolph Thomas, Grundrich Raphael

   Cassandre is based on the DessChess program, a student project realised at
   University Louis Pasteur in Strasbourg, France ; under the direction of
   professor J.Korczak.

   Cassandre is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   Cassandre is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cassandre; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Contact Info: 
     jeff@proxone.net
*/

#include "MoveParser.h"

const char MoveParser::squareName[64][3]={  "h8","g8","f8","e8","d8","c8","b8","a8",
                                            "h7","g7","f7","e7","d7","c7","b7","a7",
                                            "h6","g6","f6","e6","d6","c6","b6","a6",
                                            "h5","g5","f5","e5","d5","c5","b5","a5",
                                            "h4","g4","f4","e4","d4","c4","b4","a4",
                                            "h3","g3","f3","e3","d3","c3","b3","a3",
                                            "h2","g2","f2","e2","d2","c2","b2","a2",
                                            "h1","g1","f1","e1","d1","c1","b1","a1"};
