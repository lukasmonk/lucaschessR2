pub type Node = u8;
pub const NORMAL_NODE: Node = 0;
pub const ROOT_NODE: Node = 2;
