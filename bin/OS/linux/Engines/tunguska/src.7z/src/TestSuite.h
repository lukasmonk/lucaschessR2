#ifndef TESTS_H
#define TESTS_H

#include <string>


class TestSuite{
	public:
		static void runFile(std::string file, int movetime);
};

#endif