#include <assert.h>
#include <stdio.h>
#include <math.h>
#include "rodent.h"
#include "eval.h"

U64 BITSET[64];

int limit_distance;


void InitEvalCub(void) {
    BITSET[0] = 1;
    for (int i = 1; i < 64; i++)
    {
        BITSET[i] = BITSET[i - 1] << 1;
    }
    last_sq = 28;
    limit_distance = 400;
}

int distance_lastsq(int from_sq)
{
  int df, dc;
  int ls;

  df = from_sq/8 - last_sq/8;
  dc = from_sq%8 - last_sq%8;

  return (int) (sqrt(df*df + dc*dc)*100.0);
}



int evalpiecescub(U64 bitmap, int default_score)
{
  int sq;
  int score;
  int distance;

  score = 0;
  while(bitmap) {
    sq = FirstOne(bitmap);
    distance = distance_lastsq(sq);
    if( distance < limit_distance )
      score += default_score;
    bitmap ^= BITSET[sq];
  }
  return score;
}

int EvaluateMaterialSideCub(const POS *p, int sd) {

  U64 bbPieces;
  int scoret = 0;

  bbPieces = PcBb(p, sd, N);
  scoret = evalpiecescub(bbPieces, 3);
  bbPieces = PcBb(p, sd, B);
  scoret += evalpiecescub(bbPieces, 3);
  bbPieces = PcBb(p, sd, R);
  scoret += evalpiecescub(bbPieces, 5);
  bbPieces = PcBb(p, sd, Q);
  scoret += evalpiecescub(bbPieces, 9);
  bbPieces = PcBb(p, sd, P);
  scoret += evalpiecescub(bbPieces, 1);
  bbPieces = PcBb(p, sd, K);
  scoret += PopCnt(bbPieces)*30000;

  return scoret;
}

int EvaluateCub(POS *p) {

  // Try to retrieve score from eval hashtable

  int score = EvaluateMaterialSideCub(p, WC) - EvaluateMaterialSideCub(p, BC);


  if (score < -MAX_EVAL)
    score = -MAX_EVAL;
  else if (score > MAX_EVAL)
    score = MAX_EVAL;

  // Return score relative to the side to move
  return p->side == WC ? score : -score;
}
