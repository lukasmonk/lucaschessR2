/**************************************************************************************************
  File : uci.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "uci".
**************************************************************************************************/

#ifndef UCI_H
#define UCI_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Fonctions externes du module : */
typedef struct {

  void (*debug_command) (void);
  void (*go) (char string[]);
  void (*info) (int score);
  void (*isready) (void);
  void (*ponderhit) (void);
  void (*position) (char string[]);
  void (*quit) (int return_code);
  void (*registration) (void);
  void (*setoption) (char string[]);
  void (*stop) (void);
  void (*uci_command) (void);
  void (*ucinewgame) (void);

} uci_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern uci_module_s uci;

extern bool uci_infinite;

extern int uci_binc;
extern int uci_btime;
extern int uci_movestogo;
extern int uci_winc;
extern int uci_wtime;

#endif /* UCI_H */
