/**************************************************************************************************
  File : data.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour les donn�es globales.
**************************************************************************************************/

#ifndef DATA_H
#define DATA_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des donn�es g�n�rales du programme : */
#include "main.h"

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "moves.h"

/**************************************************************************************************
  Macro-instructions :
**************************************************************************************************/

#define CASTLE_STATUS   castle_status[game_ply]
#define EP_SQUARE       ep_square[game_ply]
#define PIECE(x)        (x == BPAWN   || x == WPAWN   ? 'p' : \
                         x == BBISHOP || x == WBISHOP ? 'b' : \
                         x == BKNIGHT || x == WKNIGHT ? 'n' : \
                         x == BROOK   || x == WROOK   ? 'r' : \
                         x == BQUEEN  || x == WQUEEN  ? 'q' : \
                         x == BKING   || x == WKING   ? 'k' : ' ')
#define RR(c)           (reverse_rank[color][c])
#define SQUARE          ((y + 1) * 10 + x)

#define max(a,b)        (a >= b ? a : b)
#define min(a,b)        (a <= b ? a : b)

/* Macro-instructions permettant l'�tude du fonctionnement du programme : */
#define CM   if (use_captured)
#define HH   if (use_history)
#define KM   if (use_killers)
#define TT   if (use_ttable)

/**************************************************************************************************
  Data :
 (Pour la description des donn�es, voir le fichier data.c)
**************************************************************************************************/

extern FILE *log_file;

extern bool blind_game;
extern bool forced_mode;
extern bool search_on_depth;
extern bool show_board;
extern bool uci_mode;
extern bool use_book;
extern bool use_captured;
extern bool use_history;
extern bool use_killers;
extern bool use_log;
extern bool use_null_move;
extern bool use_pv;
extern bool use_ttable;

extern char black_book_path[STRING_LENGTH];
extern char lan_games_file_path[STRING_LENGTH];
extern char pgn_games_file_path[STRING_LENGTH];
extern char start_position[STRING_LENGTH];
extern char white_book_path[STRING_LENGTH];

extern clock_t start_thinking_time;

extern const int castle_by_color_mask[2];
extern const int castle_done_mask[2];
extern const int castle_possible_mask[2];
extern const int file[BOARD_SIZE];
extern const int pieces_value[7];
extern const int rank[BOARD_SIZE];
extern const int reverse_rank[2][9];

extern int active_color;
extern int base_time;
extern int board[BOARD_SIZE];
extern int castle_status[MAX_MOVES * 2];
extern int computer_color;
extern int elapsed_time_ms;
extern int ep_square[MAX_MOVES * 2];
extern int fullmove;
extern int game_ply;
extern int halfmove;
extern int halfmove_history[MAX_MOVES * 2];
extern int iterative_depth;
extern int king[2];
extern int max_book_ply;
extern int max_iterative_depth;
extern int max_search_time;
extern int min_iterative_depth;
extern int moved[BOARD_SIZE];
extern int nodes;
extern int piece_count;
extern int pieces[2][17];
extern int pieces_number[2];
extern int *pieces_ptr[BOARD_SIZE];
extern int pv_length[MAX_SEARCH_PLY];
extern int repeats;
extern int result;
extern int search_ply;
extern int start_piece_count;
extern int time_for_move;
extern int time_in_console_mode;

extern move_s dummy;
extern move_s played_moves[MAX_MOVES * 2];
extern move_s pv[MAX_SEARCH_PLY][MAX_SEARCH_PLY];

#endif /* DATA_H */
