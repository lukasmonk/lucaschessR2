/**************************************************************************************************
  File : search.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Module de recherche.

  La recherche s'appuie sur les algorithmes et techniques suivants :
    - algorithme min-max avec simplification nega-max
    - �lagage alpha-beta,
    - approfondissement iteratif,
    - recherche des positions calmes pour �viter l'effet d'horizon (quiescence search),
    - tri des coups (move ordering) avec l'utilisation :
        . des captures,
        . coups qui tuent (killer moves) ou coups remarquables,
        . heuristique de l'historique (history heuristic),
        . le coup �ventuel issu de la variante principale,
        . le coup �ventuel issu de la table de transposition,
    - table de transposition,
    - coup nul (null move algorithm)
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "book.h"
#include "debug.h"
#include "evaluate.h"
#include "hash.h"
#include "moves.h"
#include "search.h"
#include "tools.h"
#include "ttable.h"
#include "uci.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

typedef struct {

  int score1;
  int score2;

  int moveid1;
  int moveid2;
  int moveid3;

} killer_move_s;

/**************************************************************************************************
  Macro-instructions :
**************************************************************************************************/

/* Prise en compte d'un coup dans la variante principale. */
#define UPDATE_PV { \
  pv[search_ply][search_ply] = moves_list[i]; \
  for (int j = search_ply + 1; j < pv_length[search_ply + 1]; j++) { \
    pv[search_ply][j] = pv[search_ply + 1][j]; \
  } \
  pv_length[search_ply] = pv_length[search_ply + 1]; \
}

/**************************************************************************************************
  Data :
**************************************************************************************************/

/* Indique si la recherche doit continuer dans le cas d'une chute du score. */
bool continue_to_search;

/* Indique la fin de la recherche � la demande du programme. */
bool end_of_search;

/* M�morise le fait que la recherche doit s'arr�ter par manque de temps. */
bool end_of_time;

/* Pour privil�gier la recherche de la variante principale. */
bool follow_pv;

/* Indique que le score diminue dangereusement par rapport au dernier coup. */
bool score_falling;

/* Indique que la recherche est interrompue sans qu'un coup ne soit trouv�. */
bool search_failure;

/* Pour m�moriser les coups qui ont provoqu� un �lagage de l'arbre. Indic� sur les cases de d�part
   et d'arriv�e. */
int history_heuristic[BOARD_SIZE][BOARD_SIZE];

/* Pour m�moriser le score du dernier coup s�lectionn�. */
int selected_move_score;

/* Coups remarquables � l'origine d'un �lagage alpha ou beta. */
killer_move_s killers[MAX_SEARCH_PLY];

/**************************************************************************************************
  Internal functions prototypes :
**************************************************************************************************/

void apply_heuristics (move_s *move, int tt_moveid);
int first_search (int depth, int alpha, int beta);
int pick_move (move_s *moves_list, int moves_number);
int quiescence_search (int alpha, int beta);
int search (int depth, int alpha, int beta, bool do_null_move);
void sort_moves (move_s *moves_list, int moves_number, int tt_moveid);
void update_killers (int moveid, int score);

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : is_repeated
  Description  : Recherche si la position courante se retrouve pour la 3�me fois sur l'�chiquier
                 depuis le d�but de la partie, auquel cas la partie est nulle par r�p�tition.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
bool is_repeated (void) {                                                                          DBG_IS_REPEATED_CALL

  /* Pour le moment aucune r�p�tition n'est d�tect�e. */
  repeats = 0;

  /* La recherche n'a de sens que si au moins 6 demi-coups ont �t� jou�s. */
  if (halfmove >= 6) {

    /* La recherche se poursuit tous les 2 demi-coups jusqu'au dernier d�placement de pion ou la
       derni�re capture. */
    for (int i = game_ply - 2; i >= game_ply - halfmove; i -= 2) {

      /* La comparaison des positions se fait avec leur valeur de hachage. */
      if (h_position == h_position_history[i]) {

        repeats++;
      }

      /* Si la position est retrouv�e deux autres fois, */
      if (repeats >= 2) {                                                                          DBG_IS_REPEATED_END_1

        /* alors la partie est nulle. */
        return true;
      }
    }
  }                                                                                                DBG_IS_REPEATED_END_2

  return false;
}
/* End of function : is_repeated */

/**************************************************************************************************
  Function     : start
  Description  : Initialisation de la r�flexion du programme.
  Parameters   : out - coup calcul� par le programme
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void start (move_s *move) {                                                                        DBG_START_CALL

/* --- Local data ------------------------------------------------------------------------------ */DBG_SEARCH_TREE_0

int score;         /* Score remont� par l'analyse pour une profondeur donn�e. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Calcule le temps allou� � la r�flexion du programme. */
  tools.compute_time ();

  /* Le nombre des noeuds calcul�s est remis � z�ro. */
  nodes = 0;

  /* Autorise � poursuivre la recherche si le score devient trop mauvais. */
  continue_to_search = true;

  /* Pour le moment le programme n'a pas de raison d'arr�ter la recherche. */
  end_of_search = false;

  /* Efface la pr�c�dente heuristique des �lagages alpha-beta. */
  memset (history_heuristic, 0, sizeof (history_heuristic));

  /* Efface la pr�c�dente variante principale. */
  memset (pv, 0, sizeof (pv));

  /* Efface les pr�c�dents coups remarquables qui ne sont plus valables pour des niveaux de
     r�flexion sup�rieurs. */
  for (int i = 0; i < MAX_SEARCH_PLY; i++) {

    killers[i].score1 = -INF;
    killers[i].score2 = -INF;

    killers[i].moveid1 = 0;
    killers[i].moveid2 = 0;
    killers[i].moveid3 = 0;
  }

  /* M�morise le nombre de pi�ces pr�sentes sur l'�chiquier au d�but de la recherche. */
  start_piece_count = piece_count;

  /* La recherche commence en augmentant progressivement la profondeur de r�flexion, la limite se
     fera principalement sur le temps. */
  for (iterative_depth = 1; iterative_depth <= max_iterative_depth; iterative_depth++) {

    /* Calcul du temps �coul� depuis le d�but de la r�flexion. */
    elapsed_time_ms = (int) ((clock () - start_thinking_time) * 1000 / (double) CLOCKS_PER_SEC);

    /* Si le temps pass� est trop important ou que le programme a d�j� un coup, */
    if (   (   elapsed_time_ms > time_for_move
            && iterative_depth > min_iterative_depth)
        || end_of_search) {

      /* alors la r�flexion est interrompue. */
      break;
    }

    /* R�initialisation des indicateurs sur le fonctionnement de la recherche. */
    end_of_time    = false;
    follow_pv      = use_pv;
    score_falling  = false;
    search_failure = false;

    /* Lance la recherche � la racine de l'arbre. */
    score = first_search (iterative_depth, -INF, INF);

    /* Si la recherche n'est pas suffisamment pertinente par manque de temps, */
    if (!search_failure) {

      /* alors le coup trouv� est celui � prendre en compte pour le moment. */
      *move = pv[1][1];

      /* M�morise le score du coup s�lectionn�. */
      selected_move_score = score;

      /* Le programme va tenter de trouver les coups de la variante principale dans la table de
         transposition. */
      TT ttable.search_tt_pv (iterative_depth);

      /* Si la profondeur de r�flexion est suffisamment int�ressante, */
      if (iterative_depth >= min_iterative_depth) {

        /* alors le programme affiche des informations sauf en cas de jeu � l'aveugle. */
        if (!blind_game) uci.info (score);
      }
    }                                                                                              DBG_SEARCH_TREE_1

    /* Efface les scores des pr�c�dents coups remarquables. Les coups seront conserv�s pour les
       phases de tri � des niveaux de recherche plus �lev�s. */
    for (int i = 0; i < MAX_SEARCH_PLY; i++) {

      killers[i].score1 = -INF;
      killers[i].score2 = -INF;
    }
  }
}
/* End of function : start */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/

search_module_s search_module = {

  is_repeated,
  start
};

/**************************************************************************************************
  Internal functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : apply_heuristics
  Description  : Pour noter les coups, cette fonction tiendra compte :
                   - des captures (ainsi que de la valeur de la capture),
                   - d'un �ventuel coup issu de la table de transposition,
                   - des coups remarquables (killer moves),
                   - de l'historique des coupures alpha et beta.
  Parameters   : in  - coup � analyser
                 in  - identifiant d'un coup issu de la table de transposition
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void apply_heuristics (move_s *move, int tt_moveid) {                                              DBG_APPLY_HEURISTICS_CALL

  /* Le programme favorise les captures, */
  if (move->captured) {

    /* en tenant compte de l'�cart entre les valeurs des pi�ces. */
    CM move->note +=  pieces_value[move->captured & 0x7]
                    - pieces_value[board[move->from] & 0x7] + 1000;                                DBG_HEURISTIC_1
  }

  /* Si le coup correspond � un coup issu de la table de transposition, */
  if (move->moveid == tt_moveid) {

    /* alors sa note est tr�s importante, moindre cependant qu'un de ceux faisant partie de la
       variante principale. */
    move->note += INF - 10000;                                                                     DBG_HEURISTIC_2
  }

  /* Le programme favorise les coups remarquables trouv�s au m�me niveau de l'arbre. */
  KM {
    if (move->moveid == killers[search_ply].moveid1) {

      move->note += 900;                                                                           DBG_HEURISTIC_3
    }
    else if (move->moveid == killers[search_ply].moveid2) {

      move->note += 600;                                                                           DBG_HEURISTIC_4
    }
    else if (move->moveid == killers[search_ply].moveid3) {

      move->note += 300;                                                                           DBG_HEURISTIC_5
    }
  }

  /* Le programme favorise enfin les coups qui ont provoqu� des coupures en se basant uniquement
     sur les cases de d�part et d'arriv�e. La valeur de la note est inversement proportionnelle �
     la profondeur atteinte dans la recherche. */
  HH move->note += history_heuristic[move->from][move->to] >> iterative_depth;                     DBG_HEURISTIC_6
}
/* End of function : apply_heuristics */

/**************************************************************************************************
  Function     : first_search
  Description  : Cette fonction est appel�e pour parcourir les coups situ�s au premier niveau de
                 l'arbre.
  Parameters   : in  - profondeur de r�flexion atteinte
                 in  - borne alpha
                 in  - borne beta
  Return value : score
  Validation   : 1
**************************************************************************************************/
int first_search (int depth, int alpha, int beta) {                                                DBG_FIRST_SEARCH_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int analyzed_branches = 0;        /* Nombre de branches analys�es � partir du noeud courant. */
int i;                            /* Pour parcourir la liste des coups g�n�r�s. */
int legal_moves = 0;              /* Nombre de coups l�gaux dans la position. */
int moves_number;                 /* Nombre de coups g�n�r�s. */
int score = -INF;                 /* Score de la branche analys�e. */
int search_extension = 0;         /* Poursuite de la recherche en cas d'�chec. */
int tt_flag = 0;                  /* Indicateur pour la recherche (inutilis�). */
int tt_moveid = 0;                /* Identifiant d'un coup issu de la table de transposition. */

move_s moves_list[MAX_MOVES];     /* Pour ranger les coups g�n�r�s. */

/* --- Function code --------------------------------------------------------------------------- */DBG_FIRST_SEARCH_START

  /* Si la position courante se retrouve pour la troisi�me fois depuis le d�but de la partie, */
  if (search_module.is_repeated ()) {

    /* le r�sultat de la partie est nul, */
    result = DRAW_REPETITION;

    /* la longueur de la variante principale est mise � z�ro, */
    pv_length[1] = 0;

    /* et aucun coup ne sera s�lectionn�. */
    pv[1][1] = dummy;

    /* Le score remont� est nul. */
    return 0;
  }

  /* D�finit la longueur de la variante principale qui augmentera � chaque niveau de l'arbre. */
  pv_length[1] = 1;

  /* Initialise le nombre de demi-coups dans la descente de l'arbre. */
  search_ply = 1;

  /* Si la position est pr�sente dans la table de transposition, le meilleur coup associ� servira
     dans la phase de tri. */
  TT ttable.read_ttable (depth, alpha, beta, &tt_flag, &tt_moveid);

  /* Si le roi est attaqu�, */
  if (moves.is_attacked (king[active_color], active_color ^1)) {

    /* alors la recherche sera prolong�e. */
    search_extension++;
  }

  /* G�n�ration des coups possibles dans la position courante. */
  moves_number = moves.generate (moves_list, false);

  /* Tri des coups pour analyser en premier les plus int�ressants. */
  sort_moves (moves_list, moves_number, tt_moveid);

  /* Parcours des coups possibles dans l'ordre du tri pr�c�dent. */
  while ((i = pick_move (moves_list, moves_number))) {

    /* Le coup consid�r� est jou� sur l'�chiquier, */
    moves.make (&moves_list[i]);
    search_ply++;

    /* mais s'il n'est pas l�gal, */
    if (!moves.is_legal (&moves_list[i])) {

      /* la position pr�c�dente est replac�e sur l'�chiquier. */
      search_ply--;
      moves.unmake (&moves_list[i]);

      /* et le programme continue avec le coup suivant. */
      continue;
    }
    else {

      legal_moves++;
    }

    /* Un nouveau noeud de l'arbre est atteint. */
    nodes++;                                                                                       DBG_SEARCH_TREE_2('f')

    /* L'analyse est poursuivie au niveau suivant de l'arbre. */
    score = -search (depth - 1 + search_extension, -beta, -alpha, use_null_move);                  DBG_SEARCH_TREE_3

    if (end_of_time) {

      /* Si la recherche n'est pas suffisamment avanc�e, */
      if (analyzed_branches < 6 && analyzed_branches < moves_number / 3) {

        /* alors une alerte est lev�e */
        search_failure = true;

        if (uci_mode && analyzed_branches) {

          tools.send_output (true, "info string search stopped (depth %d : analyzed %d/%d)\n",
            iterative_depth, analyzed_branches, moves_number);
        }
      }
    }

    /* Une nouvelle branche de l'arbre a �t� parcourue. */
    analyzed_branches++;

    /* La position pr�c�dente est replac�e sur l'�chiquier. */
    search_ply--;
    moves.unmake (&moves_list[i]);

    /* En manque de temps, le programme remonte la borne alpha actuelle. */
    if (end_of_time) return alpha;

    /* Si l'�valuation est sup�rieure � la pr�c�dente, */
    if (score > alpha) {

      /* L'int�r�t du coup trouv� augmente pour un prochain tri, */
      HH history_heuristic[moves_list[i].from][moves_list[i].to] += depth;                         DBG_HISTORY_HEURISTIC("first_search");

      /* et le programme v�rifie les coups remarquables. */
      KM update_killers (moves_list[i].moveid, score);

      /* Si le score chute dangereusement par rapport au score du dernier coup s�lectionn�, */
      if (score < (selected_move_score - 50)) {

        /* alors l'information est m�moris�e pour �ventuellement continuer la recherche. */
        score_falling = true;
      }

      /* La position est rang�e dans la table de transposition. */
      TT ttable.write_ttable (depth, EXACT_SCORE, score, moves_list[i].moveid);

      /* L'�valuation obtenue devient la nouvelle r�f�rence. */
      alpha = score;

      /* Mise � jour de la variante principale. */
      UPDATE_PV

      /* Si la r�flexion est suffisamment pertinente, */
      if (iterative_depth >= min_iterative_depth) {

        /* alors le programme affiche des informations sauf en cas de jeu � l'aveugle. */
        if (!blind_game) uci.info (alpha);
      }
    }
  }

  /* Si aucune branche n'a pu �tre analys�e, c'est qu'il n'existe pas de coup l�gal. */
  if (!analyzed_branches) {

    /* Si le roi est attaqu� par la couleur adverse, */
    if (moves.is_attacked (king[active_color], active_color^1)) {

      /* c'est qu'il y a �chec et mat, le r�sultat est d�j� d�termin�. */
      result = active_color ? WHITE_IS_MATED : BLACK_IS_MATED;

      /* Le score remont� indiquera le nombre de demi-coups avant le mat. */
      alpha = - MATE + search_ply;
    }
    /* sinon, */
    else {

      /* c'est que la partie est nulle (pat), le r�sultat est d�j� d�termin�. */
      result = DRAW_STALEMATE;

      /* Le score remont� indiquera l'�galit�. */
      alpha = 0;
    }
  }
  else {

    /* Si la r�gle des 50 coups s'applique, */
    if (halfmove >= 100) {

      /* c'est que la partie est nulle, le r�sultat est d�j� d�termin�. */
      result = DRAW_FIFTY_MOVES;

      /* La longueur de la variante principale est mise � z�ro, */
      pv_length[1] = 0;

      /* et aucun coup ne sera s�lectionn�. */
      pv[1][1] = dummy;

      /* Le score remont� indiquera l'�galit�. */
      alpha = 0;
    }

    /* S'il n'existe qu'un seul coup l�gal, */
    if (legal_moves == 1) {

      /* la recherche s'arr�tera au premier niveau de l'arbre pour �viter de perdre du temps. */
      end_of_search = true;
    }
  }

  /* Cherche si l'adversaire du programme est mat, */
  if (score == (MATE - 2)) {

    /* pour positionner le r�sultat de la partie. */
    result = active_color ? BLACK_IS_MATED : WHITE_IS_MATED;
  }

  return alpha;
}
/* End of function : first_search */

/**************************************************************************************************
  Function     : pick_move
  Description  : A chaque appel, cette fonction retourne le num�ro du coup ayant la meilleure note
                 obtenue lors du tri de la liste des coups g�n�r�s pour la position courante.
  Parameters   : in  - liste des coups g�n�r�s
                 in  - nombre des coups de cette liste
  Return value : num�ro du meilleur coup dans la liste en entr�e
  Validation   : 1
**************************************************************************************************/
int pick_move (move_s *moves_list, int moves_number) {                                             DBG_PICK_MOVE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int best_note = -1;     /* Pour ranger la meilleure note des coups de la liste; la valeur -1
                           indique que le coup n'est plus � prendre en compte pour le prochain
                           appel � la fonction. */
int move = 0;           /* Le coup 0 n'existe pas, il indiquera la fin de la recherche. */

/* --- Function code --------------------------------------------------------------------------- */

  for (int i = 1; i <= moves_number; i++) {

    if (moves_list[i].note > best_note) {

      best_note = moves_list[i].note;
      move = i;
    }
  }

  moves_list[move].note = -1;                                                                      DBG_PICK_MOVE_END

  return move;
}
/* End of function : pick_move */

/**************************************************************************************************
  Function     : quiescence_search
  Description  : Le but de cette recherche est de n'�valuer que des positions
                 "calmes" sans coup tactique gagnant, autrement dit sans capture
                 possible. Elle est n�cessaire pour �viter l'effet d'horizon.
  Parameters   : in  - borne alpha
                 in  - borne beta
  Return value : limite inf�rieure de l'�valuation
  Validation   : 1
**************************************************************************************************/
int quiescence_search (int alpha, int beta) {                                                      DBG_QUIESCENCE_SEARCH_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int i;                            /* Num�ro du coup dans la liste des coups g�n�r�s. */
int moves_number;                 /* Nombre de coups g�n�r�s. */
int score;                        /* Score de la branche analys�e. */
int stand_pat;                    /* Evaluation de la position � l'appel de la fonction. */

move_s moves_list[MAX_MOVES];     /* Pour ranger tous les coups g�n�r�s. */

/* --- Function code --------------------------------------------------------------------------- */DBG_QUIESCENCE_SEARCH_START

  /* Au d�but de la recherche, l'�valuation de la position est utilis�e pour �tablir une limite
     inf�rieure (lower bound) du score. On peut esp�rer trouver un coup qui atteindra voire
     d�passera cette limite. */
  stand_pat = evaluate.evaluate_position ();

  /* Si cette limite est d�j� sup�rieure ou �gale � beta, */
  if (stand_pat >= beta) {

    /* alors le programme retourne l'�valuation obtenue (fail-soft). */
    return stand_pat;
  }

  /* Sinon la recherche continue en gardant l'�valuation faite comme limite inf�rieure si elle
     d�passe alpha. */
  if (stand_pat > alpha) alpha = stand_pat;

  /* Le programme va d�sormais chercher un coup tactique (une capture) qui augmentera alpha. */

  pv_length[search_ply] = search_ply;

  moves_number = moves.generate (moves_list, true);
  sort_moves (moves_list, moves_number, 0);

  while ((i = pick_move (moves_list, moves_number))) {

    moves.make (&moves_list[i]);
    search_ply++;

    if (!moves.is_legal (&moves_list[i])) {

      search_ply--;
      moves.unmake (&moves_list[i]);

      continue;
    }

    nodes++;                                                                                       DBG_SEARCH_TREE_2('q')

    score = - quiescence_search (-beta, -alpha);                                                   DBG_SEARCH_TREE_3

    search_ply--;
    moves.unmake (&moves_list[i]);

    if (score >= beta) {

      KM update_killers (moves_list[i].moveid, score);

      return beta;
    }

    if (score > alpha) {

      alpha = score;

      UPDATE_PV
    }
  }

  return alpha;
}
/* End of function : quiescence_search */

/**************************************************************************************************
  Function     : search
  Description  : Cette fonction est appel�e r�cursivement pour parcourir l'arbre des positions.
  Parameters   : in  - profondeur de r�flexion courante
                 in  - borne alpha
                 in  - borne beta
                 in  - indique si l'algorithme "null move" doit �tre utilis�
  Return value : nouvelle borne alpha
  Validation   : 1
**************************************************************************************************/
int search (int depth, int alpha, int beta, bool do_null_move) {                                        DBG_SEARCH_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int analyzed_branches = 0;        /* Nombre de branches analys�es � partir du noeud courant. */
int i;                            /* Pour parcourir la liste des coups g�n�r�s. */
int initial_alpha;                /* Pour m�moriser une �volution de la borne alpha. */
int moves_number;                 /* Nombre de coups g�n�r�s. */
int score = -INF;                 /* Score de la branche analys�e. */
int search_extension = 0;         /* Poursuite de la recherche en cas d'�chec. */
int tt_flag = NO_TT_INFO;         /* Indicateur pour la recherche. */
int tt_moveid = 0;                /* Identifiant d'un coup issu de la table de transposition. */

move_s moves_list[MAX_MOVES];     /* Pour ranger les coups g�n�r�s. */

/* --- Function code --------------------------------------------------------------------------- */DBG_SEARCH_START

  /* Si la profondeur de r�flexion est significative, tous les 2**14 noeuds, */
  if (iterative_depth > min_iterative_depth && !(nodes & 16383)) {

    /* alors le temps �coul� depuis le d�but de la r�flexion est calcul�. */
    elapsed_time_ms = (int) ((clock () - start_thinking_time) * 1000 / (double) CLOCKS_PER_SEC);

    /* Si le temps octroy� pour le coup est d�pass�, */
    if (elapsed_time_ms > time_for_move) {

      /* et si le score du programme chute dangereusement, */
      if (score_falling && continue_to_search) {

        /* une fois seulement, */
        continue_to_search = false;

        /* et si le programme n'est pas en manque de temps, */
        if (   ((computer_color ? uci_wtime : uci_btime) > (6 * time_for_move))
            || (uci_movestogo > 4)) {

          /* la r�flexion sera poursuivie, */
          time_for_move *= 2;
        }
        else {

          /* sinon la r�flexion du programme sera interrompue. */
          end_of_time = true;
          return 0;
        }
      }
      else {

        /* sinon la r�flexion du programme sera interrompue. */
        end_of_time = true;
        return 0;
      }
    }
  }

  /* Si la position courante se retrouve pour la troisi�me fois depuis le d�but de la partie, */
  if (search_module.is_repeated ()) {

    /* le score remont� est nul. */
    return 0;
  }

  /* D�finit la longueur de la variante principale qui augmente � chaque niveau de l'arbre. */
  pv_length[search_ply] = search_ply;

  /* Recherche si une information peut �tre exploit�e dans la table de transposition. */
  TT score = ttable.read_ttable (depth, alpha, beta, &tt_flag, &tt_moveid);
  switch (tt_flag) {

    case EXACT_SCORE     : return (score);
    case LOWER_BOUND     : return (beta);
    case UPPER_BOUND     : return (alpha);
    case AVOID_NULL_MOVE : do_null_move = false;
  }

  /* M�morise alpha au cas ou une am�lioration de sa valeur serait int�ressante � enregistrer dans
     la table de transposition. */
  initial_alpha = alpha;

  /* Si le roi est attaqu�, tout en �vitant l'�chec perp�tuel, */
  if (   moves.is_attacked (king[active_color], active_color ^1)
      && search_ply <= max_iterative_depth) {

    /* alors la recherche sera prolong�e. */
    search_extension++;
  }
  /* sinon le roi n'est pas en �chec, */
  else {

    /* le programme v�rifie alors si l'algorithme "null move" doit �tre utilis�. Un nombre
       cons�quent de pi�ces en jeu permettra d'�viter les cas de zugzwang. */
    if (do_null_move && piece_count > 4 && depth > R) {

      active_color ^= 1;
      game_ply++;
      halfmove++;
      search_ply++;

      CASTLE_STATUS = castle_status[game_ply - 1];
      EP_SQUARE = ep_square[game_ply - 1];

      h_position ^= h_values_ep[EP_SQUARE];
      h_position ^= h_values_ep[0];
      h_position ^= h_values_color[BLACK];
      h_position ^= h_values_color[WHITE];

      h_position_history[game_ply] = h_position;

      EP_SQUARE = 0;

      score = -search (depth - R - 1, -beta, -beta + 1, false);

      active_color ^= 1;
      game_ply--;
      halfmove--;
      search_ply--;

      h_position = h_position_history[game_ply];

      if (end_of_time) {

        return 0;
      }

      if (score >= beta) {

        return beta;
      }
    }
  }

  /* Si la profondeur de r�flexion atteint la limite, */
  if (!(depth + search_extension)) {

    /* alors le programme recherche une situation calme, */
    /* avant de remonter l'�valuation de la position obtenue. */
    return quiescence_search (alpha, beta);
  }

  /* G�n�ration des coups possibles dans la position courante. */
  moves_number = moves.generate (moves_list, false);

  /* Tri des coups pour analyser en premier les plus int�ressants. */
  sort_moves (moves_list, moves_number, tt_moveid);

  /* Parcours des coups g�n�r�s dans l'ordre du tri pr�c�dent. */
  while ((i = pick_move (moves_list, moves_number))) {

    /* Le coup consid�r� est jou� sur l'�chiquier, */
    moves.make (&moves_list[i]);
    search_ply++;

    /* mais s'il n'est pas l�gal, */
    if (!moves.is_legal (&moves_list[i])) {

      /* la position pr�c�dente est replac�e sur l'�chiquier. */
      search_ply--;
      moves.unmake (&moves_list[i]);

      /* et le programme continue avec le coup suivant. */
      continue;
    }

    /* Sinon un nouveau noeud de l'arbre est atteint. */
    nodes++;                                                                                       DBG_SEARCH_TREE_2('s')

    /* et l'analyse est poursuivie au niveau suivant de l'arbre. */
    score = -search (depth - 1 + search_extension, -beta, -alpha, use_null_move);                  DBG_SEARCH_TREE_3

    /* Une nouvelle branche de l'arbre a �t� parcourue. */
    analyzed_branches++;

    /* La position pr�c�dente est replac�e sur l'�chiquier. */
    search_ply--;
    moves.unmake (&moves_list[i]);

    /* Si le temps octroy� pour la r�flexion est d�pass�, */
    if (end_of_time) {

      /* alors on arr�te la recherche. */
      return 0;
    }

    /* Si l'�valuation est sup�rieure � la pr�c�dente, */
    if (score > alpha) {

      /* alors l'int�r�t du coup trouv� augmente pour un prochain tri, */
      HH history_heuristic[moves_list[i].from][moves_list[i].to] += depth;                         DBG_HISTORY_HEURISTIC("search");

      /* S'il y a une coupure beta, */
      if (score >= beta) {

        /* le programme v�rifie les coups remarquables. */
        KM update_killers (moves_list[i].moveid, score);

        /* la position est m�moris�e dans la table de transposition. */
        TT ttable.write_ttable (depth, LOWER_BOUND, score, moves_list[i].moveid);

        /* Rien ne sert de continuer � analyser les autres coups situ�s au m�me niveau de
           profondeur (�lagage beta). */
        return beta;
      }

      /* L'�valuation obtenue devient la nouvelle r�f�rence. */
      alpha = score;

      /* Mise � jour de la variante principale. */
      UPDATE_PV
    }
  }

  /* Si aucune branche n'a pu �tre analys�e, c'est qu'il n'existe pas de coup l�gal. */
  if (!analyzed_branches) {

    /* Si le roi est attaqu� par la couleur adverse, */
    if (moves.is_attacked (king[active_color], active_color^1)) {

      /* le score remont� indiquera le nombre de demi-coups avant le mat. */
      alpha = - MATE + search_ply;
    }
    /* sinon, */
    else {

      /* le score remont� indiquera l'�galit�. */
      alpha = 0;
    }
  }
  else {

    /* Si la r�gle des 50 coups s'applique, */
    if (halfmove >= 100) {

      /* Le score remont� indiquera l'�galit�. */
      alpha = 0;
    }
  }

  /* Si une am�lioration de la borne inf�rieure est obtenue, */
  if (alpha > initial_alpha) {

    /* alors le programme m�morise la position avec un coup de la variante principale; */
    TT ttable.write_ttable (depth, EXACT_SCORE, alpha, pv[search_ply][search_ply].moveid);
  }
  else {

    /* sinon il m�morise la position avec l'�valuation correspondant � une limite sup�rieure. */
    TT ttable.write_ttable (depth, UPPER_BOUND, alpha, 0);
  }

  return alpha;
}
/* End of function : search */

/**************************************************************************************************
  Function     : sort_moves
  Description  : Cette fonction fait le tri des coups, pour lancer l'analyse en priorit� sur les
                 coups les plus int�ressants, ceci afin de  provoquer un �lagage au plus t�t.
  Parameters   : in  - liste des coups d'une position
                 in  - nombre de coups dans la liste
                 in  - identifiant d'un coup issu de la table de transposition
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void sort_moves (move_s *moves_list, int moves_number, int tt_moveid) {                            DBG_SORT_MOVES_CALL
                                                                                                   DBG_SORT_MOVES_START
  /* Pendant la recherche de la variante principale, les coups correspondants auront la note la
     plus importante. */

  if (follow_pv) {

    follow_pv = false;

    for (int i = 1; i <= moves_number; i++)   {                                                    DBG_SORT_MOVES_1("pv")

      moves_list[i].note = 0;

      /* Si le coup fait partie de la variante principale, */
      if (moves_list[i].moveid == pv[1][search_ply].moveid) {

        /* alors son int�r�t est tr�s important; il sera examin� en premier, */
        moves_list[i].note += INF;                                                                 DBG_HEURISTIC_0

        /* et le programme poursuivra sur la suite de la variante principale aux niveaux inf�rieurs
           de l'arbre. */
        follow_pv = true;
      }
      else {

        /* sinon le programme applique les autres m�thodes de notation. */
        apply_heuristics (&moves_list[i], tt_moveid);
      }
    }
  }
  /* En dehors de la recherche de la variante principale, */
  else {

    for (int i = 1; i <= moves_number; i++) {                                                      DBG_SORT_MOVES_1("not_pv")

      moves_list[i].note = 0;

      /* le programme applique les autres m�thodes de notation. */
      apply_heuristics (&moves_list[i], tt_moveid);
    }
  }                                                                                                DBG_SORT_MOVES_END
}
/* End of function : sort_moves */

/**************************************************************************************************
  Function     : update_killers
  Description  : Mise � jour des coups remarquables si un coup obtient un score meilleur que celui
                 d'un des coups pr�c�demment m�moris�s. Seuls les trois meilleurs sont conserv�s �
                 un m�me niveau de l'arbre.
  Parameters   : in  - identifiant du coup � v�rifier
                 in  - �valuation de la position obtenue
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void update_killers (int moveid, int score) {                                                      DBG_UPDATE_KILLERS_CALL

  if (score > killers[search_ply].score1) {

    killers[search_ply].score2 = killers[search_ply].score1;
    killers[search_ply].score1 = score;

    killers[search_ply].moveid3 = killers[search_ply].moveid2;
    killers[search_ply].moveid2 = killers[search_ply].moveid1;
    killers[search_ply].moveid1 = moveid;                                                          DBG_UPDATE_KILLERS(1)
  }
  else if (score > killers[search_ply].score2) {

    killers[search_ply].score2 = score;

    killers[search_ply].moveid3 = killers[search_ply].moveid2;
    killers[search_ply].moveid2 = moveid;                                                          DBG_UPDATE_KILLERS(2)
  }
}
/* End of function : update_killers */
