/**************************************************************************************************
  File : hash.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Module de hachage.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "debug.h"
#include "hash.h"
#include "tools.h"

/**************************************************************************************************
  Data :
**************************************************************************************************/

/* Valeur de hachage de la position courante. */
u64 h_position;

/* Valeur de hachage des positions de la partie :
   (Pour v�rifier la r�p�tition des position) */
u64 h_position_history[MAX_MOVES * 2];

/* Tables des valeurs de hachage pour successivement les pi�ces, la couleur au trait, la prise en
   passant et les roques : */
u64 h_values[16][BOARD_SIZE];
u64 h_values_color[2];
u64 h_values_ep[BOARD_SIZE];
u64 h_values_castle[256];

/**************************************************************************************************
  Internal functions prototypes :
**************************************************************************************************/

u64 generate_random (void);

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : compute_h_position
  Description  : Calcule une valeur de hachage pour la position courante. C'est un nombre unique
                 qui va permettre d'identifier celle-ci.
                 Elle est obtenue en utilisant la fonction logique "ou exclusif" sur des valeurs
                 qui caract�risent les �l�ments suivants :
                    - les pi�ces,
                    - la couleur au trait,
                    - la prise en passant,
                    - la possibilit� de roquer.
                 Nota : Un probl�me important � �tudier concerne les collisions qui pourraient
                 appara�tre en raison du nombre astronomique des positions possibles.
  Parameters   : aucun
  Return value : identifiant de la position
  Validation   : 1
**************************************************************************************************/
u64 compute_h_position (void) {                                                                    DBG_COMPUTE_H_POSITION_CALL

/* --- Local data ------------------------------------------------------------------------------ */

u64 h_current_position = 0;  /* Valeur d'identification initiale. */

int square;                  /* Case de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Prise en compte des pi�ces pr�sentes sur l'�chiquier, de leur couleur et de leur position. */
  for (int color = BLACK; color <= WHITE; color++) {

    for (int i = 1; i <= pieces_number[color]; i++) {

      square = pieces[color][i];

      /* Si la case n'est pas vide, */
      if (square) {

        /* la pi�ce et sa position sont prises en compte dans le calcul. */
        h_current_position ^= h_values[board[square]][square];
      }
    }
  }

  /* Prise en compte d'une �ventuelle prise en passant. */
  h_current_position ^= h_values_ep[EP_SQUARE];

  /* Prise en compte des possibilit�s de roquer. */
  h_current_position ^= h_values_castle[CASTLE_STATUS];

  /* Prise en compte de la couleur au trait. */
  h_current_position ^= h_values_color[active_color];                                              DBG_COMPUTE_H_POSITION_END

  return (h_current_position);
}
/* End of function : compute_h_position */

/**************************************************************************************************
  Function     : initialize_h_values
  Description  : Calcul et m�morisation des valeurs de hachage pour tous les �l�ments qui
                 permettent de caract�riser une position :
                    - les pi�ces par case de l'�chiquier,
                    - la couleur au trait,
                    - la prise en passant par case possible de l'�chiquier,
                    - la possibilit� de roquer.
                 Chaque valeur est constitu�e d'un nombre al�atoire de 64 bits.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void initialize_h_values (void) {                                                                  DBG_INITIALIZE_H_VALUES_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int square;        /* Case de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Efface le contenu des tables des valeurs de hachage. */
  memset (h_values, 0, sizeof (h_values));
  memset (h_values_ep, 0, sizeof (h_values_ep));
  memset (h_values_color, 0, sizeof (h_values_color));
  memset (h_values_castle, 0, sizeof (h_values_castle));

  for (int color = BLACK; color <= WHITE; color++) {

    for (int x = A; x <= H; x++) {

      /* Calcul des valeurs de hachage pour les pi�ces : chaque pi�ce aura une valeur en fonction
         de son type, de sa couleur et de sa position sur l'�chiquier. */
      for (int piece = PAWN; piece <= KING; piece++) {

        for (int y = 1; y <= 8; y++) {

          square = SQUARE;

          h_values[piece + (color << 3)][square] = generate_random ();
        }
      }

      /* Calcul des valeurs de hachage pour chaque case de destination d'une prise en passant en
         fonction de la couleur et de la colonne (cases situ�es sur la troisi�me rang�e du camp des
         blancs ou des noirs) : */
      square = (RR(3) + 1) * 10 + x;

      h_values_ep[square] = generate_random ();
    }

    /* Calcul des valeurs de hachage pour la couleur au trait : */
    h_values_color[color] = generate_random ();
  }

  /* Calcul des valeurs de hachage pour la prise en compte des roques (petit ou grand roque, blanc
     ou noir) en fonction de leur possibilit� : */
  for (int i = 0; i < 256; i++) {

    h_values_castle[i] = generate_random ();
  }
}
/* End of function : initialize_h_values */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/
hash_module_s hash = {

  compute_h_position,
  initialize_h_values
};

/**************************************************************************************************
  Internal functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : generate_random
  Description  : G�n�ration d'un nombre al�atoire entier non sign� sur 64 bits.
  Parameters   : aucun
  Return value : nombre al�atoire
  Validation   : 1
**************************************************************************************************/
u64 generate_random (void) {                                                                       DBG_GENERATE_RANDOM_CALL

/* --- Local data ------------------------------------------------------------------------------ */

u64 random_number = 0;
u64 result_number = 0;

/* --- Function code --------------------------------------------------------------------------- */

  for (int i = 0; i < sizeof (random_number); i++) {

    /* G�n�ration d'un nombre compris dans l'intervalle [0;256[ avec une pr�cision de 1/RAND_MAX */
    random_number = (unsigned int) ((double) rand() * 255 / (RAND_MAX + 1));

    /* Concat�nation des octets g�n�r�s al�atoirement pour former un nombre entier de la taille
       souhait�e. */
    result_number ^= (random_number << (8 * i));
  }

  return result_number;
}
/* End of function : generate_random */
