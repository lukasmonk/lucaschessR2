/**************************************************************************************************
  File : ttable.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "ttable".
**************************************************************************************************/

#ifndef TTABLE_H
#define TTABLE_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichier en-t�te des d�finitions g�n�rales : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "hash.h"

/**************************************************************************************************
  Constants :
**************************************************************************************************/

/* Informations sur la conduite de la recherche : */
#define NO_TT_INFO      0
#define AVOID_NULL_MOVE 1
#define EXACT_SCORE     2
#define LOWER_BOUND     3
#define UPPER_BOUND     4

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Contenu de la table de transposition : */
typedef struct {

  h_value_s h_position;

  char  depth;
  char  node_type;
  short value;
  int   moveid;

} ttable_s;

/* Fonctions externes du module : */
typedef struct {

  void (*free_ttable) (void);
  void (*initialize_ttable) (void);
  int (*read_ttable) (int depth, int alpha, int beta, int *flag, int *moveid);
  void (*reset_ttable) (void);
  void (*search_tt_pv) (int depth);
  void (*write_ttable) (int depth, int node_type, int value, int moveid);

} ttable_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern ttable_module_s ttable;

extern ttable_s *tt_address;

extern int ttable_size;

extern unsigned long int tt_entries;
extern unsigned long int tt_occupied;

#endif /* TTABLE_H */
