/**************************************************************************************************
  File : tools.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "tools".
**************************************************************************************************/

#ifndef TOOLS_H
#define TOOLS_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Fonctions externes du module : */
typedef struct {

  void (*compute_time) (void);
  void (*print_board) (FILE *output_file);
  void (*read_config_file) (void);
  void (*read_input) (char string[]);
  int (*send_output) (bool to_stdout, const char *format, ...);
  void (*update_pieces) (void);

} tools_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern tools_module_s tools;

#endif /* TOOLS_H */
