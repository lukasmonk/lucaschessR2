/**************************************************************************************************
  File : moves.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Module de g�n�ration des coups, de d�placement des pi�ces. Il regroupe �galement
                les fonctions qui ex�cutent des op�rations sur les coups.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "debug.h"
#include "hash.h"
#include "moves.h"
#include "tools.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Informations sur les d�placements possibles d'une pi�ce  : */
typedef struct {

  /* Indique une pi�ce � long rayon d'action : */
  bool long_range;

  /* Liste des directions que peut prendre une pi�ce : */
  int direction[9];

} piece_liberty_s;

/**************************************************************************************************
  Constants :
**************************************************************************************************/

/* Vecteurs de d�placement dans chacune des 18 directions : */
const int vector[19] = {
  0, /* Non utilis�. */

  /* D�placement d'une case dans toutes les directions : */
  10, 11, 1, -9, -10, -11, -1, 9,

  /* Pour les cavaliers uniquement : */
  21, 12, -8, -19, -21, -12, 8, 19,

  /* Pour les pions uniquement, � partir de leur case de d�part : */
  20, -20 };

/* Directions oppos�es (utilis�es pour les 8 premi�res des 18 existantes) : */
const int opposed_direction[9] = { 0, 5, 6, 7, 8, 1, 2, 3, 4 };

/* Directions autoris�es pour les pi�ces : */
const piece_liberty_s liberty[15] = {
  { false, { 0,  0,  0,  0,  0,  0,  0,  0,  0 } }, /* not used */

  { false, { 0,  5, 18,  4,  6,  0,  0,  0,  0 } }, /* black pawn */
  { false, { 0,  9, 10, 11, 12, 13, 14, 15, 16 } }, /* black knight */
  {  true, { 0,  0,  2,  0,  4,  0,  6,  0,  8 } }, /* black bishop */
  {  true, { 0,  1,  0,  3,  0,  5,  0,  7,  0 } }, /* black rook */
  {  true, { 0,  1,  2,  3,  4,  5,  6,  7,  8 } }, /* black queen */
  { false, { 0,  1,  2,  3,  4,  5,  6,  7,  8 } }, /* black king */

  { false, { 0,  0,  0,  0,  0,  0,  0,  0,  0 } }, /* not used */
  { false, { 0,  0,  0,  0,  0,  0,  0,  0,  0 } }, /* not used */

  { false, { 0,  1, 17,  2,  8,  0,  0,  0,  0 } }, /* white pawn */
  { false, { 0,  9, 10, 11, 12, 13, 14, 15, 16 } }, /* white knight */
  {  true, { 0,  0,  2,  0,  4,  0,  6,  0,  8 } }, /* white bishop */
  {  true, { 0,  1,  0,  3,  0,  5,  0,  7,  0 } }, /* white rook */
  {  true, { 0,  1,  2,  3,  4,  5,  6,  7,  8 } }, /* white queen */
  { false, { 0,  1,  2,  3,  4,  5,  6,  7,  8 } }  /* white king */
};

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : compute_moveid
  Description  : Pour calculer l'identifiant d'un coup donn� en notation alg�brique. C'est un
                 nombre entier cod� sur 24 bits :
                    - bit  0 �  7 : case de d�part
                    - bit  8 � 15 : case d'arriv�e
                    - bit 16 � 24 : pi�ce de promotion �ventuelle
                 Les cases de d�part et d'arriv�e sont d�finies par rapport � un tableau lin�aire
                 de 120 cases (tableau board).
  Parameters   : in  - coup au format LAN
                 out - identifiant du coup
  Return value : Le coup est potentiellement correct (true) ou non (false). Cela ne signifie
                 cependant pas qu'il fait partie des coups possibles, ni qu'il est l�gal.
  Validation   : 1
**************************************************************************************************/
bool compute_moveid (const char *lan_move, int *moveid) {                                          DBG_COMPUTE_MOVEID_CALL

/* --- Local data ------------------------------------------------------------------------------ */

bool is_possible_move = false;    /* Par d�faut le coup est incorrect. */

/* --- Function code --------------------------------------------------------------------------- */DBG_COMPUTE_MOVEID_START

  /* Pour le moment l'identifiant est ind�fini. */
  *moveid = 0;

  /* Si l'entr�e peut correspondre � un coup �crit en notation alg�brique, */
  if (   isalpha ((int) lan_move[0])
      && isdigit ((int) lan_move[1])
      && isalpha ((int) lan_move[2])
      && isdigit ((int) lan_move[3])
      && strlen (lan_move) <= 5 ) {

    /* alors le programme calcule la case de d�part, */
    if (lan_move[0] >= 'a' && lan_move[0] <= 'h') {

      int x = lan_move[0] - 'a' + 1;   /* Colonne de la case. */

      if (lan_move[1] >= '1' && lan_move[1] <= '8') {

        int y = lan_move[1] - '1' + 1; /* Rang�e de la case. */
        *moveid = SQUARE;

        /* puis la case d'arriv�e. */
        if (lan_move[2] >= 'a' && lan_move[2] <= 'h') {

          x = lan_move[2] - 'a' + 1;   /* Colonne de la case. */

          if (lan_move[3] >= '1' && lan_move[3] <= '8') {

            y = lan_move[3] - '1' + 1; /* Rang�e de la case. */
            *moveid += (SQUARE) << 8;

            /* A cet instant le coup semble correct. */
            is_possible_move = true;

            /* Le programme v�rifie la pr�sence d'une �ventuelle promotion. */
            if (strlen (lan_move) == 5) {

              switch (lan_move[4]) {

                case 'b' : *moveid += BISHOP << 16; break;
                case 'n' : *moveid += KNIGHT << 16; break;
                case 'q' : *moveid += QUEEN  << 16; break;
                case 'r' : *moveid += ROOK   << 16; break;
                default :
                  /* La lettre n'identifie pas une pi�ce de promotion. */
                  is_possible_move = false;
                  break;
              }
            }
          }
        }
      }
    }
  }                                                                                                DBG_COMPUTE_MOVEID_END

  return is_possible_move;
}
/* End of function : compute_moveid */

/**************************************************************************************************
  Function     : convert_pgm_move
  Description  : Pour convertir un coup du format tel qu'il est connu en interne par le programme
                 (structure move_s), vers le format LAN (Long Algebraic Notation).
  Parameters   : in  - coup au format interne
                 out - coup au format LAN
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void convert_pgm_move (move_s *pgm_move, char lan_move[]) {                                        DBG_CONVERT_PGM_MOVE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

char promoted_char;     /* Pour m�moriser la pi�ce de promotion. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Dans le cas d'une promotion, traduction de la pi�ce promue : */
  switch (pgm_move->promoted) {
    case (KNIGHT) : promoted_char = 'n'; break;
    case (BISHOP) : promoted_char = 'b'; break;
    case (ROOK)   : promoted_char = 'r'; break;
    case (QUEEN)  : promoted_char = 'q'; break;
    default :
      promoted_char = '\0';
  }

  /* Traduction du coup complet (case de d�part + case d'arriv�e + pi�ce de
     promotion �ventuelle) : */
  sprintf (lan_move, "%c%d%c%d%c",
    file[pgm_move->from] + 'a' - 1, rank[pgm_move->from],
    file[pgm_move->to] + 'a' - 1, rank[pgm_move->to],
    promoted_char);
}
/* End of function : convert_pgm_move */

/**************************************************************************************************
  Function     : generate
  Description  : G�n�rateur des coups � partir de la position courante et pour la couleur active.
                 La liste des coups fait abstraction des �checs. La l�galit� de chaque coup sera
                 trait�e lors du parcours de l'arbre de recherche, ce qui permet de r�duire le
                 temps consacr� � la g�n�ration.
                 Une option consiste � ne g�n�rer que les coups qui permettent une capture, ce qui
                 est utile pour la recherche des positions calmes.
  Parameters   : out - liste des coups g�n�r�s
                 in  - indique si la recherche ne doit porter que sur les captures
  Return value : nombre de coups g�n�r�s
  Validation   : 1
**************************************************************************************************/
int generate (move_s *moves, bool captures_only) {                                                 DBG_GENERATE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int color = active_color;    /* Couleur du camp. */
int moves_number = 0;        /* Nombre de coups g�n�r�s. */

int square;                  /* Case de l'�chiquier. */

/* Variables interm�diaires pour gagner du temps en �vitant des calculs inutiles. En effet � chaque
   acc�s � un �l�ment d'un tableau, le programme doit calculer l'adresse m�moire de l'�l�ment. */
int DIRECTION;
int PIECES_PIECE;
int PIECES_SQUARE;

move_s *MOVE_PTR;

/* --- Function code --------------------------------------------------------------------------- */DBG_GENERATE_START

  for (int i = 1; i <= pieces_number[color]; i++) {

    /* M�morisent la position de la pi�ce et son type. */
    PIECES_SQUARE = pieces[color][i];
    PIECES_PIECE  = board[PIECES_SQUARE];

    /* Si une pi�ce diff�rente d'un pion est pr�sente, */
    if ((PIECES_PIECE & 0x7) != PAWN && PIECES_SQUARE) {

      /* alors pour les 8 directions maximum que peut avoir une pi�ce, */
      for (int j = 1; j <= 8; ++j) {

        /* le programme m�morise cette direction. */
        DIRECTION = liberty[PIECES_PIECE].direction[j];

        /* Si la pi�ce peut prendre cette direction, */
        if (DIRECTION) {

          /* alors la recherche commence � partir de la position de la pi�ce. */
          square = PIECES_SQUARE;

          do {

            /* Le programme calcule la case suivante dans cette direction. */
            square += vector[DIRECTION];

            /* Si ce n'est pas un bord de l'�chiquier, */
            if (board[square] != FRAME) {

              /* alors il v�rifie si la case contient une pi�ce de la m�me couleur ou un roi, */
              if (   (board[square] && ((board[square] >> 3) == color))
                  || ((board[square] & 0x7) == BKING)) {

                /* auquel cas la recherche dans cette direction est termin�e. */
                break;
              }
              else {

                /* Si la case d'arriv�e contient une pi�ce adverse ou si la recherche ne se limite
                   pas aux seules captures, */
                if (!captures_only || board[square]) {

                  /* alors un d�placement est trouv�. */
                  moves_number++;

                  MOVE_PTR = &moves[moves_number];

                  /* et les informations de ce d�placement sont mises � jour. */
                  MOVE_PTR->from = PIECES_SQUARE;
                  MOVE_PTR->to = square;
                  MOVE_PTR->status = 0;
                  MOVE_PTR->promoted = 0;
                  MOVE_PTR->moveid = PIECES_SQUARE + (square << 8);

                  /* Si une pi�ce est pr�sente sur la case d'arriv�e, */
                  if (board[square]) {

                    /* alors c'est une capture et le programme m�morise les informations au sujet
                       de la pi�ce captur�e, */
                    MOVE_PTR->captured = board[square];
                    MOVE_PTR->captured_ptr = pieces_ptr[square];

                    /* et la recherche dans cette direction est termin�e. */
                    break;
                  }
                  else {

                    /* sinon c'est un simple d�placement. */
                    MOVE_PTR->captured = 0;
                    MOVE_PTR->captured_ptr = NULL;
                  }
                }
              }
            }
            else {

              /* sinon on d�passe les limites de l'�chiquier. */
              break;
            }

          /* La recherche dans cette direction continue pour une pi�ce � longue
             port�e. */
          } while (liberty[PIECES_PIECE].long_range);
        }
      }
    }
    /* si la pi�ce est un pion, */
    else if ((PIECES_PIECE & 0x7) == PAWN && PIECES_SQUARE) {

      /* alors pour les 4 directions maximum que peut avoir un pion, */
      for (int j = 1; j <= 4; j++) {

        /* le programme m�morise cette direction. */
        DIRECTION = liberty[PIECES_PIECE].direction[j];

        /* et calcule la case suivante dans cette direction. */
        square = PIECES_SQUARE + vector[DIRECTION];

        /* Si ce n'est pas un bord de l'�chiquier, */
        if (board[square] != FRAME) {

          /* alors le programme v�rifie que le d�placement r�pond � l'un des
             crit�res suivants :
             - la case d'arriv�e est vide pour un d�placement d'une case,
             - la case d'arriv�e contient une pi�ce adverse pour une prise,
             - la case d'arriv�e correspond � une prise en passant,
             - la case d'arriv�e est vide pour un d�placement de deux cases ainsi que la case de
               passage et que la case de d�part est sur la deuxi�me rang�e. */
          if (   (j == 1 && !board[square])
              || (j > 2 && board[square] && (board[square] >> 3) != color)
              || (j > 2 && EP_SQUARE == square)
              || (j == 2 && !board[square]
                  && !board[square - (color ? 10 : -10)]
                  && rank[PIECES_SQUARE] == RR(2))) {

            /* Si la recherche ne se limite pas aux seules captures,
               ou si la case d'arriv�e contient une pi�ce adverse,
               ou si la case d'arriv�e correspond � une prise en passant,
               ou s'il s'agit d'une promotion,  */
            if (   (!captures_only)
                || (board[square])
                || (j > 2 && EP_SQUARE == square)
                || (rank[square] == RR(8))) {

              /* alors un d�placement est trouv�. */
              moves_number++;

              MOVE_PTR = &moves[moves_number];

              /* et les informations de ce d�placement sont mises � jour. */
              MOVE_PTR->from = PIECES_SQUARE;
              MOVE_PTR->to = square;
              MOVE_PTR->moveid = PIECES_SQUARE + (square << 8);

              /* Si c'est une capture, */
              if (board[square]) {

                /* alors le programme m�morise les informations au sujet de la pi�ce captur�e, */
                MOVE_PTR->captured = board[square];
                MOVE_PTR->captured_ptr = pieces_ptr[square];
              }
              else {

                /* sinon c'est un simple d�placement. */
                MOVE_PTR->captured = 0;
                MOVE_PTR->captured_ptr = NULL;
              }

              /* Si c'est une promotion, */
              if (rank[square] == RR(8)) {

                /* alors le programme m�morise les informations pour la promotion en tour, */
                MOVE_PTR->status = PROMOTION;
                MOVE_PTR->promoted = ROOK;
                MOVE_PTR->moveid += (ROOK << 16);

                /* et cr�er les promotions associ�es, en cavalier, */
                moves_number++;
                memcpy (&moves[moves_number], MOVE_PTR, sizeof(move_s));
                MOVE_PTR->promoted = KNIGHT;
                MOVE_PTR->moveid -= (2 << 16);

                /* en fou, */
                moves_number++;
                memcpy (&moves[moves_number], MOVE_PTR, sizeof(move_s));
                MOVE_PTR->promoted = BISHOP;
                MOVE_PTR->moveid += (1 << 16);

                /* ou en dame. */
                moves_number++;
                memcpy (&moves[moves_number], MOVE_PTR, sizeof(move_s));
                MOVE_PTR->promoted = QUEEN;
                MOVE_PTR->moveid += (2 << 16);

                /* Nota : La promotion en dame est faite en dernier pour qu'elle apparaisse en
                   premier dans la liste des coups finale. */
              }
              /* si c'est une prise en passant, */
              else if (j > 2 && EP_SQUARE == square) {

                /* alors le programme met � jour comme pour une capture. */
                MOVE_PTR->status = EN_PASSANT;
                MOVE_PTR->captured = (color ? BPAWN : WPAWN);
                MOVE_PTR->captured_ptr = pieces_ptr[square - (color ? 10 : -10)];
              }
              /* sinon c'est un simple d�placement. */
              else {

                MOVE_PTR->status = 0;
                MOVE_PTR->promoted = 0;
              }
            }
          }
        }
      }
    }
  }

  /* Sauf pour la recherche des seules captures, */
  if (!captures_only) {

    /* le programme examine la possibilit� pour un roi de roquer. Ce dernier est possible si les
       cases entre la tour et le roi sont libres.

       Nota : Les �checs au roi ne seront examin�s que plus tard dans le module "search" pour
       gagner du temps. */

    /* Examen du petit roque. */
    if (   CASTLE_STATUS & (0x5 & castle_possible_mask[color])
        && !board[96 - 70 * color]
        && !board[97 - 70 * color]) {

      moves_number++;

      MOVE_PTR = &moves[moves_number];

      MOVE_PTR->from         = 95 - 70 * color;
      MOVE_PTR->to           = MOVE_PTR->from + 2;
      MOVE_PTR->status       = KING_CASTLING;
      MOVE_PTR->promoted     = 0;
      MOVE_PTR->captured     = 0;
      MOVE_PTR->captured_ptr = NULL;
      MOVE_PTR->moveid       = MOVE_PTR->from + (MOVE_PTR->to << 8);
    }

    /* Examen du grand roque. */
    if (   CASTLE_STATUS & (0xA & castle_possible_mask[color])
        && !board[94 - 70 * color]
        && !board[93 - 70 * color]
        && !board[92 - 70 * color]) {

      moves_number++;

      MOVE_PTR = &moves[moves_number];

      MOVE_PTR->from         = 95 - 70 * color;
      MOVE_PTR->to           = MOVE_PTR->from - 2;
      MOVE_PTR->status       = QUEEN_CASTLING;
      MOVE_PTR->promoted     = 0;
      MOVE_PTR->captured     = 0;
      MOVE_PTR->captured_ptr = NULL;
      MOVE_PTR->moveid       = MOVE_PTR->from + (MOVE_PTR->to << 8);
    }
  }                                                                                                DBG_GENERATE_END

  /* Le nombre de coups trouv�s est retourn�. */
  return moves_number;
}
/* End of function : generate */

/**************************************************************************************************
  Function     : is_attacked
  Description  : D�termine si une case est attaqu�e par une couleur.
  Parameters   : in  - case
                 in  - couleur attaquante
  Return value : La case est attaqu�e (true) ou non (false).
  Validation   : 1
**************************************************************************************************/
bool is_attacked (int square0, int color) {                                                        DBG_IS_ATTACKED_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int square;        /* Case de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */DBG_IS_ATTACKED_START

  /* Pour toutes les directions autour d'une case (sauf les 17 et 18 qui correspondent au
     d�placement de deux cases du pion en d�but de partie), */
  for (int d = 1; d < 17; d++) {

    /* On part de la case qui doit �tre test�e, */
    square = square0;

    while (true) {

      /* et l'on va � la suivante dans la direction d�finie. */
      square += vector[d];

      /* Si la case d'arriv�e est un bord de l'�chiquier,
         ou apr�s un saut de cavalier (d > 8) elle est vide,
         ou sur la case d'arriv�e il y a une pi�ce du m�me camp, */
      if (   board[square] == FRAME
          || (!board[square] && d > 8)
          || (board[square] && (board[square] >> 3) != color)) {

        /* alors la recherche dans cette direction est arr�t�e. */
        break;
      }
      /* sinon si la case d'arriv�e contient une pi�ce du camp adverse, */
      else if (board[square] && (board[square] >> 3) == color) {

        /* alors on regarde si la pi�ce adverse peut aller en direction de la case test�e : */

        /* Pour les d�placements autres que ceux du cavalier, */
        if (d <= 8) {

          /* si la case contient un pion, */
          if ((board[square] & 0x7) == PAWN) {

            /* est-ce que le pion peut atteindre la case test�e ?  */
            if (   (   liberty[board[square]].direction[3] == opposed_direction[d]
                    || liberty[board[square]].direction[4] == opposed_direction[d])
                && (((square - square0) / vector[d]) == 1)) {                                      DBG_IS_ATTACKED_END("by pawn")

              return true;
            }
          }
          /* sinon est-ce que la pi�ce peut atteindre la case test�e, en fonction de sa distance et
            de son rayon d'action ? */
          else if (   liberty[board[square]].direction[d] == d
                   && (  liberty[board[square]].long_range == true
                       || ((square - square0) / vector[d]) == 1)) {                                DBG_IS_ATTACKED_END("by piece")

            return true;
          }
        }
        /* sinon est-ce que la pi�ce est un cavalier. */
        else if ((board[square] & 0x7) == KNIGHT) {                                                DBG_IS_ATTACKED_END("by knight")

          return true;
        }

        /* alors la recherche dans cette direction est arr�t�e. */
        break;
      }
    }
  }                                                                                                DBG_IS_ATTACKED_END("none")

  return false;
}
/* End of function : is_attacked */

/**************************************************************************************************
  Function     : is_legal
  Description  : Apr�s un coup jou�, d�termine si le roi est en �chec ou si, dans le cas d'un
                 roque, une des cases du roque �tait attaqu�e par une pi�ce adverse lors du
                 d�placement du roi.
  Parameters   : in  - coup jou� � v�rifier
  Return value : Le coup jou� �tait l�gal (true) ou non (false).
  Validation   : 1
**************************************************************************************************/
bool is_legal (move_s *move) {                                                                     DBG_IS_LEGAL_CALL
                                                                                                   DBG_IS_LEGAL_START
  switch (move->status) {

    /* V�rification des �checs lors du petit roque. */
    case (KING_CASTLING) :

      if (moves.is_attacked (move->from, active_color))     return false;
      if (moves.is_attacked (move->from + 1, active_color)) return false;
      if (moves.is_attacked (move->from + 2, active_color)) return false;
      break;

    /* V�rification des �checs lors du grand roque. */
    case (QUEEN_CASTLING) :

      if (moves.is_attacked (move->from, active_color))     return false;
      if (moves.is_attacked (move->from - 1, active_color)) return false;
      if (moves.is_attacked (move->from - 2, active_color)) return false;
      break;

    default :
      /* Apr�s un coup autre que le roque, v�rifie si le roi est en �chec. */
      if (moves.is_attacked (king[active_color^1], active_color)) return false;
  }                                                                                                DBG_IS_LEGAL_END

  /* A ce stade, on peut dire que le dernier coup jou� �tait l�gal. */
  return true;
}
/* End of function : is_legal */

/**************************************************************************************************
  Function     : make
  Description  : Joue le coup donn� en entr�e et met � jour les diff�rentes donn�es du programme.
  Parameters   : in  - coup � jouer
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void make (move_s *move) {                                                                         DBG_MAKE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int color;         /* Couleur du camp au trait. */

/* --- Function code --------------------------------------------------------------------------- */DBG_MAKE_START

  /* Calcul la couleur de la pi�ce � d�placer. */
  color = board[move->from] >> 3;

  /* M�morise le coup dans la liste des coups jou�s. */
  played_moves[game_ply] = *move;

  /* Passage au coup suivant de la partie. */
  game_ply++;

  /* Les statuts du roque et de la prise en passant sont archiv�es. */
  CASTLE_STATUS = castle_status[game_ply - 1];
  EP_SQUARE = ep_square[game_ply - 1];

  /* Mise � jour des informations de hachage pour la position courante. */
  h_position ^= h_values[board[move->from]][move->from];
  h_position ^= h_values[board[move->to]][move->to];
  h_position ^= h_values[board[move->from]][move->to];
  h_position ^= h_values_ep[EP_SQUARE];
  h_position ^= h_values_color[BLACK];
  h_position ^= h_values_color[WHITE];

  /* Prise en compte des possibilit�s de roquer avant le coup jou�. */
  h_position ^= h_values_castle[CASTLE_STATUS];

  /* Efface la possibilit� de prendre en passant. */
  EP_SQUARE = 0;

  /* Mise � jour du comptage de demi-coups pour la r�gle des 50 coups. */
  halfmove_history[search_ply] = halfmove;
  if ((board[move->from] & 0x7) != PAWN && !move->captured) {

    halfmove++;
  }
  else {

    halfmove = 0;
  }

  /* Mise � jour du d�compte des pi�ces (les pions ne sont pas compt�s, le roi quant � lui n'est
     jamais captur�). */
  if ((board[move->to] & 0x7) > PAWN) {

    piece_count--;
  }

  /* Mise � jour des informations pour la case d'arriv�e. */
  board[move->to] = board[move->from];
  pieces_ptr[move->to] = pieces_ptr[move->from];
  moved[move->to]++;

  /* Mise � jour de la fiche associ�e. */
  *pieces_ptr[move->to] = move->to;

  /* Si c'est une capture, */
  if (move->captured) {

    /* alors on efface le lien vers la fiche associ�e � la pi�ce captur�e. */
    *move->captured_ptr = 0;
  }

  /* Effacement des informations pour la case de d�part. */
  board[move->from] = NONE;
  moved[move->from]++;

  /* En ce qui concerne les pions, */
  if ((board[move->to] & 0x7) == PAWN) {

    /* si c'est une promotion, la nature de la pi�ce est chang�e, */
    if (move->status == PROMOTION) {

      h_position ^= h_values[board[move->to]][move->to];

      /* et la pi�ce promue est mise sur l'�chiquier en calculant sa couleur. */
      board[move->to] = move->promoted | (color << 3);

      h_position ^= h_values[board[move->to]][move->to];
    }
    /* s'il s'agit d'une prise en passant, */
    else if (move->status == EN_PASSANT) {

      /* alors les informations du pion captur� sont effac�es. */
      board[move->to - (color ? 10 : -10)] = NONE;

      h_position ^= h_values[color ? BPAWN : WPAWN][move->to - (color ? 10 : -10)];
    }
    /* s'il s'agit d'un d�placement de deux cases � partir, */
    else if (abs (move->to - move->from) == 20) {

      /* alors la case pour une �ventuelle prise en passant est positionn�e. */
      EP_SQUARE = move->from + (color ? 10 : -10);

      h_position ^= h_values_ep[EP_SQUARE];
    }
  }
  /* Si la pi�ce d�plac�e est un roi, */
  else if ((board[move->to] & 0x7) == KING) {

    /* alors le programme m�morise sa nouvelle position, */
    king[color] = move->to;

    /* et supprime les possibilit�s de roquer pour le roi. */
    CASTLE_STATUS &= castle_by_color_mask[color^1];

    /* Si c'est un petit roque la tour 'H' est d�plac�e �galement. */
    if (move->status == KING_CASTLING) {

      /* M�morisation des cases pour �viter des calculs inutiles. */
      int sq0 = 98 - 70 * color;
      int sq1 = sq0 - 2;

      /* Indique que le roi a roqu�. */
      CASTLE_STATUS |= (color ? 0x10 : 0x40);

      /* Mise � jour des informations de la case d'arriv�e. */
      board[sq1] = (color ? WROOK : BROOK);
      pieces_ptr[sq1] = pieces_ptr[sq0];

      /* Mise � jour de la fiche associ�e. */
      *pieces_ptr[sq1] = sq1;

      /* Effacement des informations de la case de d�part. */
      board[sq0] = NONE;

      h_position ^= h_values[color ? WROOK : BROOK][sq0];
      h_position ^= h_values[color ? WROOK : BROOK][sq1];
    }
    /* Si c'est un grand roque la tour 'A' est d�plac�e �galement. */
    else if (move->status == QUEEN_CASTLING) {

      /* M�morisation des cases pour �viter des calculs inutiles. */
      int sq0 = 91 - 70 * color;
      int sq1 = sq0 + 3;

      /* Indique que le roi a roqu�. */
      CASTLE_STATUS |= (color ? 0x20 : 0x80);

      /* Mise � jour des informations de la case d'arriv�e. */
      board[sq1] = color ? WROOK : BROOK;
      pieces_ptr[sq1] = pieces_ptr[sq0];

      /* Mise � jour de la fiche associ�e. */
      *pieces_ptr[sq1] = sq1;

      /* Effacement des informations de la case de d�part. */
      board[sq0] = NONE;

      h_position ^= h_values[color ? WROOK : BROOK][sq0];
      h_position ^= h_values[color ? WROOK : BROOK][sq1];
    }
  }

  /* Le roque n'est plus possible si une case d'un des coins de l'�chiquier est concern�e par un
     d�placement. */
  if (move->from == 21 || move->to == 21) CASTLE_STATUS &= 0xFD; /* Grand roque blanc */
  if (move->from == 91 || move->to == 91) CASTLE_STATUS &= 0xF7; /* Grand roque noir */
  if (move->from == 28 || move->to == 28) CASTLE_STATUS &= 0xFE; /* Petit roque blanc */
  if (move->from == 98 || move->to == 98) CASTLE_STATUS &= 0xFB; /* Petit roque noir */

  /* Prise en compte des possibilit�s de roquer apr�s le coup jou�. */
  h_position ^= h_values_castle[CASTLE_STATUS];

  /* M�morisation de la valeur de hachage de la nouvelle position. */
  h_position_history[game_ply] = h_position;

  /* Mise � jour du num�ro du coup de la partie. */
  if (active_color == BLACK) {

    fullmove++;
  }

  /* Le trait passe � la couleur oppos�e. */
  active_color ^= 1;                                                                               DBG_MAKE_END
                                                                                                   DBG_VERIFY_BOARD_PIECES("end of make")
}
/* End of function : make */

/**************************************************************************************************
  Function     : tree
  Description  : Cette fonction permet de calculer � partir de la position courante le nombre de
                 coups l�gaux et sur une profondeur donn�e en entr�e. Pour des profondeurs
                 inf�rieures � 5, le r�sultat peut �tre envoy� dans un fichier.
  Parameters   : in  - fichier
                 in  - profondeur de construction
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void tree (FILE *tree_file, int depth, u64 *total_legal_moves, int games_by_point) {

/* --- Local data ------------------------------------------------------------------------------ */

char lan_move[6];                 /* Coup en notation alg�brique. */

int moves_number;                 /* Nombre de coups g�n�r�s. */

move_s moves_list[MAX_MOVES];     /* Pour ranger les coups g�n�r�s. */

/* --- Function code --------------------------------------------------------------------------- */

  if (depth) {

    moves_number = moves.generate (moves_list, false);

    for (int i = 1; i <= moves_number; i++) {

      moves.make (&moves_list[i]);

      if (moves.is_legal (&moves_list[i])) {

        (*total_legal_moves)++;

        if ((*total_legal_moves & (games_by_point - 1)) == 0) {

          printf (".");

          if ((*total_legal_moves & (games_by_point * 32 - 1)) == 0) {

            printf (" %6d * 10^6\n   ", (unsigned int) *total_legal_moves/1000000);
          }
        }

        if (tree_file != NULL) {

          for (int j = 0; j < 15 - depth * 3; j++) {

            fputc (' ', tree_file);
          }

          moves.convert_pgm_move (&moves_list[i], lan_move);

          fprintf (tree_file, "%s\n", lan_move);
        }

        moves.tree (tree_file, depth - 1, total_legal_moves, games_by_point);
      }

      moves.unmake (&moves_list[i]);
    }
  }
}
/* End of function : tree */

/**************************************************************************************************
  Function     : unmake
  Description  : Revient � la position pr�c�dente sur l'�chiquier.
  Parameters   : in  - coup � enlever
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void unmake (move_s *move) {                                                                       DBG_UNMAKE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int color;                   /* Couleur du camp au trait. */

/* --- Function code --------------------------------------------------------------------------- */DBG_UNMAKE_START

  game_ply--;

  /* Calcul la couleur de la pi�ce � replacer. */
  color = board[move->to] >> 3;

  /* R�cup�re la valeur de hachage de la position pr�c�dente. */
  h_position = h_position_history[game_ply];

  /* Mise � jour du comptage de demi-coups pour la r�gle des 50 coups. */
  halfmove = halfmove_history[search_ply];

  /* Mise � jour des informations de la case de d�part. */
  board[move->from] = board[move->to];
  pieces_ptr[move->from] = pieces_ptr[move->to];

  /* Mise � jour de la fiche associ�e. */
  *pieces_ptr[move->from] = move->from;

  /* Diminution du nombre de d�placements pour les cases li�es au coup. */
  moved[move->from]--;
  moved[move->to]--;

  /* Effacement des informations de la case d'arriv�e. */
  if (!move->captured) {

    board[move->to] = NONE;
  }
  else {

    /* Si c'�tait une prise en passant, */
    if (move->status == EN_PASSANT) {

      /* la fiche associ�e est mise � jour, */
      *move->captured_ptr = move->to - (color ? 10 : -10);

      /* et le pion captur� est remis sur l'�chiquier. */
      board[move->to] = NONE;
      board[*move->captured_ptr] = color ? BPAWN : WPAWN;
      pieces_ptr[*move->captured_ptr] = move->captured_ptr;
    }
    else {

      /* La pi�ce captur�e est remise sur l'�chiquier. */
      board[move->to] = move->captured;
      pieces_ptr[move->to] = move->captured_ptr;

      /* Mise � jour du d�compte des pi�ces (les pions ne sont pas compt�s).*/
      if ((board[move->to] & 0x7) > PAWN) {

        piece_count++;
      }

      /* La fiche associ�e est mise � jour. */
      *move->captured_ptr = move->to;
    }
  }

  /* Si la pi�ce d�plac�e �tait un roi, */
  if ((board[move->from] & 0x7) == KING) {

    /* alors le programme m�morise sa nouvelle position. */
    king[color] = move->from;

    /* Si c'�tait un petit roque la tour 'H' est d�plac�e �galement. */
    if (move->status == KING_CASTLING) {

      /* M�morisation des cases pour �viter des calculs inutiles. */
      int sq0 = 98 - 70 * color;
      int sq1 = sq0 - 2;

      /* Mise � jour des informations de la case d'arriv�e. */
      board[sq0] = color ? WROOK : BROOK;
      pieces_ptr[sq0] = pieces_ptr[sq1];

      /* Indique que la tour n'a pas boug�. */
      moved[sq0] = 0;

      /* Mise � jour de la fiche associ�e. */
      *pieces_ptr[sq0] = sq0;

      /* Effacement des informations de la case de d�part. */
      board[sq1] = NONE;
    }

    /* Si c'�tait un grand roque la tour 'A' est d�plac�e �galement. */
    if (move->status == QUEEN_CASTLING) {

      /* M�morisation des cases pour �viter des calculs inutiles. */
      int sq0 = 91 - 70 * color;
      int sq1 = sq0 + 3;

      /* Mise � jour des informations de la case d'arriv�e. */
      board[sq0] = color ? WROOK : BROOK;
      pieces_ptr[sq0] = pieces_ptr[sq1];

      /* Indique que la tour n'a pas boug�. */
      moved[sq0] = 0;

      /* Mise � jour de la fiche associ�e. */
      *pieces_ptr[sq0] = sq0;

      /* Effacement des informations de la case de d�part. */
      board[sq1] = NONE;
    }
  }
  /* Si c'�tait une promotion, la nature de la pi�ce est chang�e. */
  else if (move->status == PROMOTION) {

    board[move->from] = color ? WPAWN : BPAWN;
  }

  /* Mise � jour du num�ro du coup de la partie. */
  if (active_color == WHITE) {

    fullmove--;
  }

  /* Le trait passe � la couleur oppos�e. */
  active_color ^= 1;                                                                               DBG_VERIFY_BOARD_PIECES("end of unmake")
}
/* End of function : unmake */

/**************************************************************************************************
  Function     : verify_moveid
  Description  : Pour v�rifier si un nombre correspond � l'identifiant d'un coup l�gal dans la
                 position courante.
  Parameters   : in  - identifiant d'un coup � v�rifier
               : out - coup l�gal correspondant � cet identifiant (s'il existe)
  Return value : Un coup l�gal est trouv� (true) ou non (false).
  Validation   : 1
**************************************************************************************************/
bool verify_moveid (int moveid, move_s *move) {                                                    DBG_VERIFY_MOVEID_CALL

/* --- Local data ------------------------------------------------------------------------------ */

bool legal = false;               /* Valeur de retour de la fonction. */

int moves_number;                 /* Nombre de coups g�n�r�s. */

move_s moves_list[MAX_MOVES];     /* Pour ranger les coups g�n�r�s. */

/* --- Function code --------------------------------------------------------------------------- */DBG_VERIFY_MOVEID_START

  /* Recherche la liste des coups possibles dans la position courante. */
  moves_number = moves.generate (moves_list, false);

  /* Parcourt la liste obtenue. */
  do {

    /* Si l'identifiant en entr�e correspond � celui d'un coup possible, */
    if (moveid == moves_list[moves_number].moveid) {

      /* alors ce dernier est jou� sur l'�chiquier, */
      moves.make (&moves_list[moves_number]);

      /* pour ensuite v�rifier sa l�galit� dans la position courante. */
      if (moves.is_legal (&moves_list[moves_number])) {

        legal = true;
        *move = moves_list[moves_number];
      }

      /* La position d'avant le test est remise en place. */
      moves.unmake (&moves_list[moves_number]);
    }

  } while (!legal && --moves_number);

  return legal;
}
/* End of function : verify_moveid */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/

moves_module_s moves = {

  compute_moveid,
  convert_pgm_move,
  generate,
  is_attacked,
  is_legal,
  make,
  tree,
  unmake,
  verify_moveid
};
