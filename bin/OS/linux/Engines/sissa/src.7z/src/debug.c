/**************************************************************************************************
  File : debug.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Diverses fonctions utilis�es pour d�boguer ou tester le programme.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "debug.h"
#include "hash.h"
#include "tools.h"
#include "ttable.h"
#include "uci.h"

/**************************************************************************************************
  Data :
**************************************************************************************************/

#ifdef DEBUG

/* ------------------------------------------------------------------------------------------------
   Variables de comptage des appels aux diff�rentes fonctions du programme :
------------------------------------------------------------------------------------------------ */

/* Du module : book */
int select_move_calls = 0;

/* Du module : evaluate */
int evaluate_pieces_calls = 0;
int evaluate_position_calls = 0;

/* Du module : game */
int game_check_phase_calls = 0;
int game_init_calls = 0;
int game_go_on_calls = 0;

/* Du module : hash */
int compute_h_position_calls = 0;
int generate_random_calls = 0;
int init_h_values_calls = 0;

/* Du module : main */
int call_uci_function_calls = 0;
int exec_cmd_calls = 0;
int exec_dbg_cmd_calls = 0;
int init_program_calls = 0;
int main_calls = 0;

/* Du module : moves */
int compute_moveid_calls = 0;
int convert_pgm_move_calls = 0;
int generate_calls = 0;
int is_attacked_calls = 0;
int is_legal_calls = 0;
int make_calls = 0;
int unmake_calls = 0;
int verify_moveid_calls = 0;

/* Du module : pgn */
int associate_move_calls = 0;
int convert_file_calls = 0;

/* Du module : search */
int apply_heuristics_calls = 0;
int first_search_calls = 0;
int is_repeated_calls = 0;
int pick_move_calls = 0;
int quiescence_search_calls = 0;
int search_calls = 0;
int sort_moves_calls = 0;
int start_calls = 0;
int update_killers_calls = 0;

/* Du module : tools */
int compute_time_calls = 0;
int print_board_calls = 0;
int read_config_file_calls = 0;
int read_input_calls = 0;
int send_output_calls = 0;
int update_pieces_calls = 0;

/* Du module : ttable */
int free_ttable_calls = 0;
int init_ttable_calls = 0;
int read_ttable_calls = 0;
int reset_ttable_calls = 0;
int search_tt_pv_calls = 0;
int write_ttable_calls = 0;

/* Nombre de collisions lors de l'�criture dans la table de transposition. */
unsigned long int tt_collisions = 0;
/* Pour voir la r�partition des informations dans la table de transposition. */
unsigned long int *tt_repartition;

/* Du module : uci */
int go_calls = 0;
int info_calls = 0;
int isready_calls = 0;
int position_calls = 0;
int quit_calls = 0;
int setoption_calls = 0;
int uci_cmd_calls = 0;
int ucinewgame_calls = 0;

/* ------------------------------------------------------------------------------------------------
   Autres variables de d�bogage :
------------------------------------------------------------------------------------------------ */

/* Fichier pour enregistrer les informations de d�bogage du module d'�valuation : */
FILE *debug_eval_file;

/* Fichier pour enregistrer les informations de d�bogage : */
FILE *debug_file;

/* Fichier pour enregistrer les informations de d�bogage du module de recherche : */
FILE *debug_tree_file;

/* Indique si l'�valuation doit �tre d�bogu�e. */
bool debug_evaluation;

/* Indique le d�bogage de l'arbre de recherche. */
bool debug_tree;

/* Nom du fichier de d�bogage. */
char debug_file_name[STRING_LENGTH];

/* Rang du fichier de d�bogage. */
int debug_file_indice = 1;

/* Nombre d'appels de fonctions en cours de d�bogage depuis le dernier d�coupage. */
int debug_calls;

/* Num�ro du noeud en cours de d�bogage pour la construction de l'arbre. */
int debug_node;

/* Nombre total d'appels de fonctions comptabilis�s lors d'une ex�cution du programme. */
unsigned long int total_calls = 0;

/* Valeurs limites pour le d�bogage : */
unsigned long int debug_calls_limit;
unsigned long int debug_calls_max;
unsigned long int debug_calls_min;

#endif /* DEBUG */

/* Nombre d'appels � la fonction dump. */
int dump_number = 0;

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : close_debug_file
  Description  : Fermeture du fichier de d�bogage.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void close_debug_file (void) {

#ifdef DEBUG

  fclose (debug_file);

#endif /* DEBUG */
}
/* End of function : close_debug_file */

/**************************************************************************************************
  Function     : dump
  Description  : Enregistre dans un fichier les donn�es du programme.
  Parameters   : in  - commentaire
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void dump (char comment[]) {

/* --- Local data ------------------------------------------------------------------------------ */

FILE *dump_file;   /* Fichier pour enregistrer les informations du programme. */

int square;        /* Case de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Ouverture du fichier. */
  if ((dump_file = fopen (DUMP_FILE, "a")) == NULL) {

    tools.send_output (true, "\n   ERROR : %s can't open the dump file %s !\n",
      PRODUCT_NAME, DUMP_FILE);
  }
  else {

    fprintf (dump_file, "\n**************************************** %d : %s\n",
      ++dump_number, comment);

    /* Impression de la position courante. */
    fprintf (dump_file, "* Current position :");
    tools.print_board (dump_file);

    /* Listage des coups de la partie. */
    fprintf (dump_file, "* Game moves     : ");
    for (int i = 0; i < game_ply; i++) {

      fprintf (dump_file, " %c%d%c%d%c",
        file[played_moves[i].from] + 'a' - 1, rank[played_moves[i].from],
        file[played_moves[i].to] + 'a' - 1, rank[played_moves[i].to],
        played_moves[i].promoted ? PIECE(played_moves[i].promoted) : ' ');
    }

    /* Listage des coups de la variante principale. */
    fprintf (dump_file, "\n* Moves of PV[1] : ");
    for (int i = 1; i < pv_length[1]; i++) {

      fprintf (dump_file, " %c%d%c%d%c",
        file[pv[1][i].from] + 'a' - 1, rank[pv[1][i].from],
        file[pv[1][i].to] + 'a' - 1, rank[pv[1][i].to],
        pv[1][i].promoted ? PIECE(pv[1][i].promoted) : ' ');
    }

    /* Enregistrement des donn�es globales : */
    fprintf (dump_file, "\n* Global data values :\n");
    fprintf (dump_file, "  active_color       :  %d - ", active_color);
    fprintf (dump_file, "computer_color     :  %d\n", computer_color);

    fprintf (dump_file, "  base_time (en s)   :  %d - ", base_time / 1000);
    fprintf (dump_file, "time_for_move (en s)  %d\n", time_for_move / 1000);

    fprintf (dump_file, "  use_book           :  %d - ", use_book);
    fprintf (dump_file, "use_log            :  %d - ", use_log);
    fprintf (dump_file, "show_board         :  %d\n", show_board);

    fprintf (dump_file, "  forced_mode        :  %d - ", forced_mode);
    fprintf (dump_file, "uci_mode           :  %d - ", uci_mode);
    fprintf (dump_file, "search algorithms  : %s %s %s %s %s\n",
      use_captured ?  "C" : "c", use_history ?   "H" : "h",
      use_killers ?   "K" : "k", use_null_move ? "N" : "n",
      use_pv ?        "P" : "p");

    if (EP_SQUARE) {

      fprintf (dump_file, "  ep_square          : %c%d - ",
        file[EP_SQUARE] + 'a' - 1, rank[EP_SQUARE]);
    }
    else {

      fprintf (dump_file, "  ep_square          : .. - ");
    }
    fprintf (dump_file, "castle_status[%2d]  : %2x - ",
      game_ply, castle_status[game_ply]);
    fprintf (dump_file, "king position (w/b): %c%d/%c%d\n",
      file[king[WHITE]] + 'a' - 1, rank[king[WHITE]],
      file[king[BLACK]] + 'a' - 1, rank[king[BLACK]]);

    fprintf (dump_file, "  game_ply           : %2d - ", game_ply);
    fprintf (dump_file, "fullmove           : %2d - ", fullmove);
    fprintf (dump_file, "halfmove           : %2d\n", halfmove);
    fprintf (dump_file, "  iterative_depth    : %2d - ", iterative_depth);
    fprintf (dump_file, "search_ply         : %2d - ", search_ply);
    fprintf (dump_file, "nodes              : %d\n", nodes);
    fprintf (dump_file, "  piece_count        : %2d - ", piece_count);
    fprintf (dump_file, "start_piece_count  : %2d - ", start_piece_count);
    fprintf (dump_file, "pieces_number (w/b): %d/%d\n",
      pieces_number[BLACK], pieces_number[WHITE]);
    fprintf (dump_file, "  repeats            :  %d - ", repeats);
    fprintf (dump_file, "result             :  %d\n", result);
    fprintf (dump_file, "  start_position     : %s\n", start_position);
    fprintf (dump_file, "  h_position         : %16llx       - ", h_position);
    fprintf (dump_file, "tt_address         : %lu/%lu\n", tt_occupied, tt_entries);
#ifdef DEBUG
    fprintf (dump_file, "  tt_collisions      : %lu\n", tt_collisions);
#endif /* DEBUG */

    /* Enregistrement de la table des pi�ces : */
    fprintf (dump_file, "* Content of pieces table :\n");
    for (int i = 1; i <= max(pieces_number[BLACK], pieces_number[WHITE]); i++) {

      if (i <= pieces_number[WHITE]) {

        fprintf (dump_file, "  pieces[WHITE][%2d] %c%d - address %8x - ", i,
          file[pieces[WHITE][i]] + 'a' - 1,
          rank[pieces[WHITE][i]], (unsigned int) &pieces[WHITE][i]);
      }
      else {

        fprintf (dump_file, "                                          - ");
      }

      if (i <= pieces_number[BLACK]) {

        fprintf (dump_file, "pieces[BLACK][%2d] %c%d - address %8x\n", i,
          file[pieces[BLACK][i]] + 'a' - 1,
          rank[pieces[BLACK][i]], (unsigned int) &pieces[BLACK][i]);
      }
      else {

        fprintf (dump_file, "\n");
      }
    }

    /* Enregistrement de l'�chiquier : */
    fprintf (dump_file, "* Content of board table :\n");

    for (int y = 1; y <= 8; y++) {

      for (int x = A; x <= H; x++) {

        square = SQUARE;
        if (board[square]) {

          fprintf (dump_file, "  board[%c%d] %2d pieces_ptr %x moved[%2d] %2d\n",
            x + 'a' - 1, y, board[square],
            (unsigned int) pieces_ptr[square], square, moved[square]);
        }
      }
    }

    /* Enregistrement des valeurs de hachage : */
    fprintf (dump_file, "* History of hash positions :\n");
    for (int i = 0; i <= game_ply; i++) {

      fprintf (dump_file, "  h_position_history[%2d] : %16llx\n", i, h_position_history[i]);
    }

    if (!strcmp (comment, "Requested from the command line")) {

      tools.send_output (true, "\n   Data are written in %s (%d).\n", DUMP_FILE, dump_number);
    }

    /* Fermeture du fichier. */
    fclose (dump_file);
  }
}
/* End of function : dump */

/**************************************************************************************************
  Function     : open_debug_file
  Description  : Ouverture des fichiers utilis�s pour le d�bogage du programme. Cela concerne le
                 d�bogage g�n�ral avec l'encha�nement des fonctions.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void open_debug_file (void) {

/* --- Local data ------------------------------------------------------------------------------ */

#ifdef DEBUG

char string_indice[4];  /* Pour num�roter les fichiers de d�bogage. */

/* --- Function code --------------------------------------------------------------------------- */

  sprintf (debug_file_name, DEBUG_FILE);
  sprintf (string_indice, "%d", debug_file_indice);
  strcat (debug_file_name, string_indice);
  strcat (debug_file_name, ".txt");

  if ((debug_file = fopen (debug_file_name, "w")) == NULL) {

    printf ("   ERROR : %s can't open the debug file %s !\n", PRODUCT_NAME, debug_file_name);

    uci.quit (EXIT_FAILURE);
  }

#endif /* DEBUG */
}
/* End of function : open_debug_file */

/**************************************************************************************************
  Function     : print
  Description  : Pour enregistrer des informations dans le fichier de d�bogage. Afin de limiter le
                 volume d'informations, les �critures seront born�es entre deux valeurs du nombre
                 total de fonctions appel�es.
  Parameters   : in  - format d'impression
                 in  - liste des donn�es � imprimer
  Return value : nombre de caract�res �crits
  Validation   : 1
**************************************************************************************************/
int print (const char *format, ...) {

/* --- Local data ------------------------------------------------------------------------------ */

int size = 0;      /* Nombre de caract�res �crits. */

#ifdef DEBUG

va_list list;      /* Liste variable des arguments. */

/* --- Function code --------------------------------------------------------------------------- */

  if (total_calls >= debug_calls_min && total_calls < debug_calls_max) {

    /* Initialisation de la liste des param�tres : */
    va_start (list, format);

    /* Ecriture des donn�es dans le fichier de d�bogage : */
    size = vfprintf (debug_file, format, list);
    fflush (debug_file);

    /* Fin de lecture de la liste des param�tres : */
    va_end (list);
  }

#endif /* DEBUG */

  return size;
}
/* End of function : print */

/**************************************************************************************************
  Function     : print_statistics
  Description  : Enregistre dans le fichier journal des informations statistiques sur les appels de
                 fonction.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void print_statistics (void) {

#ifdef DEBUG

  if (use_log) {

    fprintf (log_file, "\nStatistics about function calls :");
    fprintf (log_file, "\n---------------------------------\n");

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* book module                 *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "select_move         : %9d\n", select_move_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* evaluate module             *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "evaluate_position   : %9d\n", evaluate_position_calls);
    fprintf (log_file, "evaluate_pieces     : %9d\n", evaluate_pieces_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* game module                 *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "check_phase         : %9d\n", game_check_phase_calls);
    fprintf (log_file, "initialize          : %9d\n", game_init_calls);
    fprintf (log_file, "go_on               : %9d\n", game_go_on_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* hash module                 *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "compute_h_position  : %9d\n", compute_h_position_calls);
    fprintf (log_file, "generate_random     : %9d\n", generate_random_calls);
    fprintf (log_file, "initialize_h_values : %9d\n", init_h_values_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* main module                 *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "call_uci_function   : %9d\n", call_uci_function_calls);
    fprintf (log_file, "execute_command     : %9d\n", exec_cmd_calls);
    fprintf (log_file, "execute_debug_com.  : %9d\n", exec_dbg_cmd_calls);
    fprintf (log_file, "initialize_program  : %9d\n", init_program_calls);
    fprintf (log_file, "main                : %9d\n", main_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* moves module                *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "compute_moveid      : %9d\n", compute_moveid_calls);
    fprintf (log_file, "convert_pgm_move    : %9d\n", convert_pgm_move_calls);
    fprintf (log_file, "generate            : %9d\n", generate_calls);
    fprintf (log_file, "is_attacked         : %9d\n", is_attacked_calls);
    fprintf (log_file, "is_legal            : %9d\n", is_legal_calls);
    fprintf (log_file, "make                : %9d\n", make_calls);
    fprintf (log_file, "unmake              : %9d\n", unmake_calls);
    fprintf (log_file, "verify_moveid       : %9d\n", verify_moveid_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* pgn module                  *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "associate_move      : %9d\n", associate_move_calls);
    fprintf (log_file, "convert_file        : %9d\n", convert_file_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* search module               *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "apply_heuristics    : %9d\n", apply_heuristics_calls);
    fprintf (log_file, "first_search        : %9d\n", first_search_calls);
    fprintf (log_file, "is_repeated         : %9d\n", is_repeated_calls);
    fprintf (log_file, "pick_move           : %9d\n", pick_move_calls);
    fprintf (log_file, "quiescence_search   : %9d\n", quiescence_search_calls);
    fprintf (log_file, "search              : %9d\n", search_calls);
    fprintf (log_file, "sort_moves          : %9d\n", sort_moves_calls);
    fprintf (log_file, "start               : %9d\n", start_calls);
    fprintf (log_file, "update_killers      : %9d\n", update_killers_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* tools module                *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "compute_time        : %9d\n", compute_time_calls);
    fprintf (log_file, "print_board         : %9d\n", print_board_calls);
    fprintf (log_file, "read_config_file    : %9d\n", read_config_file_calls);
    fprintf (log_file, "read_input          : %9d\n", read_input_calls);
    fprintf (log_file, "send_output         : %9d\n", send_output_calls);
    fprintf (log_file, "update_pieces       : %9d\n", update_pieces_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* ttable module               *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "free_ttable         : %9d\n", free_ttable_calls);
    fprintf (log_file, "initialize_ttable   : %9d\n", init_ttable_calls);
    fprintf (log_file, "read_ttable         : %9d\n", read_ttable_calls);
    fprintf (log_file, "reset_ttable        : %9d\n", reset_ttable_calls);
    fprintf (log_file, "search_tt_pv        : %9d\n", search_tt_pv_calls);
    fprintf (log_file, "write_ttable        : %9d\n", write_ttable_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "* uci module                  *\n");
    fprintf (log_file, "*******************************\n");
    fprintf (log_file, "go                  : %9d\n", go_calls);
    fprintf (log_file, "info                : %9d\n", info_calls);
    fprintf (log_file, "isready             : %9d\n", isready_calls);
    fprintf (log_file, "position            : %9d\n", position_calls);
    fprintf (log_file, "quit                : %9d\n", quit_calls);
    fprintf (log_file, "setoption           : %9d\n", setoption_calls);
    fprintf (log_file, "uci_command         : %9d\n", uci_cmd_calls);
    fprintf (log_file, "ucinewgame          : %9d\n", ucinewgame_calls);

    fprintf (log_file, "\n*******************************\n");
    fprintf (log_file, "Total calls         : %9lu\n", total_calls);
  }

#endif /* DEBUG */
}
/* End of function : print_statistics */

/**************************************************************************************************
  Function     : split_debug_file
  Description  : En raison du volume important des donn�es, le fichier de d�bogage est
                 r�guli�rement d�coup� en fonction du nombre total de fonctions appel�es.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void split_debug_file (void) {

#ifdef DEBUG

  if (total_calls > debug_calls_min && total_calls <= debug_calls_max) {

    /* Pour chaque appel de fonction, si la limite pour un fichier de d�bogage est atteinte, */
    if (total_calls % debug_calls_limit == 0) {

      /* alors on repart pour un nouveau cycle avec un nouveau fichier. */
      debug_file_indice++;

      debug.close_debug_file ();
      debug.open_debug_file ();
    }
  }

#endif /* DEBUG */
}
/* End of function : split_debug_file */

/**************************************************************************************************
  Function     : test_hash
  Description  : Permet de tester les collisions sur les valeurs de hachage. L'id�e est de v�rifier
                 que sur une partie, la valeur de hachage d'une position est identique uniquement
                 pour des positions identiques.
                 Cette fonction est int�ressante dans le cas o� la fonction de g�n�ration des
                 nombres al�atoires est modifi�e.
                 L'analyse est faite � partir d'un fichier de parties au format LAN (la commande
                 "pgn" permet de convertir un fichier de parties au format PGN).
  Parameters   : aucun
  Return value : aucun
  Validation   : 1
**************************************************************************************************/
void test_hash (void) {

/* --- Local data ------------------------------------------------------------------------------ */

FILE *lan_games_file;            /* Fichier contenant les parties � tester. */
FILE *hash_test_file;            /* Fichier de r�sultat du test. */

bool legal_move;                 /* Indique la l�galit� d'un coup. */

char game[STRING_LENGTH];        /* Partie lue dans le fichier "games_files". */
char input_line[STRING_LENGTH];  /* Partie lue dans le fichier "games_files". */
char lan_move[6];                /* Coup apr�s conversion en notation alg�brique. */
char input_lan_move[6];          /* Coup lu dans le fichier des parties. */
char *pointer;                   /* Pour parcourir la cha�ne d'une partie donn�e en entr�e. */

int count_games = 0;             /* Nombre de parties trait�es. */
int collisions = 0;              /* Nombre de collisions des valeurs de hachage. */
int moves_number;                /* Nombre de coups g�n�r�s. */
int position_id[MAX_MOVES * 2][11];    /* Ensemble de nombres pour identifier une position. */

move_s moves_list[MAX_MOVES];    /* Pour ranger les coups g�n�r�s. */

/* --- Function code --------------------------------------------------------------------------- */

  if ((lan_games_file = fopen (lan_games_file_path, "r")) == NULL) {

    tools.send_output (true,
      "\n   ERROR : %s can't open the LAN games file,\n"
      "           you can build it with the pgn command.\n",
      PRODUCT_NAME);
    return;
  }

  if ((hash_test_file = fopen (HASH_TEST_FILE, "w")) == NULL) {

    tools.send_output (true,
      "\n   ERROR : %s can't open the hash test file !\n"
      "           (%s)\n", PRODUCT_NAME, HASH_TEST_FILE);
    fclose (lan_games_file);
    return;
  }

  tools.send_output (true, "\n   Please wait, the test is running ...\n");
  tools.send_output (true, "   (File of games : %s)\n", pgn_games_file_path);

  printf ("\n   Each point equal 100 games, a line 5000 games.\n   ");

  while (!feof (lan_games_file)) {

    count_games++;

    if ((count_games % 100) == 0) {

      printf (".");

      if ((count_games % 5000) == 0) {

        printf (" : %3d collisions\n   ", collisions);
      }
    }

    /* R�initialisation des informations pour passage � la partie suivante. */
    uci.ucinewgame ();

    /* Lecture d'une partie dans le fichier. */
    fgets (input_line, STRING_LENGTH, lan_games_file);

    strcpy (game, input_line);

    /* Tant que la fin de la partie n'est pas atteinte, */
    for (pointer = strtok (game, " ");
         pointer != NULL && isalpha(pointer[0]);
         pointer = strtok (NULL, " ")) {

      /* Chaque mot trouv� est isol�. */
      strcpy (input_lan_move, pointer);

      /* Recherche la liste des coups possibles dans la position courante. */
      moves_number = moves.generate (moves_list, false);

      legal_move = false;

      /* Parcourt la liste obtenue. */
      do {

        /* Conversion du coup pour permettre la comparaison. */
        moves.convert_pgm_move (&moves_list[moves_number], lan_move);

        /* Si le coup entr� correspond � un coup possible, */
        if (!strcmp (input_lan_move, lan_move)) {

          /* alors il est jou� sur l'�chiquier, */
          moves.make (&moves_list[moves_number]);

          /* pour v�rifier sa l�galit�. */
          if (moves.is_legal (&moves_list[moves_number])) {

            legal_move = true;

            /* M�morise les caract�ristiques de la position courante sans risque de collision ou
               perte d'information. Le tableau contiendra toutes les caract�ristiques d'une
               position sur 9 entiers de 4 octets. */
            memset (position_id [game_ply], 0, sizeof (position_id [game_ply]));

            /* M�morise la couleur au trait, l'�tat des roques et une �ventuelle
               prise en passant sur un entier de 4 octets. */
            position_id [game_ply][0] = active_color;
            position_id [game_ply][0] = (position_id [game_ply][0] << 4)
              + (castle_status [game_ply] & 0xf);
            position_id [game_ply][0] = (position_id [game_ply][0] << 4) + ep_square [game_ply];

            /* M�morise pour chaque rang�e, sur un entier sur 4 octets, les
               pi�ces pr�sentes sur chaque case. */
            for (int x = A; x <= H; x++) {

              for (int y = 1; y <= 8; y++) {

                position_id[game_ply][y] = (position_id[game_ply][y] << 4) + board [SQUARE];
              }
            }

            /* Pour tous les coups de la partie, */
            for (int i = 0; i < game_ply; i++) {

              /* si la valeur de hachage pour une position se retrouve dans les valeurs m�moris�es
                 pour les positions pr�c�dentes, */
              if (h_position_history[i] == h_position) {

                /* le programmme va v�rifier que les toutes les informations de la position
                   m�moris�es dans le tableau position_id sont identiques. */
                for (int k = 0; k < 9; k++) {

                  /* Si une information est diff�rente entre les deux positions, */
                  if (position_id [game_ply][k] != position_id [i][k]) {

                    /* alors cela signifie que deux valeurs de hachage identiques sont les m�mes
                       pour deux positions diff�rentes. Il y a alors une collision. */
                    collisions++;

                    fprintf (hash_test_file, "game %4d : %s", count_games, input_line);

                    fprintf (hash_test_file, "game_ply %3d - hposition %16llx :", i,
                      h_position_history[i]);

                    for (int k = 0; k < 9; k++) {

                      fprintf (hash_test_file, "%16llx,", position_id[i][k]);
                    }
                    fprintf (hash_test_file, "\n");

                    fprintf (hash_test_file, "game_ply %3d - hposition %16llx :",
                      game_ply, h_position);

                    for (int k = 0; k < 9; k++) {

                      fprintf (hash_test_file, "%16llx,", position_id[game_ply][k]);
                    }
                    fprintf (hash_test_file, "\n\n");
                  }
                }
              }
            }
          }
        }
      } while (--moves_number && !legal_move);

      if (!legal_move) {

        /* Le coup en cours de traitement ne semble pas correct. */
        fprintf (hash_test_file, "\n   ERROR : Invalid move. "
          "(Game %d, %d, %s)\n", count_games, game_ply + 1, input_lan_move);
        fprintf (hash_test_file, "%s\n", input_line);

        /* Le programme passe � la partie suivante. */
        break;
      }
    }
  }
  printf ("\n");

  /* Fermeture des fichiers utilis�s. */
  fclose (lan_games_file);
  fclose (hash_test_file);

  /* Affichage du r�sultat du test. */
  tools.send_output (true, "\n   %s has detected %d collision(s) for %d games.\n",
    PRODUCT_NAME, collisions, count_games);

  if (collisions) {

    tools.send_output (true, "   The result is written in the hash test file %s.\n",
      HASH_TEST_FILE);
  }
}
/* End of function : test_hash */

/**************************************************************************************************
  Function     : trace
  Description  : Pour tracer l'appel � chaque fonction du programme. Tous les appels sont compt�s,
                 mais pour limiter le volume d'informations � analyser, seul l'appel � quelques
                 fonctions cl�s sera indiqu� dans le fichier de d�bogage.
  Parameters   : in  - nom de la fonction
                 in  - indique si l'appel doit �tre �crit dans le fichier de d�bogage
                 out - nombre d'appels � la fonction
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void trace (char function[], bool is_printed, int *number_of_calls) {

#ifdef DEBUG

  total_calls++;                                                                                   DBG_SPLIT_DEBUG_FILES

  if (is_printed) {

    debug.print ("%9d (%9d) - %20s", total_calls, nodes, function);
  }

  (*number_of_calls)++;

#endif /* DEBUG */
}
/* End of function : trace */

/**************************************************************************************************
  Function     : verify_board_pieces
  Description  : Pour v�rifier la coh�rence des tables "board" et "pieces". Actuellement cette
                 v�rification porte uniquement sur la couleur de la pi�ce pr�sente sur une case qui
                 doit pointer vers la table des pi�ces de la bonne couleur.
  Parameters   : in  - commentaire
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void verify_board_pieces (char comment[]) {

  for (int color = BLACK; color <= WHITE; color++) {

    for (int piece = 1; piece <= pieces_number[color]; piece++) {

      if (pieces[color][piece]) {

        if (board[pieces[color][piece]] >> 3 != color) {

          tools.send_output (true, "   ERROR between board and pieces table.");
          debug.dump (comment);

          uci.quit (EXIT_FAILURE);
        }
      }
    }
  }
}
/* End of function : verify_board_pieces */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/

debug_module_s debug = {

  close_debug_file,
  dump,
  open_debug_file,
  print,
  print_statistics,
  split_debug_file,
  test_hash,
  trace,
  verify_board_pieces
};
