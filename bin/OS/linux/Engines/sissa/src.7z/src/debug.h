/**************************************************************************************************
  File : debug.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "debug".
**************************************************************************************************/

#ifndef DEBUG_H
#define DEBUG_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/**************************************************************************************************
  Constants :
**************************************************************************************************/

/* Nom des fichiers utilis�s pour le d�bogage du programme : */
#define DEBUG_EVAL_FILE      "log/debug_eval.txt"
#define DEBUG_FILE           "log/debug"
#define DEBUG_TREE_FILE      "log/debug_tree.txt"
#define DUMP_FILE            "log/dump_file.txt"
#define HASH_TEST_FILE       "log/hash_test.txt"

/* Nombre maximum de noeuds dans le fichier de d�bogage de l'arbre. */
#define DEBUG_TREE_LIMIT     2000000

/**************************************************************************************************
  Macro instructions :
**************************************************************************************************/

/* ************************************************************************************************
 Du module : book
**************************************************************************************************/

#ifdef DEBUG

#define DBG_SELECT_MOVE_CALL { \
  debug.trace ("select_move\n", true, &select_move_calls); \
}
#define DBG_SELECT_MOVE_0 { \
  debug.print("\n"); \
}
#define DBG_SELECT_MOVE_1_1 { \
  debug.print("game_ply %d - played moves",game_ply); \
}
#define DBG_SELECT_MOVE_1_2 { \
  debug.print(" .%s.",lan_played_moves[i]); \
}
#define DBG_SELECT_MOVE_2 { \
  debug.print ("\nbook line (size %d) .%s.\n", \
    strlen (opening_line), opening_line); \
}
#define DBG_SELECT_MOVE_3 { \
  debug.print ("  compare played move .%s. and book move .%s.\n", \
    lan_played_moves[i],pointer); \
}
#define DBG_SELECT_MOVE_4 { \
  debug.print ("  played move .%s. is found in %d\n", pointer, j+1); \
}
#define DBG_SELECT_MOVE_5 { \
  debug.print ("  played move .%s. is not found \n", lan_played_moves[i]); \
}
#define DBG_SELECT_MOVE_6 { \
  debug.print ("  line is correct\n"); \
}
#define DBG_SELECT_MOVE_8 { \
  debug.print ("selected_line (%d/%d) .%s.\n\n", \
    selected_line+1, count_lines, opening_lines[selected_line]); \
}
#define DBG_SELECT_MOVE_9 { \
  debug.print ("  compare book move .%s. and played move .%s.\n", \
    lan_played_moves[i],pointer); \
}
#define DBG_SELECT_MOVE_10 { \
  debug.print ("  move to play .%s. in %d\n", pointer, j); \
}

#else

#define DBG_SELECT_MOVE_CALL
#define DBG_SELECT_MOVE_0
#define DBG_SELECT_MOVE_1_1
#define DBG_SELECT_MOVE_1_2
#define DBG_SELECT_MOVE_2
#define DBG_SELECT_MOVE_3
#define DBG_SELECT_MOVE_4
#define DBG_SELECT_MOVE_5
#define DBG_SELECT_MOVE_6
#define DBG_SELECT_MOVE_8
#define DBG_SELECT_MOVE_9
#define DBG_SELECT_MOVE_10

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : evaluate
**************************************************************************************************/

#ifdef DEBUG

#define DBG_CHECK_GAME_PHASE_CALL { \
  debug.trace ("check_game_phase", true, &check_game_phase_calls); \
}
#define DBG_CHECK_GAME_PHASE_START { \
  debug.print (" : color %d", color); \
}
#define DBG_CHECK_GAME_PHASE_END { \
  debug.print (" -> phase %s\n", game_phase == ENDGAME ? "end of game" : \
    game_phase == MIDDLE ? "middle of game" : "opening"); \
}
#define DBG_EVALUATE_PIECES_CALL { \
  debug.trace ("evaluate_pieces\n", false, &evaluate_pieces_calls); \
}
#define DBG_EVALUATE_PIECES_1(p1, p2) { \
  if (debug_evaluation) \
    fprintf (debug_eval_file, "%c %-6s %c%d, score %5d, %-s\n", \
      color ? 'w' : 'b', p1 , x + 'a' - 1, y, score, p2); \
}
#define DBG_EVALUATE_PIECES_2(p1, p2) { \
  if (debug_evaluation) \
    fprintf (debug_eval_file, "%c %-8s, score %5d, %-s\n", \
      color, p1 , score, p2); \
}
#define DBG_EVALUATE_POSITION_CALL { \
  debug.trace ("evaluate_position\n", true, &evaluate_position_calls); \
}
#define DBG_EVALUATE_POSITION_START { \
  if (debug_evaluation) { \
    tools.print_board (debug_eval_file); \
    fprintf (debug_eval_file, "\n"); \
  } \
}
#define DBG_EVALUATE_POSITION_1 { \
  if (debug_evaluation) { \
    for (int j = 1; j <= 8; j++) { \
      fprintf (debug_eval_file, "pawns[%d][%d] %d - pawn_rank[%d][%d] %d  -  " \
        "pawns[%d][%d] %d - pawn_rank[%d][%d] %d\n", \
        BLACK, j, pawns[BLACK][j], BLACK, j, pawn_rank[BLACK][j], \
        WHITE, j, pawns[WHITE][j], WHITE, j, pawn_rank[WHITE][j]); \
    } \
    fprintf (debug_eval_file, "\n"); \
  } \
}
#define DBG_EVALUATE_POSITION_2(p1, p2) { \
  if (debug_evaluation) \
    fprintf (debug_eval_file, "%-8s, score %5d, %-s\n", p1 , score, p2); \
}
#define DBG_EVALUATE_POSITION_END { \
  debug.print ("evaluate_position -> active_color %d - score %d\n", \
    active_color, score); \
}

#else

#define DBG_CHECK_GAME_PHASE_CALL
#define DBG_CHECK_GAME_PHASE_START
#define DBG_CHECK_GAME_PHASE_END
#define DBG_EVALUATE_PIECES_CALL
#define DBG_EVALUATE_PIECES_1(p1, p2)
#define DBG_EVALUATE_PIECES_2(p1, p2)
#define DBG_EVALUATE_POSITION_CALL
#define DBG_EVALUATE_POSITION_START
#define DBG_EVALUATE_POSITION_1
#define DBG_EVALUATE_POSITION_2(p1, p2)
#define DBG_EVALUATE_POSITION_END

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : game
**************************************************************************************************/

#ifdef DEBUG

#define DBG_GAME_CHECK_PHASE_CALL { \
  debug.trace ("game_check_phase", true, &game_check_phase_calls); \
}
#define DBG_GAME_CHECK_PHASE_START { \
  debug.print (" : color %d", color); \
}
#define DBG_GAME_CHECK_PHASE_END { \
  debug.print (" -> phase %s\n", game_phase == ENDGAME ? "end of game" : \
    game_phase == MIDDLE ? "middle of game" : "opening"); \
}
#define DBG_GAME_GO_ON_CALL { \
  debug.trace ("game_go_on\n", false, &game_go_on_calls); \
}
#define DBG_GAME_INITIALIZE_CALL { \
  debug.trace ("game_initialize", true, &game_init_calls); \
}
#define DBG_GAME_INITIALIZE_START { \
  debug.print (" : %s\n", string); \
}

#else

#define DBG_GAME_CHECK_PHASE_CALL
#define DBG_GAME_CHECK_PHASE_START
#define DBG_GAME_CHECK_PHASE_END
#define DBG_GAME_GO_ON_CALL
#define DBG_GAME_INITIALIZE_CALL
#define DBG_GAME_INITIALIZE_START

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : hash
**************************************************************************************************/

#ifdef DEBUG

#define DBG_COMPUTE_H_POSITION_CALL { \
  debug.trace ("compute_h_position", true, &compute_h_position_calls); \
}
#define DBG_COMPUTE_H_POSITION_END { \
  debug.print (" : h_position %llx\n", h_position); \
}
#define DBG_GENERATE_RANDOM_CALL { \
  debug.trace ("generate_random\n", false, &generate_random_calls); \
}
#define DBG_INITIALIZE_H_VALUES_CALL { \
  debug.trace ("initialize_h_values\n", true, &init_h_values_calls); \
}

#else

#define DBG_COMPUTE_H_POSITION_CALL
#define DBG_COMPUTE_H_POSITION_END
#define DBG_GENERATE_RANDOM_CALL
#define DBG_INITIALIZE_H_VALUES_CALL

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : main
**************************************************************************************************/

#ifdef DEBUG

#define DBG_CALL_UCI_FUNCTION_CALL { \
  debug.trace ("call_uci_function", true, &call_uci_function_calls); \
}
#define DBG_CALL_UCI_FUNCTION_START { \
  debug.print (" : %s\n", input); \
}
#define DBG_EXEC_CMD_EVL_1 { \
  debug_evaluation = true; \
  if ((debug_eval_file = fopen (DEBUG_EVAL_FILE, "w")) == NULL) { \
    tools.send_output (true, "\n   ERROR : %s can't open the debug file %s !\n", \
      PRODUCT_NAME, DEBUG_EVAL_FILE); \
  } \
  else { \
}
#define DBG_EXEC_CMD_EVL_2 { \
  debug_evaluation = false; \
  fclose (debug_eval_file); \
  tools.send_output (true, "\n   To debug the evaluation, see the file : " \
    "%s\n", DEBUG_EVAL_FILE); \
  } \
}
#define DBG_EXECUTE_COMMAND_CALL { \
  debug.trace ("execute_command", true, &exec_cmd_calls); \
}
#define DBG_EXECUTE_COMMAND_START { \
  debug.print (" : %s\n", input); \
}
#define DBG_EXECUTE_DEBUG_COMMAND_CALL { \
  debug.trace ("execute_debug_com.", true, &exec_dbg_cmd_calls); \
}
#define DBG_EXECUTE_DEBUG_COMMAND_START { \
  debug.print (" : %s\n", input); \
}
#define DBG_INITIALIZE_PROGRAM_START { \
  debug.open_debug_file (); \
  debug.trace ("main\n", true, &main_calls); \
  debug.trace ("initialize_program\n", true, &init_program_calls); \
  debug.trace ("read_config_file\n", true, &read_config_file_calls); \
}

#else

#define DBG_CALL_UCI_FUNCTION_CALL
#define DBG_CALL_UCI_FUNCTION_START
#define DBG_EXEC_CMD_EVL_1
#define DBG_EXEC_CMD_EVL_2
#define DBG_EXECUTE_COMMAND_CALL
#define DBG_EXECUTE_COMMAND_START
#define DBG_EXECUTE_DEBUG_COMMAND_CALL
#define DBG_EXECUTE_DEBUG_COMMAND_START
#define DBG_INITIALIZE_PROGRAM_START

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : moves
**************************************************************************************************/

#ifdef DEBUG

#define DBG_COMPUTE_MOVEID_CALL { \
  debug.trace ("compute_moveid", true, &compute_moveid_calls); \
}
#define DBG_COMPUTE_MOVEID_START { \
  debug.print (" : %s", lan_move); \
}
#define DBG_COMPUTE_MOVEID_END { \
  debug.print (" -> %d - moveid %x\n", is_possible_move, *moveid); \
}
#define DBG_CONVERT_PGM_MOVE_CALL { \
  debug.trace ("convert_pgm_move\n", false, &convert_pgm_move_calls); \
}
#define DBG_GENERATE_CALL { \
  debug.trace ("generate", true, &generate_calls); \
}
#define DBG_GENERATE_START { \
  debug.print (" : type of search %d\n", captures_only); \
  if (total_calls >= debug_calls_min && total_calls < debug_calls_max) { \
    tools.print_board (debug_file); \
  } \
}
#define DBG_GENERATE_END { \
  debug.print ("moves (%d) :", moves_number); \
  for (int i = 1; i <= moves_number; i++) { \
    debug.print (" %c%d%c%d%c", \
      file[moves[i].from] + 'a' -1, rank[moves[i].from], \
      file[moves[i].to] + 'a' -1, rank[moves[i].to], \
      moves[i].promoted ? PIECE(moves[i].promoted) : ' '); \
  } \
  debug.print ("\n"); \
}
#define DBG_IS_ATTACKED_CALL { \
  debug.trace ("is_attacked", true, &is_attacked_calls); \
}
#define DBG_IS_ATTACKED_START { \
  debug.print (" : %c%d by %s", \
    file[square0] + 'a' - 1, rank[square0], (color ? "white" : "black")); \
}
#define DBG_IS_ATTACKED_END(p1) { \
  debug.print (" = %s\n", p1); \
}
#define DBG_IS_LEGAL_CALL { \
  debug.trace ("is_legal", true, &is_legal_calls); \
}
#define DBG_IS_LEGAL_START { \
  debug.print (" : %d) %s%c%d%c%d%c\n", \
    game_ply, active_color^1 ? "" : " ..... ", \
    file[move->from] + 'a' - 1, rank[move->from], \
    file[move->to] + 'a' - 1, rank[move->to], \
    move->promoted ? PIECE(move->promoted) : ' '); \
}
#define DBG_IS_LEGAL_END { \
  debug.print ("is_legal -> true\n"); \
}
#define DBG_MAKE_CALL { \
  debug.trace ("make", true, &make_calls); \
}
#define DBG_MAKE_START { \
  debug.print (" : %d) %s%c%d%c%d%c%c (status %d moveid %x)\n", \
    game_ply, active_color ? "" : " ..... ", \
    file[move->from] + 'a' - 1, rank[move->from], \
    file[move->to] + 'a' - 1, rank[move->to], \
    move->promoted ? PIECE(move->promoted) : ' ', \
    move->captured ? PIECE(move->captured) : ' ', \
    move->status, \
    move->moveid); \
  debug.print ("make -> make history :"); \
  for (int i = 0; i < game_ply; i++) { \
    debug.print (" %c%d%c%d%c", \
      file[played_moves[i].from] + 'a' - 1, rank[played_moves[i].from], \
      file[played_moves[i].to] + 'a' - 1, rank[played_moves[i].to], \
      played_moves[i].promoted ?  PIECE(played_moves[i].promoted) : ' '); \
  } \
  debug.print ("\n"); \
}
#define DBG_MAKE_END { \
h_value_s tmp_h_position; \
  tmp_h_position = hash.compute_h_position (); \
  debug.print ("make -> new h_position %16llx (from hash module %16llx)\n", \
    h_position, tmp_h_position); \
}
#define DBG_UNMAKE_CALL { \
  debug.trace ("unmake", true, &unmake_calls); \
}
#define DBG_UNMAKE_START { \
  debug.print (" : %d) %s%c%d%c%d%c%c (status %d moveid %x)\n", \
    game_ply, active_color ? " ..... " : "", \
    file[move->from] + 'a' - 1, rank[move->from], \
    file[move->to] + 'a' - 1, rank[move->to], \
    move->promoted ? PIECE(move->promoted) : ' ', \
    move->captured ? PIECE(move->captured) : ' ', \
    move->status, \
    move->moveid); \
}
#define DBG_VERIFY_BOARD_PIECES(p1) { \
  debug.verify_board_pieces (p1); \
}
#define DBG_VERIFY_MOVEID_CALL { \
  debug.trace ("verify_moveid", true, &verify_moveid_calls); \
}
#define DBG_VERIFY_MOVEID_START { \
  debug.print (" : moveid %d\n", moveid); \
}

#else

#define DBG_COMPUTE_MOVEID_CALL
#define DBG_COMPUTE_MOVEID_START
#define DBG_COMPUTE_MOVEID_END
#define DBG_CONVERT_PGM_MOVE_CALL
#define DBG_GENERATE_CALL
#define DBG_GENERATE_START
#define DBG_GENERATE_END
#define DBG_IS_ATTACKED_CALL
#define DBG_IS_ATTACKED_START
#define DBG_IS_ATTACKED_END(p1)
#define DBG_IS_LEGAL_CALL
#define DBG_IS_LEGAL_START
#define DBG_IS_LEGAL_END
#define DBG_MAKE_CALL
#define DBG_MAKE_START
#define DBG_MAKE_END
#define DBG_UNMAKE_CALL
#define DBG_UNMAKE_START
#define DBG_VERIFY_BOARD_PIECES(p1)
#define DBG_VERIFY_MOVEID_CALL
#define DBG_VERIFY_MOVEID_START

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : pgn
**************************************************************************************************/

#ifdef DEBUG

#define DBG_ASSOCIATE_MOVE_CALL { \
  debug.trace ("associate_move", true, &associate_move_calls); \
}
#define DBG_ASSOCIATE_MOVE_START { \
  debug.print (" : move_code %x - mask %x\n", \
    move_code, mask); \
}
#define DBG_ASSOCIATE_MOVE_END_1 { \
  debug.print ("associate_move -> true - moveid %x\n", \
    move->moveid); \
}
#define DBG_ASSOCIATE_MOVE_END_2 { \
  debug.print ("associate_move -> false\n"); \
}
#define DBG_CONVERT_FILE_CALL { \
  debug.trace ("convert_file\n", true, &convert_file_calls); \
}
#define DBG_CONVERT_FILE_1 { \
  debug.print ("convert_file -> n� %6d game %s\n", \
    count_games, pgn_game); \
}

#else

#define DBG_ASSOCIATE_MOVE_CALL
#define DBG_ASSOCIATE_MOVE_START
#define DBG_ASSOCIATE_MOVE_END_1
#define DBG_ASSOCIATE_MOVE_END_2
#define DBG_CONVERT_FILE_CALL
#define DBG_CONVERT_FILE_1

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : search
**************************************************************************************************/

#ifdef DEBUG

#define DBG_APPLY_HEURISTICS_CALL { \
  debug.trace ("apply_heuristics", false, &apply_heuristics_calls); \
}
#define DBG_FIRST_SEARCH_CALL { \
  debug.trace ("first_search", true, &first_search_calls); \
}
#define DBG_FIRST_SEARCH_START { \
  debug.print (" : depth %d alpha %d beta %d game_ply %d\n", \
    depth, alpha, beta, game_ply); \
}
#define DBG_HEURISTIC_0   { debug.print (" (0 %d)", moves_list[i].note); }
#define DBG_HEURISTIC_1   { debug.print (" (1 %d)", move->note); }
#define DBG_HEURISTIC_2   { debug.print (" (2 %d)", move->note); }
#define DBG_HEURISTIC_3   { debug.print (" (3 %d)", move->note); }
#define DBG_HEURISTIC_4   { debug.print (" (4 %d)", move->note); }
#define DBG_HEURISTIC_5   { debug.print (" (5 %d)", move->note); }
#define DBG_HEURISTIC_6   { debug.print (" (6 %d)", move->note); }
#define DBG_HISTORY_HEURISTIC(p1) { \
  debug.print ("%s : history_heuristic[%c%d][%c%d] %d (+ %d)\n", p1, \
    file[moves_list[i].from] + 'a' - 1, rank[moves_list[i].from], \
    file[moves_list[i].to] + 'a' - 1, rank[moves_list[i].to], \
    history_heuristic[moves_list[i].from][moves_list[i].to], depth); }
#define DBG_IS_REPEATED_CALL { \
  debug.trace ("is_repeated", true, &is_repeated_calls); \
}
#define DBG_IS_REPEATED_END_1  { \
  debug.print (" : true\n"); \
}
#define DBG_IS_REPEATED_END_2  { \
  debug.print (" : false (repeats %d)\n", repeats); \
}
#define DBG_PICK_MOVE_CALL { \
  debug.trace ("pick_move", true, &pick_move_calls); \
}
#define DBG_PICK_MOVE_END { \
  debug.print (" : move %d\n", move); \
}
#define DBG_QUIESCENCE_SEARCH_CALL { \
  debug.trace ("quiescence_search", true, &quiescence_search_calls); \
}
#define DBG_QUIESCENCE_SEARCH_START { \
  debug.print (" : alpha %d beta %d\n", alpha, beta); \
}
#define DBG_SEARCH_CALL { \
  debug.trace ("search", true, &search_calls); \
}
#define DBG_SEARCH_START { \
  debug.print (" : depth %d alpha %d beta %d do_null_move %d - game_ply %d\n", \
    depth, alpha, beta, do_null_move, game_ply); \
}
#define DBG_SEARCH_TREE_0 int last_tree_nodes = 0;
#define DBG_SEARCH_TREE_1 { \
  if (debug_tree) { \
    for (int node = last_tree_nodes + 1; node <= nodes && node <= DEBUG_TREE_LIMIT; node++) { \
      fprintf (debug_tree_file, "%6d %c%d ", \
        node, tree_nodes[node].type, tree_nodes[node].depth); \
      for (int i = 0; i < tree_nodes[node].depth; i++) { \
        fprintf (debug_tree_file, "   "); \
      } \
      fprintf (debug_tree_file, "%2d/%2d - %s (alpha %6d beta %6d) = %4d\n", \
        tree_nodes[node].i, tree_nodes[node].moves_number, tree_nodes[node].lan_move, \
        tree_nodes[node].alpha, tree_nodes[node].beta, tree_nodes[node].score); \
    } \
    fprintf (debug_tree_file, "----------------------------------------------------------------" \
      "--------------\n"); \
    fprintf (debug_tree_file, "- End of iterative deepening level %d\n", iterative_depth); \
    fprintf (debug_tree_file, "- PV : "); \
    char lan_move[6]; \
    for (int i = 1; i < pv_length[1]; i++) { \
      moves.convert_pgm_move (&pv[1][i], lan_move); \
      fprintf (debug_tree_file, "%s ", lan_move); \
    } \
    fprintf (debug_tree_file, "\n--------------------------------------------------------------" \
      "----------------\n"); \
    last_tree_nodes = nodes; \
  } \
}
#define DBG_SEARCH_TREE_2(p1) { \
  if (debug_tree) { \
    if (nodes <= DEBUG_TREE_LIMIT) { \
      moves.convert_pgm_move (&moves_list[i], tree_nodes[nodes].lan_move); \
      tree_nodes[nodes].type         = p1; \
      tree_nodes[nodes].idepth       = iterative_depth; \
      tree_nodes[nodes].depth        = search_ply - 1; \
      tree_nodes[nodes].i            = i; \
      tree_nodes[nodes].moves_number = moves_number; \
      tree_nodes[nodes].alpha        = alpha; \
      tree_nodes[nodes].beta         = beta; \
      debug_node = nodes; \
    } \
  } \
}
#define DBG_SEARCH_TREE_3 { \
  if (debug_tree && nodes < DEBUG_TREE_LIMIT) { \
    tree_nodes[debug_node].score = score; \
  } \
}
#define DBG_SORT_MOVES_CALL { \
  debug.trace ("sort_moves", true, &sort_moves_calls); \
}
#define DBG_SORT_MOVES_START { \
  debug.print (" : moves_number %d - ", \
    moves_number); \
}
#define DBG_SORT_MOVES_1(p1) { debug.print (" (%s i %d)", p1, i); }
#define DBG_SORT_MOVES_END { \
  debug.print (" : "); \
  for (int i = 1; i <= moves_number; i++) { \
    debug.print ("%c%d%c%d%c %d - ", \
      file[moves_list[i].from] + 'a' -1, rank[moves_list[i].from], \
      file[moves_list[i].to] + 'a' -1, rank[moves_list[i].to], \
      moves_list[i].promoted ? PIECE(moves_list[i].promoted) : ' ', \
      moves_list[i].note); \
  } \
  debug.print ("\n"); \
}
#define DBG_SPLIT_DEBUG_FILES { \
  debug.split_debug_file (); \
}
#define DBG_START_CALL { \
  debug.trace ("start\n", true, &start_calls); \
}
#define DBG_UPDATE_KILLERS_CALL { \
  debug.trace ("update_killers\n", true, &update_killers_calls); \
}
#define DBG_UPDATE_KILLERS(p1) { \
  debug.print (" : killer %d - search_ply %d : score1 %d move1 %c%d%c%d%c", \
    p1, search_ply, killers[search_ply].score1, \
    file[killers[search_ply].moveid1 & 0x7f] + 'a' - 1, \
    rank[killers[search_ply].moveid1 & 0x7f], \
    file[(killers[search_ply].moveid1>>8) & 0x7f]+ 'a' - 1, \
    rank[(killers[search_ply].moveid1>>8) & 0x7f], \
    (killers[search_ply].moveid1>>16) ? \
      PIECE((killers[search_ply].moveid1>>16)) : ' '); \
  debug.print (" - score2 %d move2 %c%d%c%d%c", \
    killers[search_ply].score2, \
    file[killers[search_ply].moveid2 & 0x7f] + 'a' - 1, \
    rank[killers[search_ply].moveid2 & 0x7f], \
    file[(killers[search_ply].moveid2>>8) & 0x7f] + 'a' - 1, \
    rank[(killers[search_ply].moveid2>>8) & 0x7f], \
    (killers[search_ply].moveid2>>16) ? \
      PIECE((killers[search_ply].moveid2>>16)) : ' '); \
  debug.print (" - move3 %c%d%c%d%c\n", \
    file[killers[search_ply].moveid3 & 0x7f] + 'a' - 1, \
    rank[killers[search_ply].moveid3 & 0x7f], \
    file[(killers[search_ply].moveid3>>8) & 0x7f] + 'a' - 1, \
    rank[(killers[search_ply].moveid3>>8) & 0x7f], \
    (killers[search_ply].moveid3>>16) ? \
      PIECE((killers[search_ply].moveid3>>16)) : ' '); \
}

#else

#define DBG_APPLY_HEURISTICS_CALL
#define DBG_FIRST_SEARCH_CALL
#define DBG_FIRST_SEARCH_START
#define DBG_HEURISTIC_0
#define DBG_HEURISTIC_1
#define DBG_HEURISTIC_2
#define DBG_HEURISTIC_3
#define DBG_HEURISTIC_4
#define DBG_HEURISTIC_5
#define DBG_HEURISTIC_6
#define DBG_HISTORY_HEURISTIC(p1)
#define DBG_IS_REPEATED_CALL
#define DBG_IS_REPEATED_END_1
#define DBG_IS_REPEATED_END_2
#define DBG_PICK_MOVE_CALL
#define DBG_PICK_MOVE_END
#define DBG_QUIESCENCE_SEARCH_CALL
#define DBG_QUIESCENCE_SEARCH_START
#define DBG_SEARCH_CALL
#define DBG_SEARCH_START
#define DBG_SEARCH_TREE_0
#define DBG_SEARCH_TREE_1
#define DBG_SEARCH_TREE_2(p1)
#define DBG_SEARCH_TREE_3
#define DBG_SORT_MOVES_CALL
#define DBG_SORT_MOVES_START
#define DBG_SORT_MOVES_1(p1)
#define DBG_SORT_MOVES_END
#define DBG_SPLIT_DEBUG_FILES
#define DBG_START_CALL
#define DBG_UPDATE_KILLERS(p1)
#define DBG_UPDATE_KILLERS_CALL

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : tools
**************************************************************************************************/

#ifdef DEBUG

#define DBG_COMPUTE_TIME_CALL { \
  debug.trace ("compute_time", true, &compute_time_calls); \
}
#define DBG_COMPUTE_TIME_END { \
  debug.print (" : time_for_move %d\n", time_for_move); \
}
#define DBG_DISPLAY_BOARD_INFORMATIONS { \
    if (y == 6) { \
 \
     if (EP_SQUARE) \
        fprintf (output_file, " ep_square %c%d", file[EP_SQUARE] + 'a' - 1, rank[EP_SQUARE]); \
      else \
        fprintf (output_file, " ep_square none"); \
    } \
    if (y == 5) fprintf (output_file, " castle_status %x", CASTLE_STATUS); \
    if (y == 4) fprintf (output_file, " hash value %llx", h_position); \
}
#define DBG_PRINT_BOARD_CALL { \
  debug.trace ("print_board\n", false, &print_board_calls); \
}
#define DBG_READ_CONFIG_FILE_CALL { \
  debug.trace ("read_config_file\n", true, &read_config_file_calls); \
}
#define DBG_READ_CONFIG_FILE_DBG_LIMITS \
       READ_INTEGER_PARAMETER("debug_calls_limit", debug_calls_limit) \
  else READ_INTEGER_PARAMETER("debug_calls_max", debug_calls_max) \
  else READ_INTEGER_PARAMETER("debug_calls_min", debug_calls_min) \
  else
#define DBG_READ_INPUT_CALL { \
  debug.trace ("read_input", true, &read_input_calls); \
}
#define DBG_READ_INPUT_END { \
  debug.print (" : %s\n", string); \
}
#define DBG_SEND_OUTPUT_CALL { \
  debug.trace ("send_output", false, &send_output_calls); \
}
#define DBG_UPDATE_PIECES_CALL { \
  debug.trace ("update_pieces", true, &update_pieces_calls); \
}
#define DBG_UPDATE_PIECES_END { \
  debug.print (" : "); \
  for (color = WHITE; color >= BLACK; color--) { \
    for (int i = 1; i <= pieces_number[color]; i++) { \
      if (pieces[color][i]) { \
        debug.print ("%c%c%d - ", \
          PIECE(board[pieces[color][i]]), \
          file[pieces[color][i]] + 'a' -1, \
          rank[pieces[color][i]]); \
      } \
    } \
  } \
  debug.print ("\n"); \
}

#else

#define DBG_COMPUTE_TIME_CALL
#define DBG_COMPUTE_TIME_END
#define DBG_DISPLAY_BOARD_INFORMATIONS
#define DBG_PRINT_BOARD_CALL
#define DBG_READ_CONFIG_FILE_CALL
#define DBG_READ_CONFIG_FILE_DBG_LIMITS
#define DBG_READ_INPUT_CALL
#define DBG_READ_INPUT_END
#define DBG_SEND_OUTPUT_CALL
#define DBG_UPDATE_PIECES_CALL
#define DBG_UPDATE_PIECES_END

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : ttable
**************************************************************************************************/

#ifdef DEBUG

#define DBG_FREE_TTABLE_CALL { \
  debug.trace ("free_ttable\n", true, &free_ttable_calls); \
}
#define DBG_FREE_TTABLE_1 { \
  free (tt_repartition); \
}
#define DBG_INITIALIZE_TTABLE_CALL { \
  debug.trace ("initialize_ttable\n", true, &init_ttable_calls); \
}
#define DBG_INITIALIZE_TTABLE_1 { \
  tt_repartition = malloc (tt_entries * sizeof (unsigned long int)); \
  if (tt_repartition == NULL) { \
    tools.send_output (true, "   ERROR : %s can't allocate memory to study " \
      "the repartition in the transposition table.\n", PRODUCT_NAME); \
    uci.quit (EXIT_FAILURE); \
  } \
  else { \
    memset (tt_repartition, 0, sizeof (tt_repartition)); \
  } \
}
#define DBG_READ_TTABLE_START { \
  debug.print (" : alpha %d beta %d depth %d\n", \
    alpha, beta, depth); \
}
#define DBG_READ_TTABLE_CALL { \
  debug.trace ("read_ttable", true, &read_ttable_calls); \
}
#define DBG_READ_TTABLE_1 { \
  if (*moveid) { \
    debug.print ("read_ttable : t_depth %d tt_node_type %d tt_value %d tt_moveid " \
      "%c%d%c%d%c\n", tt_pointer->depth, tt_pointer->node_type, tt_pointer->value, \
      file[tt_pointer->moveid & 0x7F] + 'a' - 1, \
      rank[tt_pointer->moveid & 0x7F], \
      file[(tt_pointer->moveid >> 8) & 0x7F] + 'a' - 1, \
      rank[(tt_pointer->moveid >> 8) & 0x7F], \
      (tt_pointer->moveid >> 16) ? PIECE(tt_pointer->moveid >> 16) : ' '); \
  } \
  else { \
    debug.print ("read_ttable : t_depth %d tt_node_type %d tt_value %d t_move " \
      "none\n", tt_pointer->depth, tt_pointer->node_type, tt_pointer->value); \
  } \
}
#define DBG_RESET_TTABLE_CALL { \
  debug.trace ("reset_ttable\n", true, &reset_ttable_calls); \
}
#define DBG_RESET_TTABLE_1 { \
  tt_collisions = 0; \
}
#define DBG_SEARCH_TT_PV_CALL { \
  debug.trace ("search_tt_pv", true, &search_tt_pv_calls); \
}
#define DBG_SEARCH_TT_PV_START { \
  debug.print (" : depth %d (iterative_depth %d)\n", depth, iterative_depth); \
}
#define DBG_WRITE_TTABLE_CALL { \
  debug.trace ("write_ttable", true, &write_ttable_calls); \
}
#define DBG_WRITE_TTABLE_START { \
  if (moveid) { \
  debug.print (" : depth %d node_type %d value %d move %c%d%c%d%c\n", \
    depth, node_type, value, \
    file[moveid & 0x7F] + 'a' - 1, rank[moveid & 0x7F], \
    file[(moveid >> 8) & 0x7F] + 'a' - 1, rank[(moveid >> 8) & 0x7F], \
    (moveid >> 16) ? PIECE(moveid >> 16) : ' '); \
  } \
  else { \
  debug.print (" : depth %d node_type %d value %d move none\n", \
    depth, node_type, value); \
  } \
}
#define DBG_WRITE_TTABLE_1 \
    else { \
      if (tt_pointer->h_position != h_position) \
        tt_collisions++; \
        tt_repartition[h_position & tt_mask]++; \
    }

#else

#define DBG_FREE_TTABLE_CALL
#define DBG_FREE_TTABLE_1
#define DBG_INITIALIZE_TTABLE_CALL
#define DBG_INITIALIZE_TTABLE_1
#define DBG_READ_TTABLE_CALL
#define DBG_READ_TTABLE_START
#define DBG_READ_TTABLE_1
#define DBG_RESET_TTABLE_CALL
#define DBG_RESET_TTABLE_1
#define DBG_SEARCH_TT_PV_CALL
#define DBG_SEARCH_TT_PV_START
#define DBG_WRITE_TTABLE_CALL
#define DBG_WRITE_TTABLE_START
#define DBG_WRITE_TTABLE_1

#endif /* DEBUG */

/* ************************************************************************************************
 Du module : uci
**************************************************************************************************/

#ifdef DEBUG

#define DBG_GO_CALL { \
  debug.trace ("go", true, &go_calls); \
}
#define DBG_GO_START { \
  debug.print (" : %s\n", string); \
}
#define DBG_GO_END { \
  debug.print (" : infinite %d - binc %d - btime %d - movestogo %d - winc %d - wtime %d\n", \
    uci_infinite, uci_binc, uci_btime, uci_movestogo, uci_winc, uci_wtime); \
}
#define DBG_INFO_CALL { \
  debug.trace ("info", true, &info_calls); \
}
#define DBG_INFO_START { \
  debug.print (" : %d\n", score); \
}
#define DBG_ISREADY_CALL { \
  debug.trace ("isready\n", true, &isready_calls); \
}
#define DBG_POSITION_CALL { \
  debug.trace ("position", true, &position_calls); \
}
#define DBG_POSITION_START { \
  debug.print (" : %s\n", string); \
}
#define DBG_QUIT_CALL { \
  debug.trace ("quit", true, &quit_calls); \
}
#define DBG_QUIT_END_OF_DEBUG { \
  debug.close_debug_file (); \
  debug.print_statistics (); \
}
#define DBG_QUIT_START { \
  debug.print (" : %s\n", return_code); \
}
#define DBG_SETOPTION_CALL { \
  debug.trace ("setoption", true, &setoption_calls); \
}
#define DBG_SETOPTION_START { \
  debug.print (" : %s\n", string); \
}
#define DBG_UCI_COMMAND_CALL { \
  debug.trace ("uci_command\n", true, &uci_cmd_calls); \
}
#define DBG_UCINEWGAME_CALL { \
  debug.trace ("ucinewgame\n", true, &ucinewgame_calls); \
}

#else

#define DBG_GO_CALL
#define DBG_GO_START
#define DBG_GO_END
#define DBG_INFO_CALL
#define DBG_INFO_START
#define DBG_ISREADY_CALL
#define DBG_POSITION_CALL
#define DBG_POSITION_START
#define DBG_QUIT_CALL
#define DBG_QUIT_END_OF_DEBUG
#define DBG_QUIT_START
#define DBG_SETOPTION_CALL
#define DBG_SETOPTION_START
#define DBG_UCI_COMMAND_CALL
#define DBG_UCINEWGAME_CALL

#endif /* DEBUG */

/**************************************************************************************************
  Types :
**************************************************************************************************/

#ifdef DEBUG

/* Informations n�cessaires au d�bogage de l'arbre de recherche. */
struct {
  char type;        /* Type : 'f' - first search; 's' - normal search; 'q' - quiescence search */
  int idepth;       /* Iterative depth level. */
  int depth;        /* Current depth. */
  int i;            /* Rank of move in the list of generated moves. */
  int moves_number; /* Number of generated moves. */
  char lan_move[6];
  int alpha;
  int beta;
  int score;

} tree_nodes [DEBUG_TREE_LIMIT];

#endif /* DEBUG */

/* Fonctions externes du module : */
typedef struct {

  void (*close_debug_file) (void);
  void (*dump) (char comment[]);
  void (*open_debug_file) (void);
  int (*print) (const char *format, ...);
  void (*print_statistics) (void);
  void (*split_debug_file) (void);
  void (*test_hash) (void);
  void (*trace) (char function[], bool is_printed, int *number_of_calls);
  void (*verify_board_pieces) (char comment[]);

} debug_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern debug_module_s debug;

#ifdef DEBUG

/* ------------------------------------------------------------------------------------------------
   Variables de comptage des appels aux diff�rentes fonctions du programme :
------------------------------------------------------------------------------------------------ */

/* Du module : book */
extern int select_move_calls;

/* Du module : evaluate */
extern int evaluate_pieces_calls;
extern int evaluate_position_calls;

/* Du module : game */
extern int game_check_phase_calls;
extern int game_go_on_calls;
extern int game_init_calls;

/* Du module : hash */
extern int compute_h_position_calls;
extern int generate_random_calls;
extern int init_h_values_calls;

/* Du module : main */
extern int call_uci_function_calls;
extern int exec_cmd_calls;
extern int exec_dbg_cmd_calls;
extern int init_program_calls;
extern int main_calls;

/* Du module : moves */
extern int compute_moveid_calls;
extern int convert_pgm_move_calls;
extern int generate_calls;
extern int is_attacked_calls;
extern int is_legal_calls;
extern int make_calls;
extern int unmake_calls;
extern int verify_moveid_calls;

/* Du module : pgn */
extern int associate_move_calls;
extern int convert_file_calls;

/* Du module : search */
extern int apply_heuristics_calls;
extern int first_search_calls;
extern int is_repeated_calls;
extern int pick_move_calls;
extern int quiescence_search_calls;
extern int search_calls;
extern int sort_moves_calls;
extern int start_calls;
extern int update_killers_calls;

/* Du module : tools */
extern int compute_time_calls;
extern int print_board_calls;
extern int read_config_file_calls;
extern int read_input_calls;
extern int send_output_calls;
extern int update_pieces_calls;

/* Du module : ttable */
extern int free_ttable_calls;
extern int init_ttable_calls;
extern int read_ttable_calls;
extern int reset_ttable_calls;
extern int search_tt_pv_calls;
extern int write_ttable_calls;

extern unsigned long int tt_collisions;
extern unsigned long int *tt_repartition;

/* Du module : uci */
extern int go_calls;
extern int info_calls;
extern int isready_calls;
extern int position_calls;
extern int quit_calls;
extern int setoption_calls;
extern int uci_cmd_calls;
extern int ucinewgame_calls;

/* ------------------------------------------------------------------------------------------------
   Autres variables de d�bogage :
------------------------------------------------------------------------------------------------ */

extern FILE *debug_eval_file;
extern FILE *debug_file;
extern FILE *debug_tree_file;

extern bool debug_evaluation;
extern bool debug_tree;

extern int debug_file_indice;
extern int debug_node;

/* Valeurs limites pour le d�bogage : */
extern unsigned long int debug_calls_limit;
extern unsigned long int debug_calls_max;
extern unsigned long int debug_calls_min;

extern unsigned long int total_calls;

#endif /* DEBUG */

#endif /* DEBUG_H */
