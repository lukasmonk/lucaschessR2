/**************************************************************************************************
  File : book.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "book".
**************************************************************************************************/

#ifndef BOOK_H
#define BOOK_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "moves.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Fonctions externes du module : */
typedef struct {

  bool (*select_move) (move_s *move);

} book_module;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern book_module book;

#endif /* BOOK_H */
