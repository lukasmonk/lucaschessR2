/**************************************************************************************************
  File : moves.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "moves".
**************************************************************************************************/

#ifndef MOVES_H
#define MOVES_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Informations qui d�crivent un coup : */
typedef struct {

  unsigned char from;       /* Case de d�part de la pi�ce. */
  unsigned char to;         /* Case d'arriv�e de la pi�ce. */
  unsigned char captured;   /* Nom de la pi�ce captur�e. */
  unsigned char promoted;   /* Nom de la pi�ce de promotion. */
  unsigned char status;     /* Nature du coup jou�. */
  int *captured_ptr;        /* Adresse de la fiche de la pi�ce captur�e. */
  int moveid;               /* Identification du coup sur 24 bits :
                               - bits  1 �  8 : case de d�part,
                               - bits  9 � 16 : case d'arriv�e,
                               - bits 17 � 24 : nom de la pi�ce de promotion. */
  int note;                 /* Note pour le tri des coups. */

} move_s;

/* Fonctions externes du module : */
typedef struct {

  bool (*compute_moveid) (const char *lan_move, int *moveid);
  void (*convert_pgm_move) (move_s *pgm_move, char lan_move[]);
  int (*generate) (move_s *moves, bool captures_only);
  bool (*is_attacked) (int square0, int color);
  bool (*is_legal) (move_s *move);
  void (*make) (move_s *move);
  void (*tree) (FILE *tree_file, int depth, u64 *total_legal_moves, int games_by_point);
  void (*unmake) (move_s *move);
  bool (*verify_moveid) (int moveid, move_s *move);

} moves_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern moves_module_s moves;

#endif /* MOVES_H */
