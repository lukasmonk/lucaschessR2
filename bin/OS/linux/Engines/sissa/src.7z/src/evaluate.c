/**************************************************************************************************
  File : evaluate.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Module d'�valuation statique d'une position.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "debug.h"
#include "evaluate.h"
#include "game.h"
#include "tools.h"
#include "uci.h"

/**************************************************************************************************
  Constants :
**************************************************************************************************/

/* Bonus et malus pour les pions : */
const int bonus_connected_pawn[3] = { 4, 8, 12};
const int bonus_passed_pawn[3] = { 2, 4, 6 };
const int malus_backward_pawn[3] = { -2, -4, -6 };
const int malus_isolated_pawn[3] = { -2, -4, -6 };
const int malus_weak_backward_pawn = -4;
const int malus_weak_isolated_pawn = -8;
const int malus_doubled_pawn[3] = { -1, -2, -4 };
const int malus_blocked_pawns = -16;

/* Malus pour la dame : */
const int malus_queen_opening = -8;

/* Bonus pour les tours : */
const int bonus_rook_half_open_file = 4;
const int bonus_rook_open_file = 4;
const int bonus_rook_seventh_rank[3] = { 4, 8, 12};

/* Bonus et malus pour le roi : */
const int bonus_castling[2] = { 16, 24 };
const int malus_king_cover[2] = { -4, -8 };
const int malus_king_no_cover[2] = { -8, -16 };
const int malus_no_castling[2] = { -4, -8 };

/* Bonus et malus pour encourager, ou pas, les �changes en finale : */
const int bonus_exchange = 16;
const int malus_exchange = -8;

/* Malus pour �viter les r�p�titions lorsque le programme a l'avantage : */
const int malus_repetition = -16;

/* Bonus pour la position du pion (favorise l'avancement du pion) : */
const int bonus_pawn[9][9] = {
  { 0, 0, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 1, 2, 3, 4, 5, 0 },
  { 0, 0, 0, 2, 4, 6, 8,10, 0 },
  { 0, 0, 0, 3, 6, 9,12,15, 0 },
  { 0, 0,-4, 4, 8,12,16,20, 0 },
  { 0, 0,-4, 4, 8,12,16,20, 0 },
  { 0, 0, 0, 3, 6, 9,12,15, 0 },
  { 0, 0, 0, 2, 4, 6, 8,10, 0 },
  { 0, 0, 0, 1, 2, 3, 4, 5, 0 }
};

/* Bonus pour la position du cavalier : */
const int bonus_knight[9][9] = {
  { 0, 0, 0, 0, 0, 0, 0, 0, 0 },
  { 0,-8,-4,-4,-4,-4,-4,-4,-8 },
  { 0,-4, 0, 0, 0, 0, 0, 0,-4 },
  { 0,-4, 0, 4, 4, 4, 4, 0,-4 },
  { 0,-4, 2, 4, 8, 8, 4, 2,-4 },
  { 0,-4, 2, 4, 8, 8, 4, 2,-4 },
  { 0,-4, 0, 4, 4, 4, 4, 0,-4 },
  { 0,-4, 0, 0, 0, 0, 0, 0,-4 },
  { 0,-8,-4,-4,-4,-4,-4,-4,-8 }
};

/* Bonus pour la position du fou : */
const int bonus_bishop[9][9] = {
  { 0, 0, 0, 0, 0, 0, 0, 0, 0 },
  { 0,-8,-4,-4,-4,-4,-4,-4,-8 },
  { 0,-4, 8, 4, 4, 4, 4, 8,-4 },
  { 0,-4, 4, 4, 8, 8, 4, 4,-4 },
  { 0,-4, 6, 8, 2, 2, 8, 6,-4 },
  { 0,-4, 6, 8, 2, 2, 8, 6,-4 },
  { 0,-4, 4, 4, 8, 8, 4, 4,-4 },
  { 0,-4, 8, 4, 2, 2, 4, 8,-4 },
  { 0,-8,-4,-4,-4,-4,-4,-4,-8 }
};

/* Bonus pour la position du roi (d�but et milieu de partie) : */
const int bonus_king[9][9] = {
  { 0,  0,  0,  0,  0,  0,  0,  0,  0 },
  { 0,  4, -2, -4, -8,-12,-16,-20,-24 },
  { 0, 12, -2, -4, -8,-12,-16,-20,-24 },
  { 0,  6, -4, -8,-12,-16,-20,-24,-28 },
  { 0,  0, -4, -8,-12,-16,-20,-24,-28 },
  { 0,  0, -4, -8,-12,-16,-20,-24,-28 },
  { 0,  8, -4, -8,-12,-16,-20,-24,-28 },
  { 0, 12, -2, -4, -8,-12,-16,-20,-24 },
  { 0,  4, -2, -4, -8,-12,-16,-20,-24 }
};

/* Bonus pour la centralisation du roi en finale : */
const int bonus_king_endgame[9][9] = {
  { 0, 0, 0, 0, 0, 0, 0, 0, 0 },
  { 0,-8,-4,-2, 0, 0,-2,-4,-8 },
  { 0,-4, 0, 2, 2, 2, 2, 0,-4 },
  { 0,-2, 2, 8, 8, 8, 8, 2,-2 },
  { 0, 0, 2, 8,12,12, 8, 2, 0 },
  { 0, 0, 2, 8,12,12, 8, 2, 0 },
  { 0,-2, 2, 8, 8, 8, 8, 2,-2 },
  { 0,-4, 0, 2, 2, 2, 2, 0,-4 },
  { 0,-8,-4,-2, 0, 0,-2,-4,-8 }
};

/**************************************************************************************************
  Data :
**************************************************************************************************/

int gp;                 /* game_phase : phase de jeu (ouverture, milieu de partie ou finale) */
int pawn_rank[2][10];   /* Pour m�moriser la rang�e des pions arri�r�s. */
int pawns[2][10];       /* Pour le comptage des pions par colonne et couleur. */

/**************************************************************************************************
  Internal functions prototypes :
**************************************************************************************************/

int evaluate_pieces (int color);

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : evaluate_position
  Description  : Evaluation statique d'une position.
  Parameters   : aucun
  Return value : �valuation de la position
  Validation   : 1
**************************************************************************************************/
int evaluate_position (void) {                                                                     DBG_EVALUATE_POSITION_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int color;         /* Couleur du camp. */
int score = 0;     /* Evaluation de la position. */
int x, y;          /* Colonne et rang�e de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */DBG_EVALUATE_POSITION_START

  /* Initialisation des tables d'�valuation : */
  memset (pawns, 0, sizeof (pawns));

  /* Initialisation des tables de m�morisation de la rang�e des pions. */
  for (int i = 0; i < 10; i++) {

    pawn_rank[WHITE][i] = 7;
    pawn_rank[BLACK][i] = 2;
  }

  /* Pour les pi�ces noires puis blanches, une premi�re passe est faite, */
  for (color = BLACK; color <= WHITE; color++) {

    /* � partir de la table des pi�ces, */
    for (int j = 1; j <= pieces_number[color]; j++) {

      /* si un pion est trouv�, */
      if (pieces[color][j] && (board[pieces[color][j]] & 0x7) == PAWN) {

        x = file[pieces[color][j]];
        y = rank[pieces[color][j]];

        /* alors le programme m�morise sa pr�sence sur la colonne, */
        pawns[color][x]++;

        /* ainsi que la rang�e du pion le moins avanc�. */
        if (RR(y) < RR(pawn_rank[color][x])) {

          pawn_rank[color][x] = y;
        }
      }
    }
  }                                                                                                DBG_EVALUATE_POSITION_1

  /* Identifie la phase de la partie (ouverture, milieu ou finale). */
  gp = game.check_game_phase (active_color);

  /* Le score r�sulte de la diff�rence entre la valeur des pi�ces blanches et  noires; l'avantage
     est d�termin� par la couleur au trait. */
  if (active_color) {

    score = evaluate_pieces (WHITE) - evaluate_pieces (BLACK);
  }
  else {

    score = evaluate_pieces (BLACK) - evaluate_pieces (WHITE);
  }

  /* En finale, */
  if (gp == ENDGAME) {

    /* le programme favorise l'�change de mat�riel s'il poss�de un bon avantage mat�riel, */
    if (score > 200 && piece_count < start_piece_count) {

      score += bonus_exchange;                                                                     DBG_EVALUATE_POSITION_2("endgame", "bonus for exchange")
    }
    /* dans le cas contraire les �changes sont �vit�s. */
    else if (score < 150 && piece_count < start_piece_count) {

      score += malus_exchange;                                                                     DBG_EVALUATE_POSITION_2("endgame", "malus for exchange")
    }
  }

  /* Si le programme poss�de un net avantage et qu'il n'est pas en manque de temps, */
  if (   score > 150
      && (   ((computer_color ? uci_btime + 6*uci_binc : uci_wtime + 6*uci_winc) > (base_time * 6))
          || (uci_movestogo > 4))) {

    /* alors un malus est appliqu� pour �viter la r�p�tition de la position. */
    score += repeats * malus_repetition;                                                           DBG_EVALUATE_POSITION_2("endgame", "malus for repetition")
  }                                                                                                DBG_EVALUATE_POSITION_END

  return score;
}
/* End of function : evaluate_position */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/
evaluate_module_s evaluate = {

  evaluate_position
};

/**************************************************************************************************
  Internal functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : evaluate_pieces
  Description  : Evaluation statique d'une position.
  Parameters   : in  - Couleur du camp � analyser
  Return value : �valuation de la position
  Validation   : 1
**************************************************************************************************/
int evaluate_pieces (int color) {                                                                  DBG_EVALUATE_PIECES_CALL

/* --- Local data ------------------------------------------------------------------------------ */

bool backward;     /* Indique si un pion est arri�r�. */
bool isolated;     /* Indique si un pion est isol�. */

int score = 0;     /* Evaluation de la position. */
int x, y;          /* Colonne et rang�e de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Pour toutes les pi�ces connues dans la table des pi�ces, */
  for (int i = 1; i <= pieces_number[color]; i++) {

    /* si elle est encore pr�sente sur l'�chiquier, */
    if (pieces[color][i]) {

      x = file[pieces[color][i]];
      y = rank[pieces[color][i]];

      /* alors le programme calcule son influence sur la position. */
      switch (board[pieces[color][i]]) {

        case (BPAWN) :
        case (WPAWN) :

          /* Par d�faut un pion n'est ni arri�r�, ni isol�. */
          backward = false;
          isolated = false;

          /* Bonus pour la valeur du pion. */
          score += pieces_value[PAWN];

          /* Bonus pour favoriser l'avance vers la case de promotion. */
          score += bonus_pawn[x][RR(y)];                                                           DBG_EVALUATE_PIECES_1("pawn", "value + position")

          /* Si les pions adjacents sont plus avanc�s, */
          if (   RR(pawn_rank[color][x + 1]) > RR(y)
              && RR(pawn_rank[color][x - 1]) > RR(y)) {

            /* alors le pion est arri�r�. */
            backward = true;

            /* Si l'ouverture est termin�e ou si le pion n'est plus sur sa rang�e initiale, */
            if (gp != OPENING || RR(y) != 2) {

              /* alors un malus est ajout� � la position. */
              score += malus_backward_pawn[gp];                                                    DBG_EVALUATE_PIECES_1("pawn", "backward")
            }

            /* Si les pions adjacents ont disparu, */
            if (   !pawns[color][x + 1]
                && !pawns[color][x - 1]) {

              /* alors le pion est isol�, */
              isolated = true;

              /* et un malus suppl�mentaire est appliqu�. */
              score += malus_isolated_pawn[gp];                                                    DBG_EVALUATE_PIECES_1("pawn", "isolated")
            }
          }

          /* Si le pion est sur une colonne semi-ouverte, */
          if (!pawns[color^1][x]) {

            /* s'il est arri�r� : */
            if (backward) {

              /* alors un malus est appliqu�. */
              score += malus_weak_backward_pawn;                                                   DBG_EVALUATE_PIECES_1("pawn", "weak backward")
            }

            /* S'il est isol�, */
            if (isolated) {

              /* alors un malus plus important est appliqu�. */
              score += malus_weak_isolated_pawn;                                                   DBG_EVALUATE_PIECES_1("pawn", "weak isolated")
            }
          }

          /* Les pions doubl�s, voire tripl�s, */
          if (pawns[color][x] > 1) {

            /* sont lourdement p�nalis�s. */
            score += malus_doubled_pawn[gp] * (pawns[color][x] - 1);                               DBG_EVALUATE_PIECES_1("pawn", "doubled")
          }

          /* Un pion pass� (aucun pion adverse en face et sur les colonnes adjacentes), */
          if (   !pawns[color^1][x]
              && RR(y) >= RR(pawn_rank[color^1][x - 1])
              && RR(y) >= RR(pawn_rank[color^1][x + 1])) {

            /* est favoris�, et ce d'autant plus qu'il est avanc�. */
            score += bonus_passed_pawn[gp] * bonus_pawn[x][RR(y)];                                 DBG_EVALUATE_PIECES_1("pawn", "passed")

            /* S'il est soutenu par un pion adjacent, */
            if (   !isolated
                && (   (RR(pawn_rank[color][x]) - RR(pawn_rank [color][x + 1]) == 1)
                    || (RR(pawn_rank[color][x]) - RR(pawn_rank [color][x - 1]) == 1))) {

              /* il obtient un bonus suppl�mentaire. */
              score += bonus_connected_pawn[gp];                                                   DBG_EVALUATE_PIECES_1("pawn", "connected")
            }
          }
          break;

        case (BKNIGHT) :
        case (WKNIGHT) :

          /* Bonus pour la valeur du cavalier. */
          score += pieces_value[KNIGHT];

          /* Bonus pour la position du cavalier. */
          score += bonus_knight[x][y];                                                             DBG_EVALUATE_PIECES_1("knight", "value + position")
          break;

        case (BBISHOP) :
        case (WBISHOP) :

          /* Bonus pour la valeur du fou. */
          score += pieces_value[BISHOP];

          /* Bonus pour la position du fou. */
          score += bonus_bishop[x][y];                                                             DBG_EVALUATE_PIECES_1("bishop", "value + position")
          break;

        case (BROOK) :
        case (WROOK) :

          /* Bonus pour la valeur de la tour. */
          score += pieces_value[ROOK];                                                             DBG_EVALUATE_PIECES_1("rook", "value")

          /* La septi�me rang�e est int�ressante pour une tour. */
          if (RR(y) == 7) {

            score += bonus_rook_seventh_rank[gp];                                                  DBG_EVALUATE_PIECES_1("rook", "seventh rank")
          }

          /* Accorde un bonus pour une tour, */
          if (!pawns[color][x]) {

            /* sur une colonne semi-ouverte :  */
            score += bonus_rook_half_open_file;                                                    DBG_EVALUATE_PIECES_1("rook", "half open file")

            if (!pawns[color^1][x]) {

              /* et mieux sur une colonne ouverte :  */
              score += bonus_rook_open_file;                                                       DBG_EVALUATE_PIECES_1("rook", "open file")
            }
          }
          break;

        case (BQUEEN) :
        case (WQUEEN) :

          /* Bonus pour la valeur de la pi�ce. */
          score += pieces_value[QUEEN];                                                            DBG_EVALUATE_PIECES_1("queen", "value")

          /* Dans l'ouverture, */
          if (gp == OPENING) {

            /* le d�placement de la dame avant les pi�ces mineures, */
            if (   moved[94 - 70 * color]) {

              if (   !moved[92 - 70 * color]
                  || !moved[93 - 70 * color]
                  || !moved[96 - 70 * color]
                  || !moved[97 - 70 * color]) {

                /* est p�nalis�. */
                score += malus_queen_opening;                                                      DBG_EVALUATE_PIECES_1("queen", "move in opening")
              }
            }
          }
          break;

        case (BKING) :
        case (WKING) :

          /* En finale, */
          if (gp == ENDGAME) {

            /* le roi peut �tre jou� comme une autre pi�ce. */
            score += bonus_king_endgame[x][y];                                                     DBG_EVALUATE_PIECES_1("king", "endgame value")
          }
          else {

            /* sinon il doit �tre prot�g�. */
            score += bonus_king[x][RR(y)];                                                         DBG_EVALUATE_PIECES_1("king", "position")

            /* Si le roi a roqu�, */
            if (CASTLE_STATUS & castle_done_mask[color]) {

              /* alors il obtient un bonus. */
              score += bonus_castling[gp];                                                         DBG_EVALUATE_PIECES_1("king", "castling")
            }
            /* par contre s'il ne peut plus roquer, */
            else if (!(CASTLE_STATUS & castle_by_color_mask[color])) {

              /* il obtient un malus. */
              score += malus_no_castling[gp];                                                      DBG_EVALUATE_PIECES_1("king", "no castling")
            }

            /* Examen de la protection du roi offerte par les pions situ�s devant lui. */

            /* Si le pion situ� sur la m�me colonne est devant le roi, */
            if (pawns[color][x] && RR(y) < RR(pawn_rank[color][x])) {

              /* alors il obtient un malus s'il est trop �loign�, surtout dans l'ouverture. */
              score += malus_king_cover[gp] * (RR(pawn_rank[color][x]) - RR(y) - 1);               DBG_EVALUATE_PIECES_1("king", "outpost front pawn")
            }
            else {

              /* sinon il y a un malus pour absence de couverture. */
              score += malus_king_no_cover[gp];                                                    DBG_EVALUATE_PIECES_1("king", "no cover from front pawn")
            }

            /* Si le pion situ� � droite est devant le roi, */
            if (pawns[color][x + 1] && RR(y) < RR(pawn_rank[color][x + 1])) {

              /* alors il obtient un malus s'il est trop �loign�, surtout dans l'ouverture. */
              score += malus_king_cover[gp] * (RR(pawn_rank[color][x + 1]) - RR(y) - 1);           DBG_EVALUATE_PIECES_1("king", "outpost right pawn")
            }
            else {

              /* sinon il y a un malus pour absence de couverture. */
              score += malus_king_no_cover[gp];                                                    DBG_EVALUATE_PIECES_1("king", "no cover from right pawn")
            }

            /* Si le pion situ� � gauche est devant le roi, */
            if (pawns[color][x - 1] && RR(y) < RR(pawn_rank[color][x - 1])) {

              /* alors il obtient un malus s'il est trop �loign�, surtout dans l'ouverture. */
              score += malus_king_cover[gp] * (RR(pawn_rank[color][x - 1]) - RR(y) - 1);           DBG_EVALUATE_PIECES_1("king", "outpost left pawn")
            }
            else {

              /* sinon il y a un malus pour absence de couverture. */
              score += malus_king_no_cover[gp];                                                    DBG_EVALUATE_PIECES_1("king", "no cover from left pawn")
            }
          }
          break;
      }
    }
  }

  /* En d�but de partie, */
  if (gp == OPENING) {

    /* le programme p�nalise le blocage des pions centraux par une pi�ce amie situ�e sur la case
       devant lui. */

    /* Pion d bloqu�. */
    if (   !moved[84 - 50 * color]
        && board[74 - 30 * color]
        && ((board[74 - 30 * color] >> 3) == color)) {

      score += malus_blocked_pawns;                                                                DBG_EVALUATE_PIECES_2("pawn", "d pawn is blocked")
    }

    /* Pion e bloqu�. */
    if (   !moved[85 - 50 * color]
        && board[75 - 30 * color]
        && ((board[75 - 30 * color] >> 3) == color)) {

      score += malus_blocked_pawns;                                                                DBG_EVALUATE_PIECES_2("pawn", "e pawn is blocked")
    }
  }

  return score;
}
/* End of function : evaluate_pieces */
