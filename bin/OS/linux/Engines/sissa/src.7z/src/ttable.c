/**************************************************************************************************
  File : ttable.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Module de gestion de la table de transposition.

  Le but de cette table est d'�viter au programme de recalculer des positions d�j� rencontr�es.

  Les informations suivantes sont m�moris�es dans la table :
     - la valeur de hachage de la position
     - la profondeur atteinte lors de la derni�re recherche de cette position
     - le type de noeud tel qu'il est d�termin� par la recherche
     - la valeur selon le type de noeud est soit un score exact soit une borne pour ce noeud,
     - l'identifiant du meilleur coup trouv� par la recherche pour la position; le coup sera
       utilis� dans les phases de tri.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "debug.h"
#include "hash.h"
#include "moves.h"
#include "tools.h"
#include "ttable.h"
#include "uci.h"

/**************************************************************************************************
  Data :
**************************************************************************************************/

/* Adresse de la table de transposition. */
ttable_s *tt_address;

/* Taille maximum de la table de transposition. */
int ttable_size;

/* Masque pour calculer l'adresse d'une entr�e dans la table de transposition par rapport � la
   valeur de hachage d'une position. */
unsigned long int tt_mask;

/* Nombre total d'entr�es dans la table de transposition. */
unsigned long int tt_entries = 1;

/* Nombre d'entr�es occup�es de la table de transposition. */
unsigned long int tt_occupied = 0;

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : free_ttable
  Description  : Lib�ration de l'espace m�moire r�serv� � la table de transposition.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void free_ttable (void) {                                                                          DBG_FREE_TTABLE_CALL

  free (tt_address);                                                                               DBG_FREE_TTABLE_1
}
/* End of function : free_ttable */

/**************************************************************************************************
  Function     : initialize_ttable
  Description  : D�termine le nombre d'entr�es de la table de transposition et r�serve l'espace
                 m�moire n�cessaire.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void initialize_ttable (void) {                                                                    DBG_INITIALIZE_TTABLE_CALL

  /* Calcul du nombre d'entr�es que la table de transposition peut contenir, par rapport � la
     taille de la m�moire autoris�e (en Mo). */
  while (tt_entries * sizeof (ttable_s) <= ttable_size << 18) {

    tt_entries <<= 1;
  }

  /* Ce masque permet de calculer l'adresse d'une position dans la table. */
  tt_mask = tt_entries - 1;

  /* Allocation de l'espace m�moire pour la table de transposition. */
  tt_address = malloc (tt_entries * sizeof (ttable_s));

  /* Si l'espace m�moire ne peut �tre r�serv�, */
  if (tt_address == NULL) {

    /* alors un message d'erreur est �mis, */
    tools.send_output (true, "   ERROR : %s can't allocate memory for the "
      "transposition table.\n", PRODUCT_NAME);

    /* et le programme se termine. */
    uci.quit (EXIT_FAILURE);
  }
  else {

    /* Efface le contenu de la m�moire allou�e. */
    memset (tt_address, 0, tt_entries * sizeof (ttable_s));
  }                                                                                                DBG_INITIALIZE_TTABLE_1
}
/* End of function : initialize_ttable */

/**************************************************************************************************
  Function     : read_ttable
  Description  : V�rifie la pr�sence dans la table de transposition d'une position identique � la
                 position courante pour en retirer des informations sur la poursuite de la
                 recherche.
  Parameters   : in  - profondeur de recherche
                 in  - borne alpha
                 in  - borne beta
                 out - indicateur sur l'information trouv�e dans la table
                 out - identifiant du meilleur coup associ�
  Return value : valeur de la position
  Validation   : 1
**************************************************************************************************/
int read_ttable (int depth, int alpha, int beta, int *flag, int *moveid) {                         DBG_READ_TTABLE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int value = 0;          /* Valeur associ�e � la position dans la table. */

ttable_s *tt_pointer;   /* Pour calculer l'adresse associ�e � la position. */

/* --- Function code --------------------------------------------------------------------------- */DBG_READ_TTABLE_START

  /* Par d�faut, aucune information n'est transmise. */
  *flag   = NO_TT_INFO;
  *moveid = 0;

  /* Calcule l'adresse de la position courante dans la table. */
  tt_pointer = tt_address + (h_position & tt_mask);

  /* Si � cette adresse correspond une position dont la valeur de hachage est identique � celle de
     la position courante, */
  if (tt_pointer->h_position == h_position) {

    /* alors l'identifiant du meilleur coup pour cette position est retourn�, */
    *moveid = tt_pointer->moveid;                                                                  DBG_READ_TTABLE_1

    /* ainsi que la valeur asssoci�e qui est ajust�e par rapport � un mat. */
    if (tt_pointer->value >= MIN_MATE) {

      value = tt_pointer->value - search_ply;
    }
    else if (tt_pointer->value <= -MIN_MATE) {

      value = tt_pointer->value + search_ply;
    }
    else {

      value = tt_pointer->value;
    }

    /* Le programme �vitera l'utilisation de l'algorithme "null move" pour les positions o� ce
       serait une perte de temps. */
    if (   tt_pointer->depth >= depth - R
        && tt_pointer->node_type == UPPER_BOUND
        && value < beta) {

      *flag = AVOID_NULL_MOVE;
    }

    if (tt_pointer->depth >= depth) {

      switch (tt_pointer->node_type) {

        case EXACT_SCORE :

          *flag = EXACT_SCORE;
          break;

        case LOWER_BOUND :

          if (value >= beta) {

            *flag = LOWER_BOUND;
          }
          break;

        case UPPER_BOUND :

          if (value <= alpha) {

            *flag = UPPER_BOUND;
          }
          break;
      }
    }
  }

  return value;
}
/* End of function : read_ttable */

/**************************************************************************************************
  Function     : reset_ttable
  Description  : Efface toutes les informations de la table de transposition.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void reset_ttable (void) {                                                                         DBG_RESET_TTABLE_CALL

  memset (tt_address, 0, tt_entries * sizeof (ttable_s));

  /* Maintenant toutes les entr�es de la table sont vides. */
  tt_occupied = 0;                                                                                 DBG_RESET_TTABLE_1
}
/* End of function : reset_ttable */

/**************************************************************************************************
  Function     : search_tt_pv
  Description  : Recherche les coups de la variante principale dans la table de transposition. Pour
                 chaque position est rang� le meilleur coup trouv�. Il est donc possible de suivre
                 l'encha�nement des coups et retrouver ainsi cette variante principale.
  Parameters   : in  - profondeur de recherche
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void search_tt_pv (int depth) {                                                                    DBG_SEARCH_TT_PV_CALL

/* --- Local data ------------------------------------------------------------------------------ */

move_s move = dummy;    /* Au d�but aucun coup n'est identifi�. */

ttable_s *tt_pointer;   /* Pour calculer l'adresse associ�e � la position. */

/* --- Function code --------------------------------------------------------------------------- */DBG_SEARCH_TT_PV_START

  if (depth) {

    /* Calcule l'adresse de la position courante dans la table. */
    tt_pointer = tt_address + (h_position & tt_mask);

    /* Si � cette adresse correspond une position dont la valeur de hachage est identique � celle
       de la position courante, */
    if (tt_pointer->h_position == h_position) {

      /* alors le programme trouve le coup associ� � l'identifiant m�moris�, et s'il est valide, */
      if (moves.verify_moveid (tt_pointer->moveid, &move)) {

        /* la variante principale est mise � jour. */
        pv[1][iterative_depth - depth + 1] = move;
        pv_length[1] = iterative_depth - depth + 2;

        /* Le coup est jou� sur l'�chiquier, */
        moves.make (&move);
        search_ply++;

        /* pour essayer de trouver le coup suivant de la variante. */
        ttable.search_tt_pv (depth - 1);

        /* Une fois la profondeur de r�flexion limite atteinte, la position au d�part de la
           recherche est replac�e sur l'�chiquier. */
        search_ply--;
        moves.unmake (&move);
      }
    }
  }
}
/* End of function : search_tt_pv */

/**************************************************************************************************
  Function     : write_ttable
  Description  : M�morise dans la table de transposition la position courante avec les �l�ments
                 associ�s (voir la description de la table en t�te du module).
  Parameters   : in  - profondeur de recherche
                 in  - type de noeud
                 in  - valeur de la position (fonction du type de noeud)
                 in  - identifiant du meilleur coup trouv�
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void write_ttable (int depth, int node_type, int value, int moveid) {                              DBG_WRITE_TTABLE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

ttable_s *tt_pointer;   /* Pour calculer l'adresse associ�e � la position. */

/* --- Function code --------------------------------------------------------------------------- */DBG_WRITE_TTABLE_START

  /* Calcule l'adresse de la position courante dans la table. */
  tt_pointer = tt_address + (h_position & tt_mask);

  /* V�rifie que la profondeur de recherche atteinte est digne d'int�r�t. */
  if (depth >= tt_pointer->depth) {

    /* La valeur de la position est ajust�e en fonction d'un mat �ventuel. */
    if (value > MIN_MATE) {

      tt_pointer->value = value + search_ply;
    }
    else if (value < -MIN_MATE) {

      tt_pointer->value = value - search_ply;
    }
    else {

      tt_pointer->value = value;
    }

    /* Si l'entr�e dans la table �tait vide, */
    if (!tt_pointer->h_position) {

      /* elle est d�compt�e pour calculer le taux de remplissage. */
      tt_occupied++;
    }                                                                                              DBG_WRITE_TTABLE_1

    /* M�morisation des informations. */
    tt_pointer->h_position = h_position;
    tt_pointer->depth      = depth;
    tt_pointer->node_type  = node_type;
    tt_pointer->moveid     = moveid;
  }
}
/* End of function : write_ttable */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/
ttable_module_s ttable = {

  free_ttable,
  initialize_ttable,
  read_ttable,
  reset_ttable,
  search_tt_pv,
  write_ttable
};
