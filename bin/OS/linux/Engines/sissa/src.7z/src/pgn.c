/**************************************************************************************************
  File : pgn.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Module de conversion d'un fichier de parties au format PGN vers un fichier au
                format LAN. Il est utilis� dans le cadre de la construction de la biblioth�que
                des ouvertures, ou pour le test de l'algorithme de hachage.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "debug.h"
#include "moves.h"
#include "pgn.h"
#include "tools.h"
#include "uci.h"

/**************************************************************************************************
  Macro-instructions :
**************************************************************************************************/

/* Permet de d�caler le contenu d'une cha�ne de cararct�res d'un caract�re vers la gauche. */
#define LEFT_COPY(p1) { \
int i = 0; \
  while (i < strlen (p1)) { \
    p1[i] = p1[i+1]; \
    i++; \
  } \
}

/**************************************************************************************************
  Internal functions prototypes :
**************************************************************************************************/

bool associate_move (int move_code, int mask, move_s *move);
bool convert_game (char *pgn_game, int max_ply, char* lan_game);
bool convert_move (char *pgn_move, move_s *move);

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : convert_file
  Description  : Cette fonction va convertir un fichier de parties au format PGN, dont le chemin
                 est pr�cis� dans le fichier de configuration, vers un fichier dans lequel les
                 parties seront �crites au format LAN.
  Parameters   : out - fichier des parties au format LAN
                 in  - nombre maximum de coups par partie � prendre en compte
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void convert_file (char *lan_games_file_path, int max_ply) {                                            DBG_CONVERT_FILE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

FILE *lan_games_file;             /* Fichier de sortie, des parties au format LAN. */
FILE *pgn_games_file;             /* Fichier d'entr�e, des parties au format PGN. */

bool end_of_game = false;         /* Indique la fin de lecture d'une partie en entr�e. */
bool is_comment = false;          /* Indique la pr�sence d'un commentaire. */

char c;                           /* Chaque caract�re lu dans le fichier en entr�e. */
char lan_game[STRING_LENGTH];     /* Coups de la partie au format LAN. */
char pgn_game[STRING_LENGTH];     /* Coups de la partie au format PGN. */

int count_games = 0;              /* Nombre de parties correctement trait�es. */
int i = 0;                        /* Pour compter les caract�res conserv�s. */
int rejected_games = 0;           /* Nombre de parties non d�cod�es. */
int skip_char = 0;                /* Pour compter les imbrications de commentaires. */

/* --- Function code --------------------------------------------------------------------------- */

  if ((pgn_games_file = fopen (pgn_games_file_path, "r")) != NULL) {

    if ((lan_games_file = fopen (lan_games_file_path, "w")) != NULL) {

      tools.send_output (true, "\n   The initial position will be set on the board.\n");
      tools.send_output (true, "\n   Games are read from file %s", pgn_games_file_path);
      tools.send_output (true, "\n   (Max ply : %d)\n", max_ply);

      printf ("\n   Each point equal 100 games, a line 5000 games.\n   ");

      while ((c = fgetc (pgn_games_file)) != EOF) {

        /* Un des caract�res test�s indique le d�but d'un commentaire ou information � ne pas
           exploiter. Le programme tiendra compte de leur niveau d'imbrication. */
        if (c == '[' || c == '(' || c == '{') {

          skip_char++;
          is_comment = true;
        }

        /* Un des caract�res test�s indique la fin d'un niveau de commentaire ou d'information. */
        if (c == ']' || c == ')' || c == '}') skip_char--;

        /* Si les commentaires ou informations non exploit�es sont termin�es, */
        if (skip_char == 0) {

          if (is_comment) {

            c = fgetc (pgn_games_file);
            is_comment = false;
          }

          /* Le caract�re '$' introduit une annotation apport�e au coup. */
          if (c == '$') {

            while (true) {

              c = fgetc (pgn_games_file);
              if (c == ' ' || c == '\n') break;
            }
          }

          /* Les caract�res 'x', '=', '+' et '#' ne sont pas pris en compte. */
          if (c != 'x' && c != '=' && c != '+' && c != '#') {

            /* Les retours � la ligne sont convertis en ' '. */
            if (c == '\n') c = ' ';

            /* Enfin les caract�res lus sont conserv�s; seul le premier ' ' est conserv�. */
            if (c != ' ' || (i > 1 && pgn_game[i-1] != ' ')) pgn_game[i++] = c;

            /* Les caract�res d'alignement des coups noirs sont saut�s. */
            if (   pgn_game[i-1] == '.' && pgn_game[i-2] == '.' && pgn_game[i-3] == '.') {

              i -=1;
              while (pgn_game[i] != ' ') i--;
            }

            /* Le test de la pr�sence d'un r�sultat ne doit �tre fait que lorsque la partie
               comprent au moins un coup. */
            if (i >= 8) {

              /* Le r�sultat de la partie n'est pas conserv�. */
              if (   pgn_game[i-3] == '1' && pgn_game[i-2] == '-' && pgn_game[i-1] == '0') {

                end_of_game = true; i -=4;
              }
              else if (   pgn_game[i-3] == '0' && pgn_game[i-2] == '-' && pgn_game[i-1] == '1') {

                end_of_game = true; i -=4;
              }
             else if (   pgn_game[i-7] == '1' && pgn_game[i-6] == '/' && pgn_game[i-5] == '2'
                       && pgn_game[i-4] == '-'
                       && pgn_game[i-3] == '1' && pgn_game[i-2] == '/' && pgn_game[i-1] == '2') {

                end_of_game = true; i -=8;
              }
            }

            /* Si la lecture de la partie est finie, */
            if (end_of_game == true) {

              pgn_game[i] = '\0';                                                                  DBG_CONVERT_FILE_1

              count_games++;

              if ((count_games % 100) == 0) {

                printf (".");

                if ((count_games % 5000) == 0) printf ("\n   ");
              }

              /* La liste des coups est convertie au format LAN. */
              if (strlen (pgn_game) > 10 && convert_game (pgn_game, max_ply, lan_game)) {

                if (count_games > 1) {

                  fprintf (lan_games_file, "\n");
                }

                fprintf (lan_games_file, lan_game);
              }
              else {

                rejected_games++;
              }

              /* R�initialisation des variables pour traiter la partie suivante. */
              i = 0;
              end_of_game = false;
            }
          }
        }
      }

      tools.send_output (true, "\n\n   %s write %d games in file %s.\n"
        "   (Games rejected : %d)\n", PRODUCT_NAME, count_games - rejected_games,
        lan_games_file_path, rejected_games);

      fclose (lan_games_file);
    }
    else {

      tools.send_output (true, "\n   ERROR : %s can't open the output lan games file !"
        "\n           (%s)\n",
        PRODUCT_NAME, lan_games_file_path);
    }

    fclose (pgn_games_file);
  }
  else {

    tools.send_output (true, "\n   ERROR : %s can't open the pgn games file !"
      "\n           (%s)\n",
      PRODUCT_NAME, pgn_games_file_path);
  }
}
/* End of function : convert_file */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/

pgn_module_s pgn = {

  convert_file
};

/**************************************************************************************************
  Function     : associate_move
  Description  : Cette fonction va essayer d'associer un coup possible dans la position courante au
                 coup fourni en entr�e sous la forme d'un nombre caract�ristique.
  Parameters   : in  - nombre pour caract�riser le coup
                 in  - masque concernant les informations manquantes sur la case de d�part du coup
                 out - coup trouv�
  Return value : Un coup possible est trouv� (true) ou non (false).
  Validation   : 1
**************************************************************************************************/
bool associate_move (int move_code, int mask, move_s *move) {                                      DBG_ASSOCIATE_MOVE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int moves_number;               /* Nombre de coups g�n�r�s. */
int tmp_move_code = 0;          /* Nombre pour comparer le coup en entr�. */

move_s moves_list[MAX_MOVES];   /* Pour ranger les coups g�n�r�s. */

/* --- Function code --------------------------------------------------------------------------- */DBG_ASSOCIATE_MOVE_START

  /* Cr�ation de la liste des coups possibles (pas forc�ment l�gaux) dans la position courante. */
  moves_number = moves.generate (moves_list, false);

  while (moves_number > 0) {

    /* R�cup�ration du type de la pi�ce. */
    tmp_move_code = board[moves_list[moves_number].from] & 0x7;
    tmp_move_code <<=4;

    /* Colonne de la case de d�part. */
    tmp_move_code |= file[moves_list[moves_number].from];
    tmp_move_code <<=4;

    /* Rang�e de la case de d�part. */
    tmp_move_code |= rank[moves_list[moves_number].from];
    tmp_move_code <<=4;

    /* Colonne de la case d'arriv�e. */
    tmp_move_code |= file[moves_list[moves_number].to];
    tmp_move_code <<=4;

    /* Rang�e de la case d'arriv�e. */
    tmp_move_code |= rank[moves_list[moves_number].to];
    tmp_move_code <<=4;

    /* Ajour de l'�ventuelle pi�ce de promotion. */
    tmp_move_code |= moves_list[moves_number].promoted;

    /* Application du masque pour ne pas comparer les donn�es manquantes. */
    tmp_move_code &= mask;

    /* Si un coup est trouv� dans la liste des coups possibles, */
    if (tmp_move_code == move_code) {

      /* le programme v�rifie sa l�galit�, */
      moves.make (&moves_list[moves_number]);
      if (moves.is_legal (&moves_list[moves_number])) {

        /* avant de le remonter. */
        *move = moves_list[moves_number];                                                          DBG_ASSOCIATE_MOVE_END_1

        moves.unmake (&moves_list[moves_number]);

        /* La recherche est alors arr�t�e. */
        return true;
      }
      moves.unmake (&moves_list[moves_number]);
    }

    moves_number--;
  }                                                                                                DBG_ASSOCIATE_MOVE_END_2

  /* La recherche est infructueuse, aucune association n'est trouv�e. */
  return false;
}
/* End of function : associate_move */

/**************************************************************************************************
  Function     : convert_game
  Description  : Cette fonction construit une cha�ne avec la liste des coups de la partie au format
                 LAN.
  Parameters   : in  - liste des coups au format PGN
                 in  - nombre maximum de coups d'une partie � prendre en compte
                 out - liste des coups au format LAN
  Return value : Tous les coups ont �t� trouv�s (true) ou non (false)
  Validation   : 1
**************************************************************************************************/
bool convert_game (char *pgn_game, int max_ply, char *lan_game) {

/* --- Local data ------------------------------------------------------------------------------ */

bool game_is_correct = true; /* Indique si la partie a �t� d�cod�e enti�rement. */

char lan_move[6];            /* Coup au format LAN apr�s conversion du format PGN. */
char pgn_move[6];            /* Coup de la partie au format PGN. */
char *pointer;               /* Pour parcourir la cha�ne d'une partie donn�e en entr�e. */

int ply = 0;                 /* Nombre de coups lus. */

move_s move;                 /* Coup au format interne une fois associ� � un coup PGN. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Initialisation de l'analyse de la partie et saut du num�ro du coup n�1. */
  pointer = strtok (pgn_game, " ");

  strcpy (lan_game, "");

  /* Tant que la fin de la partie n'est pas atteinte, */
  for (pointer = strtok (NULL, " ");
       pointer != NULL && ply < max_ply;
       pointer = strtok (NULL, " ")) {

    /* Chaque mot trouv� est isol�. */
    strcpy (pgn_move, pointer);

    /* Si ce n'est pas un num�ro de coup suivi d'un ".", */
    if (pgn_move[strlen (pgn_move) - 1] != '.') {

      /* alors si le coup a �t� identifi� parmi les coups possibles, */
      if (convert_move (pgn_move, &move)) {

        /* il est convertit au format LAN, */
        moves.convert_pgm_move (&move, lan_move);

        /* et ajout� � la suite des autres. */
        strcat (lan_game, lan_move);
        strcat (lan_game, " ");

        /* Enfin il est jou� sur l'�chiquier avant de passer au coup suivant. */
        moves.make (&move);

        ply++;
      }
      else {

        /* sinon le d�codage de la partie est arr�t�. */
        game_is_correct = false;
        break;
      }
    }
  }

  /* La position initiale est remise sur l'�chiquier avant de passer � une autre partie. */
  uci.ucinewgame ();

  return game_is_correct;
}
/* End of function : convert_game */

/**************************************************************************************************
  Function     : convert_move
  Description  : Cette fonction va calculer un nombre qui caract�risera le coup jou� : pi�ce
                 d�plac�e + case de d�part + case d'arriv�e + pi�ce de promotion �ventuelle. Les
                 cases de d�part et d'arriv�es sont repr�sent�es par leur colonne et rang�e. Chaque
                 information est cod�e sur 4 bits.
  Parameters   : in  - coup au formet PGN
                 out - coup au format LAN
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
bool convert_move (char *pgn_move, move_s *move) {

/* --- Local data ------------------------------------------------------------------------------ */

int move_code = 0; /* Nombre pour caract�riser le coup. */
int mask;          /* Masque pour indiquer les informations manquantes sur la case de d�part. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Si le coup est un roque, il est remplac� par le d�placement du roi correspondant. */
  if (pgn_move[0] == 'O') {

    if (strlen (pgn_move) == 3) {

      if (active_color == WHITE) {

        strcpy (pgn_move, "Kg1");
      }
      else {

        strcpy (pgn_move, "Kg8");
      }
    }
    else {

      if (active_color == WHITE) {

        strcpy (pgn_move, "Kc1");
      }
      else {

        strcpy (pgn_move, "Kc8");
      }
    }
  }

  /* Informations sur le type de pi�ce qui est d�plac�e :
     -------------------------------------------------- */

  if (pgn_move[0] >= 'a' && pgn_move[0] <= 'h') {

   move_code = PAWN;
  }
  else {

    switch (pgn_move[0]) {

      case 'B' : move_code = BISHOP; break;
      case 'K' : move_code = KING;   break;
      case 'N' : move_code = KNIGHT; break;
      case 'Q' : move_code = QUEEN;  break;
      case 'R' : move_code = ROOK;   break;
    }

    LEFT_COPY(pgn_move);
  }
  move_code <<= 4;

  /* Informations sur la case de d�part :
     ---------------------------------- */

  if (   pgn_move[0] >= 'a' && pgn_move[0] <= 'h'
      && pgn_move[1] >= 'a' && pgn_move[1] <= 'h') {

    /* Seule la colonne est mentionn�e. */
    move_code |= (pgn_move[0] - 'a' + 1);
    move_code <<= 8;
    LEFT_COPY(pgn_move);
    mask = 0xFF0FFF;
  }
  else if (pgn_move[0] >= '1' && pgn_move[0] <= '8') {

    /* Seule la rang�e est mentionn�e. */
    move_code <<= 4;
    move_code |= (pgn_move[0] - '0');
    move_code <<= 4;
    LEFT_COPY(pgn_move);
    mask = 0xF0FFFF;
  }
  else {

    /* Aucune information concernant la case de d�part n'est pr�sente. */
    move_code <<= 8;
    mask = 0xF00FFF;
  }

  /* Informations sur la case de d'arriv�e :
     ------------------------------------- */

  /* Ajout de la colonne de la case d'arriv�e. */
  move_code |= (pgn_move[0] - 'a' + 1);
  move_code <<= 4;
  LEFT_COPY(pgn_move);

  /* Ajout de la rang�e de la case d'arriv�e. */
  move_code |= (pgn_move[0] - '0');
  move_code <<= 4;
  LEFT_COPY(pgn_move);

  /* Informations sur une �ventuelle promotion. */
  if (strlen (pgn_move) != 0) {

    switch (pgn_move[0]) {

      case 'B' : move_code |= BISHOP; break;
      case 'N' : move_code |= KNIGHT; break;
      case 'Q' : move_code |= QUEEN;  break;
      case 'R' : move_code |= ROOK;   break;
    }
  }

  return associate_move (move_code, mask, move);
}
/* End of function : convert_move */
