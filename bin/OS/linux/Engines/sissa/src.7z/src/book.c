/**************************************************************************************************
  File : book.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Gestion de la biblioth�que des ouvertures.

  Elle est constitu�e de deux fichiers, un pour les parties ou le programme a les blancs et un pour
  les parties avec les noirs. Chaque fichier comprend une liste de coups en notation alg�brique.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "book.h"
#include "debug.h"
#include "hash.h"
#include "moves.h"
#include "pgn.h"
#include "tools.h"

/**************************************************************************************************
  Constants :
**************************************************************************************************/

/* Valeurs limites pour quelques constantes g�n�rales : */
#define MAX_OPENING_LINES     256
#define OPENING_LINE_LENGTH   256

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : select_move
  Description  : S�lection d'un coup dans la biblioth�que des ouvertures.
  Parameters   : out - coup s�lectionn� dans la biblioth�que.
  Return value : Le programme a trouv� un coup (true) ou non (false).
  Validation   : 1
**************************************************************************************************/
bool select_move (move_s *move) {                                                                  DBG_SELECT_MOVE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

FILE *openings_file;                    /* Fichier contenant les ouvertures. */

bool book_move = false;                 /* Indique si le coup d'une ouverture est d�j� jou�. */
bool line_to_keep;                      /* Indique si une ouverture se rapporte � la partie. */
bool move_in_line;                      /* Indique si un coup est dans une ligne de jeu. */

char lan_move[6];                       /* Coup en notation alg�brique. */
char lan_played_moves[MAX_BOOK_PLY][6]; /* Liste des coups jou�s . */
char moves_line[STRING_LENGTH];         /* Coups pour une ligne de jeu. */
char opening_line[STRING_LENGTH];       /* Ligne de jeu de la biblioth�que. */
char opening_lines[MAX_OPENING_LINES][MAX_BOOK_PLY * 6];
                                        /* Liste des ouvertures qui se rapportent � la partie. */
char *pointer;                          /* Pour parcourir la liste des coups. */

/* Pour calculer le temps mis � chercher un coup dans la biblioth�que. */
clock_t start_chronometer;
clock_t stop_chronometer;

int count_lines;                        /* Nombre d'ouvertures trouv�es dans la biblioth�que. */
int moveid;                             /* Idenfiant d'un coup. */
int selected_line;                      /* Num�ro de l'ouverture s�lectionn�e. */

/* --- Function code --------------------------------------------------------------------------- */

  /* M�morise le d�but de la recherche. */
  start_chronometer = clock ();

  /* Initialisation, � partir de l'heure actuelle, d'une nouvelle s�quence de nombres
     pseudo-al�atoires pour varier le choix des ouvertures. */
  srand(time(NULL));

  /* Si le fichier qui contient les ouvertures n'est pas trouv�, */
  if ((openings_file = fopen ((active_color ? white_book_path : black_book_path), "r")) == NULL) {

    /* alors un message est affich� et la recherche est interrompue. */
    if (uci_mode) {

      tools.send_output (true,
        "info string %s can't open the openings file %s",
        PRODUCT_NAME, active_color ? white_book_path : black_book_path);
    }
    else {

      tools.send_output (true,
        "\n   WARNING : %s can't open the openings file %s,\n"
        "             however it will continue to play.\n\n",
        PRODUCT_NAME, active_color ? white_book_path : black_book_path);
    }

    use_book = false;
  }
  else {

    /* Premi�re �tape : construction de la liste des coups jou�s.
       ---------------------------------------------------------- */

    /* Tous les coups jou�s depuis le d�but de la partie, */                                       DBG_SELECT_MOVE_1_1
    for (int i = 0; i < game_ply; i++) {

      /* sont rang�s en notation alg�brique dans un tableau. */
      moves.convert_pgm_move (&played_moves[i], lan_played_moves[i]);                              DBG_SELECT_MOVE_1_2
    }                                                                                              DBG_SELECT_MOVE_0

    /* Seconde �tape : recherche des lignes d'ouvertures possibles.
       ------------------------------------------------------------ */

    /* Le programme va rechercher celles qui contiennent tous les coups jou�s. Cette fa�on de
       proc�der va permettre de tenir compte des inversions de coups. Le nombre des lignes
       s�lectionn�es sera limit� pour �viter les d�bordements. */
    count_lines = 0;
    while (!feof (openings_file) && count_lines < MAX_OPENING_LINES) {

      /* Lecture d'une ligne d'ouverture dans le fichier des ouvertures. */
      fgets (opening_line, STRING_LENGTH, openings_file);

      /* Si la ligne n'est pas un commentaire, */
      if (opening_line[0] != '#') {

        /* alors le caract�re de retour � la ligne est supprim�, */
        opening_line[strlen(opening_line) - 1] = '\0';                                             DBG_SELECT_MOVE_2

        line_to_keep = true;
        int i = game_ply;

        /* et tant que la ligne d'ouverture est semblable, pour chaque coup jou� depuis le d�but de
           la partie, */
        while (--i >= 0 && line_to_keep) {

          move_in_line = false;
          strcpy (moves_line, opening_line);
          int j = 0;

          /* le programme va v�rifier qu'il est pr�sent dans la ligne d'ouverture, */
          for (pointer = strtok (moves_line, " ");
               pointer != NULL && j <= game_ply && !move_in_line;
               pointer = strtok (NULL, " ")) {                                                     DBG_SELECT_MOVE_3

            if (!strcmp (lan_played_moves[i], pointer)) {                                          DBG_SELECT_MOVE_4

              move_in_line = true;
            }

            j++;
          }

          /* Si le coup n'est pas pr�sent dans la ligne d'ouverture, */
          if (!move_in_line) {                                                                     DBG_SELECT_MOVE_5

            /* alors cette derni�re ne sera pas conserv�e. */
            line_to_keep = false;
          }
        }

        /* Lorsque le programme a v�rifi� que tous les coups jou�s sont pr�sents dans la ligne
           d'ouverture lue dans le fichier, */
        if (line_to_keep) {                                                                        DBG_SELECT_MOVE_6

          /* elle sera m�moris�e pour l'�tape suivante. */
          strcpy (opening_lines[count_lines++], opening_line);
        }
      }
    }                                                                                              DBG_SELECT_MOVE_0

    /* Troisi�me �tape : S�lection d'une ligne d'ouverture.
       ---------------------------------------------------- */

    /* Si des ouvertures sont trouv�es, */
    if (count_lines) {

      /* alors l'une d'entre elles sera s�lectionn�e al�atoirement. */
      selected_line = rand() % count_lines;                                                        DBG_SELECT_MOVE_0

      tools.send_output (true, "%s Openings book line (%d/%d)\n",
        uci_mode ? "info string" : "\n  ", selected_line + 1, count_lines);                        DBG_SELECT_MOVE_8

      /* Quatri�me �tape : S�lection du prochain coup � jouer.
         ----------------------------------------------------- */

      strcpy (moves_line, opening_lines[selected_line]);
      int j = 0;

      /* Pour chaque coup de la ligne de jeu s�lectionn�e, */
      for (pointer = strtok (moves_line, " ");
           pointer != NULL && j <= game_ply && !book_move;
           pointer = strtok (NULL, " ")) {

        int i = game_ply;
        move_in_line = false;

        /* le programme parcourra toute la liste des coups jou�s, tant qu'il ne sera pas trouv�. */
        while (--i >= 0 && !move_in_line) {                                                        DBG_SELECT_MOVE_9

          if (!strcmp (lan_played_moves[i], pointer)) {

            move_in_line = true;
          }
        }

        j++;

        /* Si le coup n'est toujours pas trouv� une fois la liste parcourue, */
        if (!move_in_line) {

          /* alors il est celui qui doit �tre jou� par le programme. */
          book_move = true;
          strcpy (lan_move, pointer);                                                              DBG_SELECT_MOVE_10
        }
      }

      /* Si apr�s avoir calcul� l'identifiant du coup trouv�, le programme trouve un coup possible
         associ�, */
      if (   moves.compute_moveid (lan_move, &moveid)
          && moves.verify_moveid (moveid, move)) {

        /* alors la recherche est termin�e, */
        stop_chronometer = clock ();

        /* et le r�sultat est affich�. */
        tools.send_output (true, "%s Elapsed time to select a book move : %.1f s\n",
          uci_mode ? "info string" : "\n  ",
          (stop_chronometer - start_chronometer) / (double) CLOCKS_PER_SEC);
      }
      else {

        /* sinon le coup n'est pas possible, */
        book_move = false;

        /* ce qui signifie que la ligne de jeu est probablement erron�e. */
        tools.send_output (true,
          "%s WARNING : Opening line is probably bad : %s",
          uci_mode ? "info string" : "\n  ", opening_lines[selected_line]);
      }
    }

    /* Le fichier des ouvertures est ferm�, */
    fclose (openings_file);
  }

  /* Le r�sultat de la recherche est retourn�. */
  return book_move;
}
/* End of function : select_move */

/**************************************************************************************************
  Module declaration :
**************************************************************************************************/
book_module book = {

  select_move
};
