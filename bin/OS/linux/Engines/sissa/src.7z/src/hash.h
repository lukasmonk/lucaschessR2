/**************************************************************************************************
  File : hash.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "hash".
**************************************************************************************************/

#ifndef HASH_H
#define HASH_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* D�finition d'un type sur un mot de 64 bits pour les valeurs de hachage : */
typedef uint64_t h_value_s;

/* Fonctions externes du module : */
typedef struct {

  h_value_s (*compute_h_position) (void);
  void (*initialize_h_values) (void);

} hash_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern hash_module_s hash;

extern h_value_s h_position;
extern h_value_s h_position_history[MAX_MOVES * 2];

extern h_value_s h_values[16][BOARD_SIZE];
extern h_value_s h_values_color[2];
extern h_value_s h_values_ep[BOARD_SIZE];
extern h_value_s h_values_castle[256];

#endif /* HASH_H */
