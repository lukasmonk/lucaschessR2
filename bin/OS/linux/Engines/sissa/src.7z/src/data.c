/**************************************************************************************************
  File : data.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Donn�es globales du programme avec leur description.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des donn�es globales du programme : */
#include "data.h"

/**************************************************************************************************
  Data :
**************************************************************************************************/

/* Fichier journal pour enregistrer les �changes avec le programme. */
FILE *log_file;

/* Indique si la r�flexion du programme sera affich�e pour jouer � l'aveugle. */
bool blind_game;

/* Indique si le programme joue automatiquement � la r�ception d'un coup.
   (In UCI mode, the engine will always be in forced mode which means it should never start
    calculating or pondering without receiving a "go" command first) */
bool forced_mode;

/* The program stop its search when the maximum depth is reached. */
bool search_on_depth;

/* Indique si l'�chiquier doit �tre affich� en mode console. */
bool show_board;

/* Indique si les �changes avec le programme se font en respectant le protocole UCI. */
bool uci_mode;

/* Indique si le programme doit utiliser la biblioth�que des ouvertures. */
bool use_book;

/* Indique si le programme doit trier les coups en tenant compte des captures. */
bool use_captured;

/* Indique si le programme doit utiliser l'heuristique concernant l'historique des d�placements. */
bool use_history;

/* Indique si le programme doit utiliser l'heuristique concernant les coups remarquables. */
bool use_killers;

/* Indique si le fichier journal est utilis�. */
bool use_log;

/* Indique si le programme doit utiliser l'algorithme "null move". */
bool use_null_move;

/* Indique si le programme doit suivre la variante principale pour trier les coups. */
bool use_pv;

/* Indique si le programme doit utiliser la table de transposition. */
bool use_ttable;

/* Biblioth�que des ouvertures du programme avec les noirs (fichier de parties au format LAN). */
char black_book_path[STRING_LENGTH];

/* Fichier de parties au format LAN la conversion d'un fichier au format PGN. */
char lan_games_file_path[STRING_LENGTH];

/* Fichier de parties au format PGN pour construire la biblioth�que des ouvertures ou effectuer des
   tests avec la fonction de hachage (voir la commande "htest"). */
char pgn_games_file_path[STRING_LENGTH];

/* La position de d�part standard au format FEN/EPD. */
char start_position[STRING_LENGTH] =
  { "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" };

/* Biblioth�que des ouvertures du programme avec les blancs (fichier de parties au format LAN). */
char white_book_path[STRING_LENGTH];

/* Permet le temps depuis le d�but de la r�flexion du programme. */
clock_t start_thinking_time;

/* Masques pour isoler petit et grand roque de chaque couleur.
  (voir la description de castle_status) */
const int castle_by_color_mask[2] = { 0xFC, 0xF3 };

/* Masques pour isoler les donn�es de la variable castle_status, afin de savoir si les roques noirs
   et blancs sont effectu�s.
  (voir la description de castle_status) */
const int castle_done_mask[2] = { 0xC0, 0x30 }; /* Roques effectu�s */

/* Masques pour isoler les donn�es de la variable castle_status, afin de savoir si les roques noirs
   et blancs sont possibles.
  (voir la description de castle_status) */
const int castle_possible_mask[2] = { 0x0C, 0x03 }; /* Roques possibles */

/* Pour chaque case de l'�chiquier, donne le num�ro de la colonne. */
const int file[BOARD_SIZE] = {
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

/* Valeur de base des pi�ces du jeu d'�checs. */
const int pieces_value[7] = { 0, 100, 300, 300, 500, 900, 0 };

/* Pour chaque case de l'�chiquier, donne le num�ro de la rang�e. */
const int rank[BOARD_SIZE] = {
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
 0, 2, 2, 2, 2, 2, 2, 2, 2, 0,
 0, 3, 3, 3, 3, 3, 3, 3, 3, 0,
 0, 4, 4, 4, 4, 4, 4, 4, 4, 0,
 0, 5, 5, 5, 5, 5, 5, 5, 5, 0,
 0, 6, 6, 6, 6, 6, 6, 6, 6, 0,
 0, 7, 7, 7, 7, 7, 7, 7, 7, 0,
 0, 8, 8, 8, 8, 8, 8, 8, 8, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

/* Tableau qui donne pour chaque rang�e de l'�chiquier son rang par rapport � la couleur. */
const int reverse_rank[2][9] = {
  { 0, 8, 7, 6, 5, 4, 3, 2, 1},
  { 0, 1, 2, 3, 4, 5, 6, 7, 8}
};

/* La couleur du camp qui a le trait.
  (Pour les valeurs possibles, cf "Noms des couleurs" dans data.h) */
int active_color;

/* Temps de base (en ms) allou� pour un coup, calcul� au d�but de la partie. */
int base_time;

/* L'�chiquier est repr�sent� par un tableau lin�aire de 120 cases :
   a1 = 21, e1 = 25, h1 = 28, a8 = 91, e8 = 95, h8 = 98.
{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
  0, a1, b1, c1, d1, e1, f1, g1, h1,  0,
  0, a2, b2, c2, d2, e2, f2, g2, h2,  0,
  0, a3, b3, c3, d3, e3, f3, g3, h3,  0,
  0, a4, b4, c4, d4, e4, f4, g4, h4,  0,
  0, a5, b5, c5, d5, e5, f5, g5, h5,  0,
  0, a6, b6, c6, d6, e6, f6, g6, h6,  0,
  0, a7, b7, c7, d7, e7, f7, g7, h7,  0,
  0, a8, b8, c8, d8, e8, f8, g8, h8,  0,
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 } */
int board[BOARD_SIZE];

/* Indique les possibilit�s de roque blanc et noir :
   - bit 1 petit roque blanc possible
   - bit 2 grand roque blanc possible
   - bit 3 petit roque noir possible
   - bit 4 grand roque noir possible
   Indique les roques effectu�s :
   - bit 5 petit roque blanc effectu�
   - bit 6 grand roque blanc effectu�
   - bit 7 petit roque noir effectu�
   - bit 8 grand roque noir effectu� */
int castle_status[MAX_MOVES * 2];

/* La couleur jou�e par le programme.
   (Pour les valeurs possibles, cf "Noms des couleurs" dans data.h) */
int computer_color;

/* Temps de r�flexion �coul� en milli�mes de secondes. */
int elapsed_time_ms;

/* La case de prise en passant; elle est renseign�e seulement si le coup pr�c�dent correspond �
   l'avance d'un pion de deux cases : */
int ep_square[MAX_MOVES * 2];

/* This number is the fullmove number. It will have the value "1" for the first move of a game for
   both White and Black. It is incremented by one immediately after each move by Black. */
int fullmove;

/* This number is the count of halfmoves since the begin of the game. */
int game_ply;

/* This number is the count of halfmoves (or ply) since the last pawn advance or capturing move. It
   is used for the fifty move draw rule. */
int halfmove;
int halfmove_history[MAX_MOVES * 2];

/* Profondeur de recherche atteinte (en demi-coups). */
int iterative_depth;

/* Position des rois blancs et noirs. */
int king[2];

/* Nombre maximum de coups par partie dans la biblioth�que des ouvertures. */
int max_book_ply;

/* Profondeur de recherche maximum (permet principalement de donner une limite � la r�flexion). */
int max_iterative_depth;

/* The maximum amount of time (in ms) for the search. */
int max_search_time;

/* Profondeur de recherche minimum (permet d'assurer au programme un minimum de r�flexion). */
int min_iterative_depth;

/* Indique pour chaque case de l'�chiquier si une pi�ce a �t� d�plac�e. */
int moved[BOARD_SIZE];

/* Nombre de noeuds de l'arbre de recherche parcourus par le programme. */
int nodes;

/* Nombre de pi�ces sur l'�chiquier, blanches et noires, autres que pions et rois. Permet de
   m�moriser l'�volution de ce nombre pendant la recherche. */
int piece_count;

/* Indique la case des pi�ces (16 pi�ces au maximum pour chaque couleur). */
int pieces[2][17];

/* Le nombre de pi�ces de chaque couleur. */
int pieces_number[2];

/* Adresse de la fiche associ�e � la pi�ce situ�e sur une case. */
int *pieces_ptr[BOARD_SIZE];

/* Longueur de la variante principale � chaque demi-coup de l'arbre de recherche. */
int pv_length[MAX_SEARCH_PLY];

/* M�morise le nombre de r�p�titions d'une position, depuis le d�but de la partie, avant son
   �valuation pour �viter des parties nulles lorsque le programme poss�de un net avantage. */
int repeats;

/* R�sultat de la partie.
   (Pour les valeurs possibles, cf "Noms des r�sultats" dans data.h). */
int result;

/* This number is the count of halfmoves since the start of the search. */
int search_ply;

/* Nombre de pi�ces sur l'�chiquier (cf piece_count), au d�but de chaque nouvelle recherche. */
int start_piece_count;

/* Temps allou� pour la r�flexion du programme (en milli�mes de seconde). */
int time_for_move;

/* Temps allou� pour la r�flexion du programme en mode console (en milli�mes de seconde). */
int time_in_console_mode;

/* Coup factice utilis� au retour des fonctions lorsqu'aucun coup n'est � prendre en compte, ou
   pour initialiser des donn�es. */
move_s dummy;

/* Liste des coups jou�s (en nombre de demi-coups). */
move_s played_moves[MAX_MOVES * 2];

/* Liste des coups de la variante principale � chaque demi-coup de l'arbre de recherche. */
move_s pv[MAX_SEARCH_PLY][MAX_SEARCH_PLY];
