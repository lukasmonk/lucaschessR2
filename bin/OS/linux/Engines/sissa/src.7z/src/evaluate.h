/**************************************************************************************************
  File : evaluate.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "evaluate".
**************************************************************************************************/

#ifndef EVALUATE_H
#define EVALUATE_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Fonctions externes du module : */
typedef struct {

  int (*evaluate_position) (void);

} evaluate_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern evaluate_module_s evaluate;

#endif /* EVALUATE_H */
