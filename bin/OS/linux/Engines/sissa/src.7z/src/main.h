/**************************************************************************************************
  File : main.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te du module principal.
**************************************************************************************************/

#ifndef MAIN_H
#define MAIN_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te de la librairie standard du langage C : */
#include <ctype.h>
#include <limits.h>
#include <math.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/**************************************************************************************************
  Constants :
**************************************************************************************************/

/* Informations sur le programme */
#define PRODUCT_AUTHOR       "Christophe J. Mandin"
#define PRODUCT_NAME	     "Sissa"

/* Nom des fichiers utilis�s par le programme : */
#define CONFIG_FILE          "etc/config_file.txt"
#define HELP_FILE            "etc/help_file.txt"
#define LOG_FILE             "log/log_file.txt"
#define TREE_FILE            "log/tree_file.txt"
#define TT_FILE              "log/tt_file.csv"

/* Valeurs limites pour quelques constantes g�n�rales : */
#define BOARD_SIZE              120
#define INF                   32000
#define MATE                  30000
#define MAX_BOOK_PLY             40
#define MAX_MOVES               256
#define MAX_SEARCH_PLY           64
#define MIN_BOOK_PLY             10
#define MIN_MATE                       (MATE - MAX_SEARCH_PLY)
#define STRING_LENGTH          4096

/* Noms des huit colonnes de l'�chiquier : */
#define A 1
#define B 2
#define C 3
#define D 4
#define E 5
#define F 6
#define G 7
#define H 8

/* Noms des couleurs des deux camps : */
#define BLACK 0
#define WHITE 1

/* Valeurs du contenu des cases de l'�chiquier : */
#define NONE     0

#define PAWN     1
#define KNIGHT   2
#define BISHOP   3
#define ROOK     4
#define QUEEN    5
#define KING     6

#define BPAWN    1
#define BKNIGHT  2
#define BBISHOP  3
#define BROOK    4
#define BQUEEN   5
#define BKING    6

#define WPAWN    9
#define WKNIGHT 10
#define WBISHOP 11
#define WROOK   12
#define WQUEEN  13
#define WKING   14

#define FRAME   15

/* Noms pour quelques coups sp�ciaux : */
#define NORMAL_MOVE    0
#define KING_CASTLING  1
#define QUEEN_CASTLING 2
#define EN_PASSANT     3
#define PROMOTION      4

/* Noms des diff�rentes phases de la partie : */
#define OPENING      0
#define MIDDLE       1
#define ENDGAME      2
#define UNDEFINED_GP 3

/* Noms des r�sultats possibles pour une partie : */
#define NO_RESULT          0
#define BLACK_IS_MATED     1
#define WHITE_IS_MATED     2
#define DRAW_FIFTY_MOVES   3
#define DRAW_REPETITION    4
#define DRAW_STALEMATE     5

/* The depth reduction factor (null move pruning algorithm) : */
#define R 2

/* Pour nommer un type non sign� sur 64 bits : */
#define u64 uint64_t

#endif /* MAIN_H */
