/**************************************************************************************************
  File : game.h

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Fichier en-t�te pour le module "game".
**************************************************************************************************/

#ifndef GAME_H
#define GAME_H

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des informations g�n�rales du programme : */
#include "main.h"

/* Fichier en-t�te des donn�es globales : */
#include "data.h"

/**************************************************************************************************
  Types :
**************************************************************************************************/

/* Fonctions externes du module : */
typedef struct {

  int (*check_game_phase) (int color);
  void (*go_on) (void);
  void (*initialize) (const char string[]);

} game_module_s;

/**************************************************************************************************
  Data :
**************************************************************************************************/

extern game_module_s game;

#endif /* GAME_H */
