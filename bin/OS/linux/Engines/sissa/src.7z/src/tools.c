/**************************************************************************************************
  File : tools.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Diverses fonctions utilis�es tout au long du programme.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "debug.h"
#include "evaluate.h"
#include "hash.h"
#include "moves.h"
#include "tools.h"
#include "ttable.h"
#include "uci.h"

/**************************************************************************************************
  Macro instructions :
**************************************************************************************************/

/* Pour factoriser la lecture des param�tres en provenance du fichier de configuration :
   ----------------------------------------------------------------------------------- */

#define READ_BOOLEAN_PARAMETER(n,p) \
  if (!strcmp (pointer, n)) { \
    pointer = strtok (NULL, " "); \
    if (!strcmp (pointer, "yes")) { \
      p = true; \
    } \
    else if (!strcmp (pointer, "no")) { \
      p = false; \
    } \
    else { \
      printf ("   ERROR : Unknown value for parameter %s (%s)\n", n, pointer); \
    } \
  }

#define READ_INTEGER_PARAMETER(n,p) \
  if (!strcmp (pointer, n)) { \
    pointer = strtok (NULL, " "); \
    p = atoi (pointer); \
  }

#define READ_STRING_PARAMETER(n,p) \
  if (!strcmp (pointer, n)) { \
    pointer = strtok (NULL, ";"); \
    strcpy (p, pointer); \
  }

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : compute_time
  Description  : Avant chaque coup du programme, cette fonction calcule le temps octroy� avant
                 d'arr�ter sa r�flexion.
                 Les temps sont calcul�s en milli�mes de secondes.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void compute_time (void) {                                                                         DBG_COMPUTE_TIME_CALL

/* --- Local data ------------------------------------------------------------------------------ */

bool time_is_min = false;    /* Indique si la limite inf�rieure est atteinte. */
bool time_is_max = false;    /* Indique si la limite sup�rieure est atteinte. */

/* --- Function code --------------------------------------------------------------------------- */

  /* En mode UCI, le programme calcule un temps par coup en fonction du temps restant pour la
     partie : */
  if (uci_mode) {

    /* Si la r�flexion doit se poursuivre ind�finiment, */
    if (uci_infinite) {

      /* alors le temps octroy� pour la r�flexion est limit� � une journ�e. */
      base_time = 8640000;
      time_for_move = 8640000;

      tools.send_output (true, "info string No limit of time, %s will stop in one day !\n",
        PRODUCT_NAME);
    }
    /* si un nombre de coups est fix� pour un quota de temps, */
    else if (uci_movestogo) {

      /* alors le temps allou� est fix� en divisant le temps restant par le nombre de coups � jouer
         avant le prochain contr�le de temps. */
      time_for_move = ((computer_color ? uci_wtime : uci_btime) - 100) / uci_movestogo;

      tools.send_output (true, "info string Time for move : %.1f s (moves to go : %d)\n",
        time_for_move / 1000.0, uci_movestogo);

      /* Le nombre de coup restant sera redonn� par le superviseur � la prochaine commande "go". */
      uci_movestogo = 0;
    }
    else {

      /* sinon la premi�re fois, */
      if (base_time == 0) {

        /* le temps de base allou� est arbitrairement calcul� sur une base de 60 coups pour toute
           la partie. */
        base_time = (computer_color ? uci_wtime : uci_btime) / 60.0;
        time_for_move = base_time;
      }

      /* Si le programme est en avance au temps par rapport � son adversaire, */
      if ((computer_color ? uci_wtime : uci_btime) >
          (computer_color ? uci_btime : uci_wtime)) {

        /* et si l'avance est suffisamment importante */
        if (abs(uci_wtime - uci_btime) > base_time) {

          /* alors le temps allou� pour le prochain coup est augment� de 10%, */
          time_for_move = time_for_move * 1.1;

          /* mais pour �viter un emballement, une limite haute est fix�e. */
          if (time_for_move > 2 * base_time) {

            time_for_move = 2 * base_time;
            time_is_max = true;
          }
        }
      }
      else {

        /* sinon le temps allou� est diminu� de 20%, */
          time_for_move = time_for_move * 0.8;

         /* mais pour avoir une analyse pertinente, une limite basse est fix�e. */
         if (time_for_move < base_time / 2) {

           time_for_move = base_time / 2;
           time_is_min = true;
         }
      }

      /* S'il reste moins d'une minute, */
      if ((computer_color ? uci_wtime : uci_btime) < 60000) {

        /* un temps maximum est octroy� pour �viter le zeitnot (la profondeur minimum de r�flexion
           �vitera les cas limites) : */
        if (time_for_move > (computer_color ? uci_wtime : uci_btime) / 10.0) {

          time_for_move = (computer_color ? uci_wtime : uci_btime) / 10.0;
          time_is_max = true;
        }
      }

      tools.send_output (true, "info string Time for move : %.1f s (base time %.1f%s)\n",
        time_for_move / 1000.0, base_time / 1000.0,
        time_is_max ? " - time is limited" :
        time_is_min ? " - minimum time allowed" : "");
    }
  }
  /* En mode console, */
  else {

    /* lorsque la recherche est bas�e sur la profondeur de r�flexion, */
    if (search_on_depth) {

      /* une limite est tout de m�me fix�e, */
      time_for_move = max_search_time;
    }
    else {

      /* sinon le temps de r�flexion est le m�me pour chaque coup. */
      time_for_move = time_in_console_mode;
    }
  }                                                                                                DBG_COMPUTE_TIME_END
}
/* End of function : compute_time */

/**************************************************************************************************
  Function     : print_board
  Description  : Envoie une repr�sentation de l'�chiquier vers la destination donn�e en entr�e
                 (console ou autre fichier).
  Parameters   : in  - destination de l'impression de l'�chiquier
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void print_board (FILE *output_file) {                                                             DBG_PRINT_BOARD_CALL

/* --- Local data ------------------------------------------------------------------------------ */

/* Ligne de s�paration de l'�chiquier. */
char *line = "   |---+---+---+---+---+---+---+---|";

/* Caract�res de repr�sentation des pi�ces du jeu. */
char *piece_char[15] = { " ","p","n","b","r","q","k"," "," ","P","N","B","R","Q","K" };

int square;        /* Case de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */

  fprintf (output_file, "\n  %s\n", line);

  for (int y = 8; y > 0; y--) {

    fprintf (output_file, "   %d |", y);

    for (int x = 1; x < 9; x++) {

      square = SQUARE;
      fprintf (output_file, " %s |", piece_char[board[square]]);
    }

    if (y == 3) fprintf (output_file, " halfmove %d", halfmove);
    if (y == 2) fprintf (output_file, " game_ply %d", game_ply);
    if (y == 1) fprintf (output_file, active_color ? " WHITE to move" : " BLACK to move");         DBG_DISPLAY_BOARD_INFORMATIONS

    fprintf (output_file, "\n  %s\n", line);
  }

  fprintf (output_file, "       a   b   c   d   e   f   g   h\n");
}
/* End of function : print_board */

/**************************************************************************************************
  Function     : read_config_file
  Description  : Lecture des param�tres du fichier de configuration.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void read_config_file (void) {                                                                     DBG_READ_CONFIG_FILE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

FILE *config_file;                     /* Fichier des param�tres. */

char parameter_line[STRING_LENGTH];    /* Ligne du fichier. */
char *pointer;                         /* Pointeur pour parcourir une ligne. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Si le fichier de configuration du programme existe, */
  if ((config_file = fopen (CONFIG_FILE, "r")) != NULL) {

    /* alors le programme parcourt le fichier. */
    while (!feof (config_file)) {

      /* Lecture d'une ligne du fichier. */
      fgets (parameter_line, STRING_LENGTH, config_file);

      /* Si la ligne n'est pas un commentaire, */
      if (parameter_line[0] != '#') {

        /* alors le caract�re de retour � la ligne est supprim�, */
        parameter_line[strlen (parameter_line) - 1] = '\0';

        /* un param�tre est lu, */
        pointer = strtok (parameter_line, " ");

        /* et le programme associe sa valeur � une variable. */                                    DBG_READ_CONFIG_FILE_DBG_LIMITS
             READ_BOOLEAN_PARAMETER("blind_game", blind_game)
        else READ_BOOLEAN_PARAMETER("show_board", show_board)
        else READ_BOOLEAN_PARAMETER("search_on_depth", search_on_depth)
        else READ_BOOLEAN_PARAMETER("use_book", use_book)
        else READ_BOOLEAN_PARAMETER("use_captured", use_captured)
        else READ_BOOLEAN_PARAMETER("use_history", use_history)
        else READ_BOOLEAN_PARAMETER("use_killers", use_killers)
        else READ_BOOLEAN_PARAMETER("use_log", use_log)
        else READ_BOOLEAN_PARAMETER("use_null_move", use_null_move)
        else READ_BOOLEAN_PARAMETER("use_pv", use_pv)
        else READ_BOOLEAN_PARAMETER("use_ttable", use_ttable)

        else READ_INTEGER_PARAMETER("max_book_ply", max_book_ply)
        else READ_INTEGER_PARAMETER("max_iterative_depth", max_iterative_depth)
        else READ_INTEGER_PARAMETER("max_search_time", max_search_time)
        else READ_INTEGER_PARAMETER("min_iterative_depth", min_iterative_depth)
        else READ_INTEGER_PARAMETER("ttable_size", ttable_size)
        else READ_INTEGER_PARAMETER("time_in_console_mode", time_in_console_mode)

        else READ_STRING_PARAMETER("black_book_path", black_book_path)
        else READ_STRING_PARAMETER("lan_games_file_path", lan_games_file_path)
        else READ_STRING_PARAMETER("pgn_games_file_path", pgn_games_file_path)
        else READ_STRING_PARAMETER("start_position", start_position)
        else READ_STRING_PARAMETER("white_book_path", white_book_path);
      }
    }

    /* Fermeture du fichier de configuration. */
    fclose (config_file);
  }
  else {

    /* sinon le programme ne trouve pas le fichier de configuration, */
    printf ("\n   WARNING : %s can't open the config file %s\n", PRODUCT_NAME, CONFIG_FILE);
    printf ("\n   It continues with default values.\n");

    /* et il prendra des valeurs par d�faut. */
    blind_game      = false;
    search_on_depth = false;
    show_board      = true;
    use_book        = true;
    use_captured    = true;
    use_history     = true;
    use_killers     = true;
    use_log         = false;
    use_null_move   = true;
    use_pv          = true;
    use_ttable      = true;

    max_book_ply         = 20;
    max_iterative_depth  = 30;
    max_search_time      = 3600000;
    min_iterative_depth  = 4;
    time_in_console_mode = 5000;
    ttable_size          = 64;
  }
}
/* End of function : read_config_file */

/**************************************************************************************************
  Function     : read_input
  Description  : Lecture de caract�res � partir de l'entr�e standard.
  Parameters   : out - cha�ne des caract�res lus
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void read_input (char string[]) {                                                                  DBG_READ_INPUT_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int character;     /* Caract�re lu sur l'entr�e standard. */
int i = 0;         /* Indice du caract�re lu. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Lecture d'une suite de caract�res. */
  while ((character = getc (stdin)) != (int) '\n' && character != EOF) {

    if (i < STRING_LENGTH - 1) {

      /* Construction de la cha�ne. */
      string[i++] = character;
    }
  }

  /* Terminaison de la cha�ne. */
  string[i] = '\0';                                                                                DBG_READ_INPUT_END

  /* Si c'est demand�, la cha�ne lue est �crite dans le fichier journal. */
  if (use_log) fprintf (log_file, "\nInput  : %s\n", string);
}
/* End of function : read_input */

/**************************************************************************************************
  Function     : send_output
  Description  : Pour envoyer des informations vers les diff�rentes sorties (console, fichier
                 journal).
  Parameters   : in  - indique si les donn�es sont � envoyer sur la console
                 in  - format d'impression des donn�es
                 in  - liste de longueur variable des donn�es � envoyer
  Return value : nombre de caract�res �crits
  Validation   : 1
**************************************************************************************************/
int send_output (bool to_stdout, const char *format, ...) {                                        DBG_SEND_OUTPUT_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int size = 0;      /* Nombre de caract�res �crits. */

va_list list;      /* Liste variable des arguments. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Initialisation de la liste des param�tres. */
  va_start (list, format);

  if (to_stdout) {

    /* Envoi des donn�es vers la console. */
    size = vfprintf (stdout, format, list);
  }

  /* Si c'est demand�, */
  if (use_log) {

    /* les donn�es sont �crites dans le fichier journal. */
    size = vfprintf (log_file, format, list);
    fflush (log_file);
  }

  /* Fin de lecture de la liste des param�tres. */
  va_end (list);

  return size;
}
/* End of function : send_output */

/**************************************************************************************************
  Function     : update_pieces
  Description  : Met � jour la table des pi�ces et le lien entre la fiche de la pi�ce et la case de
                 l'�chiquier sur laquelle elle se trouve.
                 L'int�r�t de cette table est de tenir compte de la diminution du nombre des pi�ces
                 au cours de la partie.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void update_pieces (void) {                                                                        DBG_UPDATE_PIECES_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int color;         /* Couleur du camp. */
int square;        /* Case de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Initialisation du nombre des pi�ces blanches et noires. */
  pieces_number[BLACK] = 0;
  pieces_number[WHITE] = 0;

  for (int y = 1; y <= 8; y++) {

    for (int x = 1; x <= 8; x++) {

      /* Calcul de la case � partir des coordonn�es (colonne et rang�e). */
      square = SQUARE;

      /* Si la case sur l'�chiquier n'est pas vide, */
      if (board[square]) {

        /* alors le programme d�termine la couleur de la pi�ce, */
        color = board[square] >> 3;

        /* comptabilise la pi�ce trouv�e, */
        pieces_number[color]++;

        /* indique sur quelle case se trouve chaque pi�ce, */
        pieces[color][pieces_number[color]] = square;

        /* et �tablit un lien direct entre la case et la pi�ce. */
        pieces_ptr[square] = &pieces[color][pieces_number[color]];
      }
      else {

        /* Pour prendre en compte le fait que la position de d�part n'est pas toujours la position
           classique avec toutes les pi�ces, on suppose qu'un mouvement de pi�ce a eu lieu lorsque
           la case de l'�chiquier est vide. */
        moved[square] = true;
      }
    }
  }                                                                                                DBG_UPDATE_PIECES_END
}
/* End of function : update_pieces */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/

tools_module_s tools = {

  compute_time,
  print_board,
  read_config_file,
  read_input,
  send_output,
  update_pieces
};
