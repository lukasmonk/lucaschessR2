/**************************************************************************************************
  File : game.c

  This file is distributed under the MIT license (see the document "doc\license.txt")

  Description : Ce module regroupe quelques fonctions concernant une partie d'�checs.
**************************************************************************************************/

/**************************************************************************************************
  Include files :
**************************************************************************************************/

/* Fichiers en-t�te des diff�rents modules du programme : */
#include "book.h"
#include "debug.h"
#include "game.h"
#include "hash.h"
#include "search.h"
#include "tools.h"

/**************************************************************************************************
  Data :
**************************************************************************************************/

int computer_game_phase = UNDEFINED_GP;

/**************************************************************************************************
  External functions :
**************************************************************************************************/

/**************************************************************************************************
  Function     : check_phase
  Description  : D�termination de la phase du jeu pour une couleur donn�e :
                    - ouverture,
                    - milieu de partie,
                    - finale.
  Parameters   : in  - couleur du camp pour lequel le traitement sera effectu�
  Return value : phase de la partie
  Validation   : 1
**************************************************************************************************/
int check_phase (int color) {                                                                      DBG_GAME_CHECK_PHASE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

int game_phase = OPENING;    /* Phase de la partie */
int moved_pieces;            /* Nombre de pieces ayant d�j� jou�. */

/* --- Function code --------------------------------------------------------------------------- */DBG_GAME_CHECK_PHASE_START

  /* Si un grand nombre de pi�ces ont �t� �chang�es, */
  if (piece_count < 5) {

    /* alors la partie est dans la phase finale. */
    game_phase = ENDGAME;
  }
  else {

    /* Cas de passage en milieu de partie pour la couleur au trait :
       1) Le roque est effectu� (le cas le plus fr�quent).
       2) Le roque n'est plus possible et au moins 3 pi�ces (fou, cavalier ou
          dame) ont �t� d�plac�es.
       3) Au moins 20 demi-coups ont �t� jou�s. */
    moved_pieces = 0;

    /* La valeur de la premi�re rang�e d�pend de la couleur du camp. */
    int y = RR(1);

    /* Calcule le nombre de pi�ces qui ont boug� pour la couleur au trait : */
    for (int x = B; x <= G; x++) {

      if (moved[SQUARE]) {

        moved_pieces++;
      }
    }

    /* Si l'un des cas pr�cit�s est rencontr�, */
    if (   (CASTLE_STATUS & castle_done_mask[color])
        || (   !(CASTLE_STATUS & castle_by_color_mask[color])
            && moved_pieces >= 3)
        || (game_ply > 20)) {

      /* alors c'est la phase du milieu de partie. */
      game_phase = MIDDLE;
    }
  }                                                                                                DBG_GAME_CHECK_PHASE_END

  return game_phase;
}
/* End of function : check_phase */

/**************************************************************************************************
  Function     : go_on
  Description  : Poursuite de la partie avec le lancement de la r�flexion du programme puis le
                 traitement du coup choisi, ainsi que celui d'un �ventuel r�sultat de la partie.
  Parameters   : aucun
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void go_on (void) {                                                                                DBG_GAME_GO_ON_CALL

/* --- Local data ------------------------------------------------------------------------------ */

char lan_move[6];       /* Coup en notation alg�brique. */

double elapsed_time_s;  /* Temps �coul� en secondes. */

int game_phase;         /* Phase de jeu : ouverture, milieu de partie ou finale. */

move_s computer_move;   /* Coup calcul� par le programme. */

/* --- Function code --------------------------------------------------------------------------- */

  /* Identification de la phase de la partie. */
  game_phase = game.check_game_phase (active_color);

  /* Lors du passage d'une phase � une autre, */
  if (computer_game_phase != game_phase) {

    /* alors on affiche la nouvelle phase de jeu, */
    tools.send_output (true, "%s %s is in the %s.\n",
      uci_mode ? "info string" : "\n  ", PRODUCT_NAME,
      game_phase == ENDGAME ? "end of game" :
      game_phase == MIDDLE ? "middle of game" : "opening");

    /* et celle-ci est m�moris�e. */
    computer_game_phase = game_phase;
  }

  /* M�morise l'instant de d�part de la r�flexion. */
  start_thinking_time = clock ();

  /* Si la recherche dans la biblioth�que des ouvertures n'aboutit pas, */
  if (!use_book || game_ply > MAX_BOOK_PLY || !book.select_move (&computer_move)) {

    if (!uci_mode) tools.send_output (true, "\n");

    /* alors le programme d�marre sa propre recherche. */
    search_module.start (&computer_move);
  }

  /* Si la partie n'est pas d�j� termin�e, */
  if (   (   (computer_color == BLACK && result != BLACK_IS_MATED)
          || (computer_color == WHITE && result != WHITE_IS_MATED))
      && result != DRAW_FIFTY_MOVES
      && result != DRAW_REPETITION
      && result != DRAW_STALEMATE) {

    /* alors le coup est convertit puis jou� sur l'�chiquier. */
    moves.convert_pgm_move (&computer_move, lan_move);
    moves.make (&computer_move);

    /* La table des pi�ces est mise � jour avec le reste des pi�ces sur l'�chiquier. */
    tools.update_pieces ();

    /* Le coup est transmis, */
    if (uci_mode) {

      /* selon le format UCI, */
      tools.send_output (true, "bestmove %s\n", lan_move);
    }
    else {

      /* ou en format standard pour le mode console, */
      tools.send_output (true, "\n   %s plays %s\n", PRODUCT_NAME, lan_move);

      if (nodes) {

        elapsed_time_s = (clock () - start_thinking_time) / (double) CLOCKS_PER_SEC;

        /* avec quelques informations suppl�mentaires. */
        tools.send_output (true, "\n   Elapsed time %.1f - ", elapsed_time_s);
        tools.send_output (true, "Nodes %d (%d nps)\n", nodes,
          (int) ((float) nodes / elapsed_time_s));
      }

      /* En fonction du param�trage, l'�chiquier est affich� sur la console, */
      if (show_board) tools.print_board (stdout);

      /* et il est enregistr� dans le fichier journal. */
      if (use_log) tools.print_board (log_file);
    }

    /* Si la position courante s'est retrouv�e trois fois sur l'�chiquier, */
    if (search_module.is_repeated ()) {

      /* alors la partie est nulle par r�p�tition. */
      result = DRAW_REPETITION;
    }
    /* Si 50 coups ont �t� jou�s sans capture ni d�placement de pion, */
    else if (halfmove > 100) {

      /* alors la partie est �galement nulle. */
      result = DRAW_FIFTY_MOVES;
    }
  }

  /* Affichage d'un �ventuel r�sultat de la partie : */
  if (result) {

    tools.send_output (true, "%s", uci_mode ? "info string " : "\n   ");

    switch (result) {

      case WHITE_IS_MATED   : tools.send_output (true, "0-1 (black mates)\n"); break;
      case BLACK_IS_MATED   : tools.send_output (true, "1-0 (white mates)\n"); break;
      case DRAW_FIFTY_MOVES : tools.send_output (true, "1/2-1/2 (draw - fifty move)\n"); break;
      case DRAW_REPETITION  : tools.send_output (true, "1/2-1/2 (draw - 3 repetitions)\n"); break;
      case DRAW_STALEMATE   : tools.send_output (true, "1/2-1/2 (draw - stalemate)\n"); break;
    }
  }
}
/* End of function : go_on */

/**************************************************************************************************
  Function     : initialize
  Description  : Met � jour les donn�es du programme � partir de la position de d�part donn�e en
                 entr�e. Le format de la position (standard FEN/EPD) est d�crit dans le document :
                 "doc\pgn_specification.txt, chapitre 16".
  Parameters   : in  - position de d�part
  Return value : aucune
  Validation   : 1
**************************************************************************************************/
void initialize (const char string[]) {                                                            DBG_GAME_INITIALIZE_CALL

/* --- Local data ------------------------------------------------------------------------------ */

char c, *pointer;                 /* Pour parcourir les caract�res. */
char position[STRING_LENGTH];     /* Position donn�e en entr�e. */

int i;                            /* Rang du caract�re lu dans la cha�ne en entr�e. */
int square;                       /* Case de l'�chiquier. */
int x, y;                         /* Colonne et rang�e de l'�chiquier. */

/* --- Function code --------------------------------------------------------------------------- */DBG_GAME_INITIALIZE_START

  /* Par d�faut aucun demi-coup n'a �t� jou� depuis le d�but de la partie. */
  game_ply = 0;

  /* Par d�faut le nombre de pi�ces est nul. */
  piece_count = 0;

  /* Par d�faut toutes les cases de l'�chiquier sont vues comme un bord et aucune pi�ce n'a encore
     �t� d�plac�e. */
  for (square = 0; square < BOARD_SIZE; square++) {

    board[square] = FRAME;
    moved[square] = 0;
  }

  /* La cha�ne en entr�e va �tre analys�e en d�coupant tous les �l�ments identifi�s dans le format
     FEN/EPD. */
  strcpy (position, string);

  /* Mise � jour de l'�chiquier avec les pi�ces. */
  pointer = strtok (position, " ");
  i = 0;
  c = pointer[i];

  for (y = 8; y >= 1; y--) {

    for (x = A; x <= H; ) {

      /* Case de l'�chiquier calcul�e � partir de ses coordonn�es. */
      square = SQUARE;

      if (c >= '1' && c <= '8') {

        for (int j = 0; j < c - '0'; j++) {

          board[SQUARE] = NONE;
          x++;
        }
      }
      else {

        /* Positionnement des pi�ces, comptabilisation des pi�ces (sauf pions et
           rois) et m�morisation de la position des rois. */
        switch (c) {

          case 'b': board[square] = BBISHOP; piece_count++; break;
          case 'k': board[square] = BKING; king[BLACK] = square; break;
          case 'n': board[square] = BKNIGHT; piece_count++; break;
          case 'p': board[square] = BPAWN;   break;
          case 'q': board[square] = BQUEEN;  piece_count++; break;
          case 'r': board[square] = BROOK;   piece_count++; break;

          case 'B': board[square] = WBISHOP; piece_count++; break;
          case 'K': board[square] = WKING; king[WHITE] = square; break;
          case 'N': board[square] = WKNIGHT; piece_count++; break;
          case 'P': board[square] = WPAWN;   break;
          case 'Q': board[square] = WQUEEN;  piece_count++; break;
          case 'R': board[square] = WROOK;   piece_count++; break;
        }

        x++;
      }

      c = pointer[++i];
    }

    if (y > 1) {

      if (c != '/') {

        tools.send_output (true, "\n   ERROR : Bad position (rank).\n");
      }

      c = pointer[++i];
    }
  }

  /* Mise � jour de la table des pi�ces. */
  tools.update_pieces ();

  /* D�finition de la couleur qui a le trait. */
  pointer = strtok (NULL, " ");
  if (pointer[0] == 'w') {

    active_color = WHITE;
  }
  else if (pointer[0] == 'b') {

    active_color = BLACK;
  }
  else {

    tools.send_output (true, "\n   ERROR : Bad position (unknown color).\n");
  }

  /* Mise � jour des possibilit�s de roquer. */
  pointer = strtok (NULL, " ");
  i = 0;
  c = pointer[i];

  CASTLE_STATUS = 0;

  if (c != '-') {

    if (c == 'K') {

      CASTLE_STATUS |= 0x1;
      c = pointer[++i];
    }

    if (c == 'Q') {

      CASTLE_STATUS |= 0x2;
      c = pointer[++i];
    }

    if (c == 'k') {

      CASTLE_STATUS |= 0x4;
      c = pointer[++i];
    }

    if (c == 'q') {

      CASTLE_STATUS |= 0x8;
    }
  }

  /* Mise � jour de la case de prise en-passant �ventuelle. */
  pointer = strtok (NULL, " ");
  i = 0;
  c = pointer[i];

  if (c == '-') {

    EP_SQUARE = 0;
  }
  else {

    if (c < 'a' || c > 'h') {

      tools.send_output (true, "\n   ERROR : Bad position (file for ep square).");
    }

    y = c - 'a' + 1;
    c = pointer[++i];

    x = c - '1' + 1;

    EP_SQUARE = SQUARE;
  }

  /* Halfmove clock :
     The fifth field is a nonnegative integer representing the halfmove clock. This number is the
     count of halfmoves (or ply) since the last pawn advance or capturing move. This value is used
     for the fifty move draw rule. */
  pointer = strtok (NULL, " ");
  c = pointer[0];

  if (!isdigit(c)) {

    tools.send_output (true, "\n   ERROR : Bad position (Halfmove is not a digit).");
  }
  else {

    halfmove = atoi (&pointer[0]);
  }

  /* Fullmove number :
     The sixth and last field is a positive integer that gives the fullmove number. This will have
     the value "1" for the first move of a game for both White and Black. It is incremented by one
     immediately after each move by Black. */
  pointer = strtok (NULL, " ");
  c = pointer[0];

  if (!isdigit(c)) {

    tools.send_output (true, "\n   ERROR : Bad position (Fullmove is not a digit)");
  }
  else {

    fullmove = atoi (&pointer[0]);
  }

  /* Au d�part le programme n'a pas le trait. */
  computer_color = active_color^1;

  /* Le r�sultat de la partie est pour le moment ind�termin�. */
  result = NO_RESULT;

  /* Calcule la valeur de hachage de la position initiale, */
  h_position = hash.compute_h_position ();

  /* et m�morise cette valeur dans l'historique. */
  h_position_history[0] = h_position;
}
/* End of function : initialize */

/**************************************************************************************************
  Object declaration :
**************************************************************************************************/
game_module_s game = {

  check_phase,
  go_on,
  initialize
};
