rm *.o

gcc -o sissa *.c -s -O3 -std=c99 -flto -D_LINUX -march=athlon64 -Wfatal-errors -lm


