
PATH=/home/lucas/fpc-3.2.2/bin:$PATH
make alouette
