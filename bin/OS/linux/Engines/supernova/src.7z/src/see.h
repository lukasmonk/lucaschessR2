#ifndef SEE_H
#define SEE_H

int SEE(unsigned char board[8][8], int new_x, int new_y, int target, int color);

int SEE_MO(unsigned char board[8][8], int att_x, int att_y, int new_x, int new_y, int target, int color);

#endif