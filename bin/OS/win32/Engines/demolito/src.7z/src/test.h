#pragma once

namespace test {

uint64_t bench(bool perft, int depth, int threads);
bool see(bool verbose = false);

}    // namespace test
