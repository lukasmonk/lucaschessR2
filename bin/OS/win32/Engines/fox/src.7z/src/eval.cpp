#include <assert.h>
#include <stdio.h>
#include "rodent.h"
#include "eval.h"


void calc_limit_elo(void)
{
  int size_table = 17;
  double porc_cub = 0.00;
  double porc_mr = 0.00;

  double x = (double) uci_elo;

  if (x < elo_table[0].x) {
    porc_cub = 100.00;
  }
  else if (x > elo_table[size_table - 1].x) {
    porc_mr = 100.00;
  }
  else {
    for (int i = 0; i < size_table - 1; i++) {
        if (x >= elo_table[i].x && x <= elo_table[i + 1].x) {
            double x1 = (double) elo_table[i].x;
            double porc_cub1 = (double) elo_table[i].porc_cub;
            double porc_mr1 = (double) elo_table[i].porc_mr;
            double x2 = (double) elo_table[i + 1].x;
            double porc_cub2 = (double) elo_table[i + 1].porc_cub;
            double porc_mr2 = (double) elo_table[i + 1].porc_mr;

            porc_cub = porc_cub1 + (x - x1) * (porc_cub2 - porc_cub1) / (x2 - x1);
            porc_mr = porc_mr1 + (x - x1) * (porc_mr2 - porc_mr1) / (x2 - x1);
            break;
        }
    }
  }

  cub_weight = (int) (porc_cub*100.00);
  mr_weight = (int) (porc_mr*100.00);

  fox_weight = 10000 - cub_weight - mr_weight;

  show_weights();
}

void show_weights(void)
{
  printf("info weights foxcub %.02f fox %.02f minirodent %.02f\n", (double)cub_weight/100, (double)fox_weight/100.0, (double)mr_weight/100);
}

sEvalHashEntry EvalTT[EVAL_HASH_SIZE];

void ClearEvalHash(void) {

  for (int e = 0; e < EVAL_HASH_SIZE; e++) {
    EvalTT[e].key = 0;
    EvalTT[e].score = 0;
  }
}

int Evaluate(POS *p, int use_hash) {

  int addr = p->hash_key % EVAL_HASH_SIZE;

  if (EvalTT[addr].key == p->hash_key && use_hash) {
    int hashScore = EvalTT[addr].score;
    return p->side == WC ? hashScore : -hashScore;
  }

  long score = 0;
  if(fox_weight) score += EvaluateFox(p)*fox_weight;
  if(cub_weight) score += EvaluateCub(p)*cub_weight;
  if(mr_weight) score += EvaluateMR(p)*mr_weight;
  score /= 10000;

  EvalTT[addr].key = p->hash_key;
  EvalTT[addr].score = score;
  return score;
}

