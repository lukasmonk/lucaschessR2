#include <assert.h>

#include <stdio.h>

#include <math.h>

#include "rodent.h"


int EvaluateMaterialSideFox(const POS * p, int sd) {

    U64 bbPieces;
    int score = 0;

    bbPieces = PcBb(p, sd, N);
    score = PopCnt(bbPieces) * 350;
    bbPieces = PcBb(p, sd, B);
    score += PopCnt(bbPieces) * 350;
    bbPieces = PcBb(p, sd, R);
    score += PopCnt(bbPieces) * 525;
    bbPieces = PcBb(p, sd, Q);
    score += PopCnt(bbPieces) * 1000;
    bbPieces = PcBb(p, sd, P);
    score += PopCnt(bbPieces) * 100;
    bbPieces = PcBb(p, sd, K);
    score += PopCnt(bbPieces) * 30000;

    return score;
}



int EvaluateFox(POS * p) {

    int score = EvaluateMaterialSideFox(p, WC) - EvaluateMaterialSideFox(p, BC);

    if (score < -MAX_EVAL)
        score = -MAX_EVAL;
    else if (score > MAX_EVAL)
        score = MAX_EVAL;

    return p -> side == WC ? score : -score;
}
