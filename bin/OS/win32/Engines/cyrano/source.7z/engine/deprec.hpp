
#define	pcPAWN		0		// Piece types.
#define	pcKNIGHT	1
#define	pcBISHOP	2
#define	pcROOK		3
#define	pcQUEEN		4
#define	pcKING		5

#define	pcMAX		6
