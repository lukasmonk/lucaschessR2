./makeself.sh ../pyLCR2/genlinux/LucasChessR LucasChessR2_19g_LINUX.sh "Lucas Chess R 2.19g" ./setup_linux.sh .
